#:sdk Microsoft.NET.Sdk.Web
#:package NETCore.Encrypt@3.0.0
#:package Microsoft.Extensions.Caching.Memory@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Buffers;
using System.Runtime.CompilerServices;
using NETCore.Encrypt;
using Microsoft.Extensions.Caching.Memory;

[SkipLocalsInit]
public sealed class EncryptService : IDisposable
{
    private readonly ObjectPool<byte[]> _bufferPool;
    private readonly MemoryCache _keyCache;
    private readonly string _defaultAesKey;

    public EncryptService()
    {
        _bufferPool = new DefaultObjectPool<byte[]>(
            new ArrayPoolPolicy(), 
            Environment.ProcessorCount * 4);
            
        _keyCache = new MemoryCache(new MemoryCacheOptions
        {
            SizeLimit = 100
        });
        
        _defaultAesKey = EncryptProvider.CreateAesKey().Key;
    }

    // 1. AES加密
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public string AesEncrypt(string input, string key = null)
    {
        var buffer = _bufferPool.Get();
        try
        {
            var aesKey = key ?? _defaultAesKey;
            return EncryptProvider.AESEncrypt(input, aesKey);
        }
        finally
        {
            _bufferPool.Return(buffer);
        }
    }

    // 2. AES解密
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public string AesDecrypt(string input, string key = null)
    {
        var buffer = _bufferPool.Get();
        try
        {
            var aesKey = key ?? _defaultAesKey;
            return EncryptProvider.AESDecrypt(input, aesKey);
        }
        finally
        {
            _bufferPool.Return(buffer);
        }
    }

    // 3. MD5哈希
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public string Md5Hash(string input)
    {
        var buffer = _bufferPool.Get();
        try
        {
            return EncryptProvider.Md5(input);
        }
        finally
        {
            _bufferPool.Return(buffer);
        }
    }

    // 4. SHA哈希系列
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public string ShaHash(string input, ShaType type = ShaType.SHA256)
    {
        var buffer = _bufferPool.Get();
        try
        {
            return type switch
            {
                ShaType.SHA1 => EncryptProvider.Sha1(input),
                ShaType.SHA256 => EncryptProvider.Sha256(input),
                ShaType.SHA384 => EncryptProvider.Sha384(input),
                ShaType.SHA512 => EncryptProvider.Sha512(input),
                _ => EncryptProvider.Sha256(input)
            };
        }
        finally
        {
            _bufferPool.Return(buffer);
        }
    }

    // 5. RSA密钥生成
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public (string PublicKey, string PrivateKey) GenerateRsaKeys(int keySize = 2048)
    {
        var cacheKey = $"rsa_{keySize}";
        if (_keyCache.TryGetValue<(string, string)>(cacheKey, out var cached))
            return cached;
            
        var key = EncryptProvider.CreateRsaKey(keySize);
        _keyCache.Set(cacheKey, (key.PublicKey, key.PrivateKey), TimeSpan.FromHours(1));
        return (key.PublicKey, key.PrivateKey);
    }

    // 6. RSA加密
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public string RsaEncrypt(string input, string publicKey)
    {
        var buffer = _bufferPool.Get();
        try
        {
            return EncryptProvider.RSAEncrypt(publicKey, input);
        }
        finally
        {
            _bufferPool.Return(buffer);
        }
    }

    // 7. RSA解密
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public string RsaDecrypt(string input, string privateKey)
    {
        var buffer = _bufferPool.Get();
        try
        {
            return EncryptProvider.RSADecrypt(privateKey, input);
        }
        finally
        {
            _bufferPool.Return(buffer);
        }
    }

    public void Dispose()
    {
        _keyCache.Dispose();
    }
}

[SkipLocalsInit]
public class ArrayPoolPolicy : IPooledObjectPolicy<byte[]>
{
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public byte[] Create()
    {
        return GC.AllocateUninitializedArray<byte>(4096, pinned: true);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public bool Return(byte[] obj)
    {
        Array.Clear(obj, 0, obj.Length);
        return true;
    }
}

public enum ShaType
{
    SHA1,
    SHA256,
    SHA384,
    SHA512
}

// 启动配置
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<EncryptService>();

var app = builder.Build();
app.MapGet("/", () => "NETCore.Encrypt Service Running");
app.Run();