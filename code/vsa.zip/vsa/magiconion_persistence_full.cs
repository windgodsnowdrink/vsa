#:sdk Microsoft.NET.Sdk.Web
#:package MagicOnion@5.0.0
#:package Microsoft.Extensions.Caching.StackExchangeRedis@8.0.0
#:package Microsoft.Extensions.Caching.Memory@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using MagicOnion;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;

var builder = WebApplication.CreateBuilder();

// 1. Redis分布式缓存
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = "redis:6379";
    options.InstanceName = "MagicOnion_";
});

// 2. 本地内存缓存
builder.Services.AddSingleton<IMemoryCache>(sp =>
    new MemoryCache(new MemoryCacheOptions
    {
        SizeLimit = 1024 * 1024 * 100, // 100MB
        ExpirationScanFrequency = TimeSpan.FromMinutes(5)
    }));

// 3. 缓存感知服务
builder.Services.AddMagicOnion()
    .AddCaching(options =>
    {
        options.DefaultExpiration = TimeSpan.FromMinutes(30);
        options.SlidingExpiration = TimeSpan.FromMinutes(10);
    });

var app = builder.Build();
app.MapMagicOnionService();
app.Run();

// 缓存策略实现
public class HybridCacheStrategy : ICacheStrategy
{
    private readonly IDistributedCache _distributedCache;
    private readonly IMemoryCache _memoryCache;
    
    public HybridCacheStrategy(
        IDistributedCache distributedCache,
        IMemoryCache memoryCache)
    {
        _distributedCache = distributedCache;
        _memoryCache = memoryCache;
    }

    public async Task<T> GetOrCreateAsync<T>(string key, Func<Task<T>> factory)
    {
        // 实现混合缓存逻辑
        // ... existing code ...
    }
}