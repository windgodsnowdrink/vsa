#:sdk Microsoft.NET.Sdk
#:package NRules@0.9.7
#:package NRules.DependencyInjection@0.9.7
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Collections.Concurrent;
using NRules;
using NRules.Fluent;
using NRules.RuleModel;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

public record Order(int Id, string CustomerId, decimal TotalAmount, bool IsPreferred);
public record Discount(decimal Amount, string Reason);

public class OrderDiscountRule : Rule
{
    public override void Define()
    {
        Order order = null!;
        Discount discount = null!;

        When()
            .Match<Order>(() => order, o => o.IsPreferred);

        Then()
            .Do(ctx => ctx.Insert(new Discount(order.TotalAmount * 0.1m, "Preferred customer discount")));
    }
}

public class BulkOrderDiscountRule : Rule
{
    public override void Define()
    {
        Order order = null!;

        When()
            .Match<Order>(() => order, o => o.TotalAmount > 1000);

        Then()
            .Do(ctx => ctx.Insert(new Discount(50, "Bulk order discount")));
    }
}

public class RuleEngineOptions
{
    public int MaxParallelism { get; set; } = Environment.ProcessorCount;
    public TimeSpan SessionTimeout { get; set; } = TimeSpan.FromSeconds(30);
}

public class RuleEngine : IAsyncDisposable
{
    private readonly ISessionFactory _sessionFactory;
    private readonly ConcurrentBag<ISession> _activeSessions = new();
    private readonly ILogger<RuleEngine> _logger;
    private readonly RuleEngineOptions _options;

    public RuleEngine(
        ISessionFactory sessionFactory, 
        IOptions<RuleEngineOptions> options,
        ILogger<RuleEngine> logger)
    {
        _sessionFactory = sessionFactory;
        _logger = logger;
        _options = options.Value;
    }

    public async Task<IEnumerable<Discount>> ExecuteRulesAsync(Order order, CancellationToken cancellationToken = default)
    {
        using var session = _sessionFactory.CreateSession();
        _activeSessions.Add(session);
        
        session.Insert(order);
        
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        cts.CancelAfter(_options.SessionTimeout);
        
        try
        {
            await Task.Run(() => session.Fire(_options.MaxParallelism), cts.Token);
            return session.Query<Discount>().ToList();
        }
        finally
        {
            _activeSessions.TryTake(out _);
        }
    }

    public async ValueTask DisposeAsync()
    {
        foreach (var session in _activeSessions)
        {
            try
            {
                session.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to dispose rule session");
            }
        }
        
        await Task.CompletedTask;
    }
}

public static class RuleEngineExtensions
{
    public static IServiceCollection AddRuleEngine(this IServiceCollection services, Action<RuleEngineOptions> configure)
    {
        services.Configure(configure);
        
        services.AddSingleton<IRuleRepository>(provider => 
        {
            var repository = new RuleRepository();
            repository.Load(x => x.From(typeof(OrderDiscountRule).Assembly));
            return repository;
        });
        
        services.AddSingleton<ISessionFactory>(provider => 
        {
            var repository = provider.GetRequiredService<IRuleRepository>();
            var factory = repository.Compile();
            factory.DependencyResolver = new DependencyResolver(provider);
            return factory;
        });
        
        services.AddSingleton<RuleEngine>();
        
        return services;
    }
}

// 电梯状态模型
public record ElevatorSignal(int ElevatorId, int CurrentFloor, ElevatorDirection Direction, ElevatorStatus Status, DateTime Timestamp);
public record ElevatorDispatch(int ElevatorId, int TargetFloor, ElevatorDirection Direction, int Priority);

public enum ElevatorDirection { Up, Down, None }

public enum ElevatorAlertType 
{
    Overload,
    DoorObstruction,
    PowerFailure,
    EmergencyStop,
    MaintenanceRequired
}

public record ElevatorAlert(
    int ElevatorId,
    ElevatorAlertType AlertType,
    DateTimeOffset Timestamp,
    string Details);

public class ElevatorStateMachine : IStateMachine<ElevatorStatus>
{
    private readonly Channel<ElevatorCommand> _commandChannel;
    private readonly ILogger<ElevatorStateMachine> _logger;
    private readonly ObjectPool<ElevatorContext> _contextPool;

    public ElevatorStateMachine(
        Channel<ElevatorCommand> commandChannel,
        ILogger<ElevatorStateMachine> logger,
        ObjectPool<ElevatorContext> contextPool)
    {
        _commandChannel = commandChannel;
        _logger = logger;
        _contextPool = contextPool;
    }

    public async Task ProcessCommandsAsync(CancellationToken cancellationToken)
    {
        await foreach (var command in _commandChannel.Reader.ReadAllAsync(cancellationToken))
        {
            using var context = _contextPool.Get();
            try
            {
                await HandleCommandAsync(command, context.Value);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing elevator command {CommandId}", command.CommandId);
            }
        }
    }

    private async Task HandleCommandAsync(ElevatorCommand command, ElevatorContext context)
    {
        // State machine logic implementation
    }
}
public enum ElevatorStatus 
{
    Online,          // 正常运行
    Offline,         // 离线状态
    Maintenance,     // 维护中
    Overloaded,      // 超载
    DoorObstructed,  // 门受阻
    PowerFailure,    // 电源故障
    EmergencyStop,   // 紧急停止
    OutOfService,    // 停用
    Idle,            // 空闲状态
    Moving,          // 移动中
    Stopped,         // 已停止
    EmergencyStopped,// 紧急停止
    MaintenanceMode  // 维护模式
}

// 电梯调度规则
public class ElevatorDispatchRule : Rule
{
    public override void Define()
    {
        ElevatorSignal signal = null!;
        ElevatorDispatch dispatch = null!;

        When()
            .Match<ElevatorSignal>(() => signal, s => s.Status == ElevatorStatus.Online)
            .Match<ElevatorDispatch>(() => dispatch);

        Then()
            .Do(ctx => CalculateDispatch(signal, dispatch));
    }

    private void CalculateDispatch(ElevatorSignal signal, ElevatorDispatch dispatch)
{
    // 检查电梯是否处于可调度状态
    if (signal.Status == ElevatorStatus.Online || 
        signal.Status == ElevatorStatus.Overloaded)
    {
        // 计算调度得分（基于距离、方向和当前负载）
        var score = CalculateDispatchScore(signal, dispatch);
        
        // 更新最佳调度决策
        ctx.Update(dispatch with { ElevatorId = signal.ElevatorId, Priority = score });
    }
    else if (signal.Status == ElevatorStatus.Overloaded)
    {
        // 超载状态特殊处理
        ctx.Insert(new ElevatorAlert(signal.ElevatorId, 
            "Overload condition detected", DateTime.UtcNow));
    }
}

private int CalculateDispatchScore(ElevatorSignal signal, ElevatorDispatch dispatch)
{
    // 计算距离分
    var distanceScore = Math.Abs(signal.CurrentFloor - dispatch.TargetFloor);
    
    // 计算方向分
    var directionScore = signal.Direction == dispatch.Direction ? 10 : 0;
    
    // 计算优先级分
    var priorityScore = dispatch.Priority * 2;
    
    return 100 - distanceScore + directionScore + priorityScore;
}
}

// 离线电梯处理规则
public class OfflineElevatorRule : Rule
{
    public override void Define()
    {
        ElevatorSignal signal = null!;

        When()
            .Match<ElevatorSignal>(() => signal, s => s.Status == ElevatorStatus.Offline);

        Then()
            .Do(ctx => HandleOfflineElevator(signal));
    }

    private void HandleOfflineElevator(ElevatorSignal signal)
{
    // 记录离线事件
    ctx.Insert(new ElevatorEvent(
        signal.ElevatorId, 
        "Elevator went offline", 
        signal.CurrentFloor, 
        DateTime.UtcNow));
    
    // 如果电梯在运行中离线，触发紧急协议
    if (signal.Direction != ElevatorDirection.None)
    {
        ctx.Insert(new EmergencyProtocol(
            signal.ElevatorId, 
            signal.CurrentFloor, 
            "Elevator offline while moving"));
    }
}
}

// 示例使用
public class ElevatorRuleEngineSample
{
    private readonly RuleEngine _ruleEngine;

    public ElevatorRuleEngineSample(RuleEngine ruleEngine)
    {
        _ruleEngine = ruleEngine;
    }

    public async Task RunSampleAsync()
    {
        // 模拟电梯信号
        var signals = new List<ElevatorSignal>
        {
            new(1, 3, ElevatorDirection.Up, ElevatorStatus.Online, DateTime.Now),
            new(2, 5, ElevatorDirection.Down, ElevatorStatus.Online, DateTime.Now),
            new(3, 1, ElevatorDirection.None, ElevatorStatus.Offline, DateTime.Now)
        };

        // 模拟调度请求
        var dispatch = new ElevatorDispatch(0, 8, ElevatorDirection.Up, 1);

        // 执行规则
        foreach (var signal in signals)
        {
            await _ruleEngine.ExecuteRulesAsync(signal);
        }
        await _ruleEngine.ExecuteRulesAsync(dispatch);
    }
}