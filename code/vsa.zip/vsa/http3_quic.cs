#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.Native.Quic.MsQuic.OpenSSL@2.3.0
#:package System.Net.Quic@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using System.Net.Quic;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Channels;
using Microsoft.Extensions.ObjectPool;

[SkipLocalsInit]
public sealed class Http3Server : IAsyncDisposable
{
    private readonly QuicListener _listener;
    private readonly Channel<QuicConnection> _connectionChannel;
    private readonly CancellationTokenSource _cts;
    private readonly ObjectPool<QuicStream> _streamPool;
    private readonly TailLatencyOptimizer _latencyOptimizer;

    public Http3Server(X509Certificate2 certificate, IPEndPoint endpoint)
    {
        _latencyOptimizer = new TailLatencyOptimizer();
        _cts = new CancellationTokenSource();
        
        var options = new QuicListenerOptions
        {
            ListenEndPoint = endpoint,
            ApplicationProtocols = new List<SslApplicationProtocol> 
            { 
                SslApplicationProtocol.Http3 
            },
            ConnectionOptionsCallback = (_, _, _) => 
                ValueTask.FromResult(new QuicServerConnectionOptions
                {
                    DefaultStreamErrorCode = 0x0c,
                    DefaultCloseErrorCode = 0x10,
                    ServerAuthenticationOptions = new SslServerAuthenticationOptions
                    {
                        ServerCertificate = certificate,
                        ApplicationProtocols = new List<SslApplicationProtocol>
                        {
                            SslApplicationProtocol.Http3
                        }
                    }
                })
        };
        
        _listener = new QuicListener(options);
        _connectionChannel = Channel.CreateBounded<QuicConnection>(
            new BoundedChannelOptions(10_000)
            {
                SingleReader = true,
                FullMode = BoundedChannelFullMode.DropOldest
            });
        
        _streamPool = new DefaultObjectPool<QuicStream>(
            new QuicStreamPooledPolicy(), 
            Environment.ProcessorCount * 2);
        
        _ = Task.Run(AcceptConnectionsAsync);
        _ = Task.Run(ProcessConnectionsAsync);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task AcceptConnectionsAsync()
    {
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                var connection = await _listener.AcceptConnectionAsync(_cts.Token);
                await _connectionChannel.Writer.WriteAsync(connection, _cts.Token);
            }
            catch (OperationCanceledException) when (_cts.IsCancellationRequested)
            {
                break;
            }
        }
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task ProcessConnectionsAsync()
    {
        await foreach (var connection in _connectionChannel.Reader.ReadAllAsync(_cts.Token))
        {
            _ = Task.Run(async () =>
            {
                using (connection)
                {
                    while (!connection.IsClosed && !_cts.IsCancellationRequested)
                    {
                        try
                        {
                            var stream = await connection.AcceptInboundStreamAsync(_cts.Token);
                            _ = ProcessStreamAsync(stream);
                        }
                        catch (QuicException) { break; }
                    }
                }
            });
        }
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task ProcessStreamAsync(QuicStream stream)
    {
        using var latencyToken = _latencyOptimizer.BeginOperation();
        var buffer = ArrayPool<byte>.Shared.Rent(4096);
        try
        {
            var bytesRead = await stream.ReadAsync(buffer, _cts.Token);
            // HTTP/3帧处理逻辑
            await HandleHttp3Frame(buffer.AsMemory(0, bytesRead), stream);
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }

    public async ValueTask DisposeAsync()
    {
        _cts.Cancel();
        _connectionChannel.Writer.Complete();
        await _connectionChannel.Reader.Completion;
        await _listener.DisposeAsync();
    }
}

[SkipLocalsInit]
internal sealed class QuicStreamPooledPolicy : PooledObjectPolicy<QuicStream>
{
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public override QuicStream Create() => throw new NotSupportedException();

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public override bool Return(QuicStream obj)
    {
        if (!obj.CanWrite) return false;
        obj.Reset(QuicAbortDirection.Both, 0);
        return true;
    }
}

// 启动配置
var builder = WebApplication.CreateBuilder(args);
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(443, listenOptions =>
    {
        listenOptions.UseHttps(httpsOptions =>
        {
            httpsOptions.Protocols = HttpProtocols.Http3;
        });
    });
});

var app = builder.Build();
app.MapGet("/", () => "HTTP/3 Server Running");
app.Run();