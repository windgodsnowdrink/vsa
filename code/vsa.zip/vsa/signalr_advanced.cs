#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.AspNetCore.SignalR@8.0.0
#:package MessagePack@2.5.122
#:package BrotliSharpLib@0.3.3
#:package Microsoft.EntityFrameworkCore.SqlServer@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.IO.Compression;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder();

// 1. 消息压缩策略
builder.Services.AddSignalR()
    .AddMessagePackProtocol(options => {
        options.Compression = MessagePackCompression.Lz4BlockArray;
        options.CompressionMinLength = 1024;
    });

// 2. 离线消息同步
builder.Services.AddDbContext<OfflineMessageContext>(options => 
    options.UseSqlServer("Server=.;Database=SignalR_Offline;Trusted_Connection=True;"));

// 3. 服务质量分级
builder.Services.AddSingleton<IQualityOfService>(sp => 
    new PriorityBasedQoS(
        new ThreadLocal<Span<byte>>(() => stackalloc byte[512])));

var app = builder.Build();
app.MapHub<AdvancedHub>("/advanced");
app.Run();

// 高级Hub实现
public class AdvancedHub : Hub
{
    private readonly OfflineMessageContext _db;
    private readonly IQualityOfService _qos;
    
    public AdvancedHub(OfflineMessageContext db, IQualityOfService qos)
    {
        _db = db;
        _qos = qos;
    }

    public override async Task OnConnectedAsync()
    {
        // 同步离线消息
        var messages = await _db.Messages
            .Where(m => m.UserId == Context.UserIdentifier)
            .OrderBy(m => m.Timestamp)
            .ToListAsync();
        
        foreach (var msg in messages)
            await Clients.Caller.SendAsync("ReceiveOfflineMessage", msg);
        
        await base.OnConnectedAsync();
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task SendWithQoS(string message, QoSPriority priority)
    {
        await _qos.ProcessAsync(Context.ConnectionId, message, priority);
    }
}

// 服务质量分级器
[SkipLocalsInit]
public class PriorityBasedQoS : IQualityOfService
{
    private readonly ThreadLocal<Span<byte>> _buffer;
    private readonly Channel<QoSEntry> _highPriorityChannel;
    private readonly Channel<QoSEntry> _normalChannel;
    
    public PriorityBasedQoS(ThreadLocal<Span<byte>> buffer)
    {
        _buffer = buffer;
        _highPriorityChannel = Channel.CreateBounded<QoSEntry>(1000);
        _normalChannel = Channel.CreateBounded<QoSEntry>(10000);
    }

    public async Task ProcessAsync(string connectionId, string message, QoSPriority priority)
    {
        var entry = new QoSEntry(connectionId, message, DateTime.UtcNow);
        var channel = priority == QoSPriority.High ? 
            _highPriorityChannel : _normalChannel;
        
        await channel.Writer.WriteAsync(entry);
    }
}

// 数据库上下文
public class OfflineMessageContext : DbContext
{
    public DbSet<OfflineMessage> Messages { get; set; }
    
    public OfflineMessageContext(DbContextOptions options) : base(options) {}
}

public enum QoSPriority
{
    Low,
    Normal,
    High
}

public record QoSEntry(
    string ConnectionId,
    string Message,
    DateTime Timestamp);

public record OfflineMessage(
    string UserId,
    string Content,
    DateTime Timestamp);