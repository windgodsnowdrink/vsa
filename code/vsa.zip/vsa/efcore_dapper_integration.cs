#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.EntityFrameworkCore.Sqlite@8.0.0
#:package Dapper@2.1.28
#:package Dapper.AOT@0.1.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Data;
using System.Data.Common;
using Dapper;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// 1. 配置读写分离数据库连接
builder.Services.AddSingleton<IDbConnection>(_ => 
    new SqliteConnection("Data Source=readonly.db;Mode=ReadOnly"));
builder.Services.AddSingleton<IDbConnection>(_ => 
    new SqliteConnection("Data Source=readwrite.db;Mode=ReadWrite"));

// 2. 配置EFCore主数据库上下文
builder.Services.AddDbContext<AppDbContext>(options => 
    options.UseSqlite("Data Source=master.db"));

// 3. 配置DapperAOT
SqlMapper.AddTypeHandler(new DateTimeOffsetHandler());
DapperAot.Enable();

// 4. 分库分表路由服务
builder.Services.AddSingleton<IDatabaseRouter, HashBasedDatabaseRouter>();

var app = builder.Build();
app.MapGet("/", () => "EFCore+Dapper Integration Ready");
app.Run();

// 数据库上下文
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // 配置分表策略
        modelBuilder.Entity<Order>().ToTable("Orders_${ShardId}");
    }
}

// 分库分表路由实现
public class HashBasedDatabaseRouter : IDatabaseRouter
{
    private readonly IDbConnection[] _readConnections;
    private readonly IDbConnection[] _writeConnections;
    
    public HashBasedDatabaseRouter(IEnumerable<IDbConnection> connections)
    {
        _readConnections = connections.Where(c => c.ConnectionString.Contains("ReadOnly")).ToArray();
        _writeConnections = connections.Where(c => c.ConnectionString.Contains("ReadWrite")).ToArray();
    }
    
    public IDbConnection GetReadConnection(string shardKey)
    {
        var hash = GetShardHash(shardKey);
        return _readConnections[hash % _readConnections.Length];
    }
    
    public IDbConnection GetWriteConnection(string shardKey)
    {
        var hash = GetShardHash(shardKey);
        return _writeConnections[hash % _writeConnections.Length];
    }
    
    private int GetShardHash(string key)
    {
        return key.GetHashCode() & 0x7FFFFFFF; // 确保正数
    }
}

// DapperAOT实体映射
[GenerateAOT]
public record Order(
    int Id,
    string OrderNumber,
    DateTimeOffset CreatedAt,
    decimal Amount);

// 高性能查询实现
public static class OrderQueries
{
    [GenerateAOT]
    public static async Task<Order?> GetOrderByNumber(this IDbConnection db, string orderNumber)
    {
        return await db.QueryFirstOrDefaultAsync<Order>(
            "SELECT * FROM Orders WHERE OrderNumber = @orderNumber",
            new { orderNumber });
    }
    
    [GenerateAOT]
    public static async Task<int> CreateOrder(this IDbConnection db, Order order)
    {
        return await db.ExecuteAsync(
            "INSERT INTO Orders (OrderNumber, CreatedAt, Amount) " +
            "VALUES (@OrderNumber, @CreatedAt, @Amount)",
            order);
    }
}

// 自定义类型处理器
public class DateTimeOffsetHandler : SqlMapper.TypeHandler<DateTimeOffset>
{
    public override DateTimeOffset Parse(object value) => 
        DateTimeOffset.FromUnixTimeMilliseconds((long)value);
        
    public override void SetValue(IDbDataParameter parameter, DateTimeOffset value) => 
        parameter.Value = value.ToUnixTimeMilliseconds();
}

// 扩展分库分表路由策略
public class ConsistentHashRouter : IDatabaseRouter
{
    private readonly SortedDictionary<uint, IDbConnection> _circle = new();
    
    public ConsistentHashRouter(IEnumerable<IDbConnection> connections)
    {
        foreach (var conn in connections)
        {
            for (int i = 0; i < 160; i++) // 虚拟节点
            {
                var hash = MurmurHash3.ComputeHash($"{conn.ConnectionString}-{i}");
                _circle[hash] = conn;
            }
        }
    }
    
    public IDbConnection GetConnection(string key)
    {
        var hash = MurmurHash3.ComputeHash(key);
        var first = _circle.Keys.FirstOrDefault(k => k >= hash);
        return _circle[first == 0 ? _circle.Keys.Last() : first];
    }
}

// 高性能批处理扩展
public static class DapperBatchExtensions
{
    [GenerateAOT]
    public static async Task BulkInsertAsync<T>(
        this IDbConnection db, 
        IEnumerable<T> entities,
        CancellationToken ct = default)
    {
        using var tx = db.BeginTransaction();
        using var cmd = db.CreateCommand();
        
        // 使用AOT编译的批量插入
        await db.ExecuteAsync(
            "INSERT INTO Table VALUES(@p0, @p1)", 
            entities.Select(x => new { x.p0, x.p1 }),
            transaction: tx);
        
        await tx.CommitAsync(ct);
    }
}