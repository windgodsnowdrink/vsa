/*
- 优先使用直接依赖注入，简单直接
- 跨模块通信使用MediatR或领域事件
- 共享核心业务逻辑应放在共享内核模块
- 避免服务之间的循环依赖
- 使用明确的接口定义服务契约
*/

// 直接依赖注入方式（推荐）：
// 在Endpoint类中直接注入所需服务
public static async Task<IResult> MyEndpoint(
    [FromServices] MyInternalService service,
    [FromServices] ILogger<MyEndpoint> logger)
{
    // 调用服务方法
    var result = await service.DoSomethingAsync();
    return Results.Ok(result);
}

// 通过共享内核模块方式：
// 在共享内核模块中定义接口
public interface ISharedService
{
    Task<Result> ProcessDataAsync(Input input);
}

// 在Endpoint中调用
public static async Task<IResult> ProcessEndpoint(
    [FromServices] ISharedService service)
{
    // ... existing code ...
    var result = await service.ProcessDataAsync(input);
    // ... existing code ...
}

// 使用MediatR的跨切片通信：
// 定义命令
public record ProcessCommand(Input Data) : IRequest<Result>;

// 在Endpoint中发送命令
public static async Task<IResult> ProcessEndpoint(
    [FromServices] IMediator mediator)
{
    var result = await mediator.Send(new ProcessCommand(input));
    return Results.Ok(result);
}

// 领域事件驱动方式：
// 在服务中发布事件
await _eventBus.PublishAsync(new DataProcessedEvent(data));

// 在其他切片中订阅事件
public class DataProcessedHandler : IEventHandler<DataProcessedEvent>
{
    public Task Handle(DataProcessedEvent @event)
    {
        // 处理事件
    }
}