#:sdk Microsoft.NET.Sdk.Web
#:package NetEscapades.AspNetCore.SecurityHeaders@3.0.0
#:package Microsoft.AspNetCore.ResponseCompression@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using NetEscapades.AspNetCore.SecurityHeaders;
using NetEscapades.AspNetCore.SecurityHeaders.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

// 安全头配置
// builder.Services.AddSecurityHeaders(builder.Configuration.GetSection("SecurityHeaders"));
builder.Services.AddSecurityHeaders(securityHeaders =>
{
    // 内容安全策略
    securityHeaders.AddContentSecurityPolicy(csp =>
    {
        csp.AddDefaultSrc().Self();
        cp.AddScriptSrc()
            .Self()
            .UnsafeInline()
            .WithNonce()
            .StrictDynamic();
        csp.AddStyleSrc()
            .Self()
            .UnsafeInline();
        csp.AddImgSrc().Self().Data();
        csp.AddFontSrc().Self();
        csp.AddFormAction().Self();
        csp.AddFrameAncestors().None();
        csp.AddUpgradeInsecureRequests();
    });

    // 其他安全头
    securityHeaders.AddCrossOriginOpenerPolicy(builder => builder.SameOrigin());
    securityHeaders.AddCrossOriginResourcePolicy(builder => builder.SameOrigin());
    securityHeaders.AddCrossOriginEmbedderPolicy(builder => builder.RequireCorp());
    securityHeaders.AddReferrerPolicy(builder => builder.StrictOriginWhenCrossOrigin());
    securityHeaders.AddPermissionsPolicy(builder =>
    {
        builder.AddAccelerometer().None();
        builder.AddCamera().None();
        builder.AddGeolocation().None();
        builder.AddMicrophone().None();
        builder.AddPayment().None();
    });
});

// 响应压缩
builder.Services.AddResponseCompression(options =>
{
    options.EnableForHttps = true;
    options.Providers.Add<BrotliCompressionProvider>();
    options.Providers.Add<GzipCompressionProvider>();
});

var app = builder.Build();

// 中间件配置
app.UseSecurityHeaders();
app.UseResponseCompression();
app.UseHsts();
app.UseHttpsRedirection();

app.MapGet("/", () => "Secure Web Application");
app.Run();