#:sdk Microsoft.NET.Sdk.Web
#:package Dtmcli@2.6.0
#:package MediatR@12.1.1
#:property TargetFramework net10.0
#:property Nullable enable

using Dtmcli;
using MediatR;

// TCC事务协调器
public class TccCoordinator<TRequest> : IPipelineBehavior<TRequest, Unit>
    where TRequest : IRequest<Unit>
{
    private readonly DtmClient _dtmClient;
    private readonly ILogger<TccCoordinator<TRequest>> _logger;

    public TccCoordinator(DtmClient dtmClient, ILogger<TccCoordinator<TRequest>> logger)
    {
        _dtmClient = dtmClient;
        _logger = logger;
    }

    public async Task<Unit> Handle(
        TRequest request,
        RequestHandlerDelegate<Unit> next,
        CancellationToken cancellationToken)
    {
        if (request is not ITccTransaction tccRequest)
            return await next();

        var gid = await _dtmClient.GenGid();
        tccRequest.SetGid(gid);

        try
        {
            // Try阶段
            await _dtmClient.TccGlobalTransaction(gid, async (tcc) =>
            {
                await tccRequest.TryPhase();
                await next();
            });

            return Unit.Value;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "TCC事务执行失败");
            throw;
        }
    }
}

// TCC事务接口
public interface ITccTransaction
{
    string Gid { get; }
    void SetGid(string gid);
    Task TryPhase();
    Task ConfirmPhase();
    Task CancelPhase();
}

// 示例：订单创建TCC处理器
public class CreateOrderTccHandler : IRequestHandler<CreateOrderCommand>, ITccTransaction
{
    public string Gid { get; private set; } = null!;
    
    public void SetGid(string gid) => Gid = gid;

    public async Task<Unit> Handle(CreateOrderCommand request, CancellationToken cancellationToken)
    {
        // 主业务逻辑
        return Unit.Value;
    }

    public async Task TryPhase()
    {
        // 预留资源
    }

    public async Task ConfirmPhase()
    {
        // 确认资源
    }

    public async Task CancelPhase()
    {
        // 取消预留
    }
}

// DI扩展
public static class MediatRDependencyInjectionExtensions
{
    public static IServiceCollection AddMediatRTccSupport(this IServiceCollection services)
    {
        services.AddSingleton<DtmClient>(sp => 
            new DtmClient(sp.GetRequiredService<IConfiguration>()[\"Dtm:Url\"]));
            
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(TccCoordinator<>));
        return services;
    }
}