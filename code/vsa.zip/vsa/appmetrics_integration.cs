#:sdk Microsoft.NET.Sdk.Web
#:package App.Metrics@4.3.0
#:package App.Metrics.AspNetCore@4.3.0
#:package App.Metrics.Formatters.Prometheus@4.3.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using App.Metrics;
using App.Metrics.Counter;
using App.Metrics.Gauge;
using App.Metrics.Timer;

public class AppMetricsService
{
    private readonly IMetrics _metrics;
    
    public AppMetricsService(IMetrics metrics)
    {
        _metrics = metrics;
    }

    // 计数器指标
    public void IncrementRequestCounter(string endpoint)
    {
        var options = new CounterOptions
        {
            Name = "http_requests_total",
            Tags = new MetricTags("endpoint", endpoint)
        };
        _metrics.Increment(options);
    }

    // 测量执行时间
    public async Task<T> TimeAsync<T>(string operationName, Func<Task<T>> operation)
    {
        var options = new TimerOptions
        {
            Name = "operation_duration_seconds",
            Tags = new MetricTags("operation", operationName)
        };
        
        using (_metrics.Measure.Timer.Time(options))
        {
            return await operation();
        }
    }

    // 记录内存使用
    public void RecordMemoryUsage()
    {
        var options = new GaugeOptions
        {
            Name = "process_working_set_bytes"
        };
        _metrics.Measure.Gauge.SetValue(options, GC.GetTotalMemory(false));
    }
}

// 启动配置
var builder = WebApplication.CreateBuilder();

// 配置AppMetrics
builder.Services.AddMetrics(metrics =>
{
    metrics.Configuration.Configure(options =>
    {
        options.GlobalTags.Add("host", Environment.MachineName);
        options.Enabled = true;
        options.ReportingEnabled = true;
    });
});

// 添加Prometheus格式支持
builder.Services.AddMetricsEndpoints(options =>
{
    options.MetricsEndpointOutputFormatter = new MetricsPrometheusTextOutputFormatter();
});

var app = builder.Build();

// 启用指标端点
app.UseMetricsAllEndpoints();
app.UseMetricsAllMiddleware();

app.MapGet("/", () => "AppMetrics Monitoring Ready");
app.Run();