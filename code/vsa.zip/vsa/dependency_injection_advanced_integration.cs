#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.Extensions.DependencyInjection@8.0.0
#:package Scrutor@4.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Microsoft.Extensions.DependencyInjection;
using Scrutor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// 1. 基础服务注册示例
public interface IService { }
public class Service : IService { }

// 2. 装饰器模式示例
public interface IDecoratedService { }
public class DecoratedService : IDecoratedService { }
public class Decorator : IDecoratedService
{
    private readonly IDecoratedService _decorated;
    public Decorator(IDecoratedService decorated) => _decorated = decorated;
}

// 3. 程序集扫描注册示例
public interface IScannedService { }
public class ScannedService : IScannedService { }

// 4. 工厂模式示例
public interface IFactoryService { }
public class FactoryService : IFactoryService 
{
    private readonly string _param;
    public FactoryService(string param) => _param = param;
}

// 5. 泛型服务注册示例
public interface IGenericService<T> { }
public class GenericService<T> : IGenericService<T> { }

// 6. 命名服务注册示例
public interface INamedService { string Name { get; } }
public class NamedServiceA : INamedService { public string Name => "A"; }
public class NamedServiceB : INamedService { public string Name => "B"; }

// 7. 验证服务注册示例
public interface IValidatedService { }
public class ValidatedService : IValidatedService { }

// 8. 生命周期事件示例
public class LifetimeEventsService : IDisposable
{
    public LifetimeEventsService() => Console.WriteLine("Service created");
    public void Dispose() => Console.WriteLine("Service disposed");
}

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddAdvancedDIFeatures(this IServiceCollection services)
    {
        // 1. 基础服务注册
        services.AddTransient<IService, Service>();
        services.AddScoped<IService, Service>();
        services.AddSingleton<IService, Service>();

        // 2. 装饰器模式
        services.AddTransient<IDecoratedService, DecoratedService>();
        services.Decorate<IDecoratedService, Decorator>();

        // 3. 程序集扫描注册
        services.Scan(scan => scan
            .FromAssemblyOf<IScannedService>()
            .AddClasses(classes => classes.AssignableTo<IScannedService>())
            .AsImplementedInterfaces()
            .WithTransientLifetime());

        // 4. 工厂模式
        services.AddTransient<IFactoryService>(provider => 
            new FactoryService("factory-param"));

        // 5. 泛型服务注册
        services.AddTransient(typeof(IGenericService<>), typeof(GenericService<>));

        // 6. 命名服务注册
        services.AddTransient<INamedService, NamedServiceA>();
        services.AddTransient<INamedService, NamedServiceB>();

        // 7. 验证服务注册
        services.AddTransient<IValidatedService, ValidatedService>();

        // 8. 生命周期事件
        services.AddTransient<LifetimeEventsService>();

        return services;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        var services = new ServiceCollection();
        services.AddAdvancedDIFeatures();

        var provider = services.BuildServiceProvider();
        
        // 演示命名服务解析
        var namedServices = provider.GetServices<INamedService>().ToList();
        Console.WriteLine($"Found {namedServices.Count} named services");
        
        // 演示泛型服务解析
        var genericService = provider.GetService<IGenericService<string>>();
        Console.WriteLine($"Generic service resolved: {genericService != null}");
        
        // 演示装饰器模式
        var decoratedService = provider.GetService<IDecoratedService>();
        Console.WriteLine($"Decorated service resolved: {decoratedService != null}");
        
        // 演示生命周期事件
        using (var scope = provider.CreateScope())
        {
            var lifetimeService = scope.ServiceProvider.GetService<LifetimeEventsService>();
        }
    }
}