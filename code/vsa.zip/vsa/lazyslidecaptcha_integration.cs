#:sdk Microsoft.NET.Sdk.Web
#:package LazySlideCaptcha@1.2.0
#:package Microsoft.Extensions.Caching.Memory@8.0.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0

using System.Buffers;
using System.Drawing;
using System.Threading.Channels;
using LazySlideCaptcha;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.ObjectPool;
using Microsoft.Extensions.Options;

public enum CaptchaMode
{
    Slide = 0,
    Rotate = 1,
    Puzzle = 2
}

public class CaptchaOptions
{
    public int Width { get; set; } = 320;
    public int Height { get; set; } = 160;
    public int ExpirySeconds { get; set; } = 300;
    public int MaxAttempts { get; set; } = 3;
    public bool EnableDistributedCache { get; set; } = false;
    public bool EnablePerformanceMetrics { get; set; } = false;
    public CaptchaMode Mode { get; set; } = CaptchaMode.Slide;
    public int NoiseLevel { get; set; } = 3;
}

public record CaptchaMetrics
{
    public long TotalRequests { get; init; }
    public long FailedAttempts { get; init; }
    public double AverageGenerationTimeMs { get; init; }
    public double AverageValidationTimeMs { get; init; }
}

public interface ICaptchaService
{
    Task<CaptchaData> GenerateAsync(string sessionId);
    Task<bool> ValidateAsync(string sessionId, int position);
    CaptchaMetrics GetMetrics();
}

public class CaptchaService : ICaptchaService
{
    private readonly IMemoryCache _cache;
    private readonly ObjectPool<Bitmap> _bitmapPool;
    private readonly Channel<CaptchaGenerator> _generatorChannel;
    private readonly CaptchaOptions _options;

    public CaptchaService(
        IMemoryCache cache,
        ObjectPool<Bitmap> bitmapPool,
        IOptions<CaptchaOptions> options)
    {
        _cache = cache;
        _bitmapPool = bitmapPool;
        _options = options.Value;
        
        _generatorChannel = Channel.CreateBounded<CaptchaGenerator>(
            new BoundedChannelOptions(Environment.ProcessorCount)
            {
                FullMode = BoundedChannelFullMode.Wait,
                SingleReader = true,
                SingleWriter = false
            });

        // Initialize generator workers
        for (int i = 0; i < Environment.ProcessorCount; i++)
        {
            _generatorChannel.Writer.TryWrite(new CaptchaGenerator());
        }
    }

    public async Task<CaptchaData> GenerateAsync(string sessionId)
    {
        var bitmap = _bitmapPool.Get();
        var generator = await _generatorChannel.Reader.ReadAsync();
        
        try
        {
            var data = generator.Generate(bitmap, _options.Width, _options.Height);
            _cache.Set(sessionId, data, TimeSpan.FromSeconds(_options.ExpirySeconds));
            return data;
        }
        finally
        {
            _bitmapPool.Return(bitmap);
            _generatorChannel.Writer.TryWrite(generator);
        }
    }

    public Task<bool> ValidateAsync(string sessionId, int position)
    {
        if (!_cache.TryGetValue(sessionId, out CaptchaData data))
            return Task.FromResult(false);

        _cache.Remove(sessionId);
        return Task.FromResult(Math.Abs(data.Position - position) < 5);
    }
}

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddLazySlideCaptcha(
        this IServiceCollection services,
        Action<CaptchaOptions> configure)
    {
        services.Configure(configure);
        
        services.AddSingleton<ObjectPool<Bitmap>>(sp =>
        {
            var policy = new BitmapPooledObjectPolicy(
                sp.GetRequiredService<IOptions<CaptchaOptions>>().Value.Width,
                sp.GetRequiredService<IOptions<CaptchaOptions>>().Value.Height);
            return new DefaultObjectPool<Bitmap>(policy, Environment.ProcessorCount * 2);
        });
        
        services.AddSingleton<ICaptchaService, CaptchaService>();
        
        var options = new CaptchaOptions();
        configure(options);
        
        if (options.EnableDistributedCache)
        {
            services.AddStackExchangeRedisCache(opt =>
            {
                opt.Configuration = "localhost";
                opt.InstanceName = "Captcha:";
            });
        }
        
        if (options.EnablePerformanceMetrics)
        {
            services.AddSingleton<CaptchaMetrics>();
        }
        
        return services;
    }
}

internal class BitmapPooledObjectPolicy : IPooledObjectPolicy<Bitmap>
{
    private readonly int _width;
    private readonly int _height;

    public BitmapPooledObjectPolicy(int width, int height)
    {
        _width = width;
        _height = height;
    }

    public Bitmap Create() => new Bitmap(_width, _height);
    
    public bool Return(Bitmap obj)
    {
        using var g = Graphics.FromImage(obj);
        g.Clear(Color.White);
        return true;
    }
}