#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.Extensions.DependencyInjection@8.0.0
#:package Microsoft.Extensions.Options@8.0.0
#:package Microsoft.Extensions.Configuration@8.0.0
#:package Scrutor@4.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Scrutor;

var builder = WebApplication.CreateBuilder(args);

// 1. 基础服务注册
builder.Services.AddTransient<ITransientService, TransientService>();
builder.Services.AddScoped<IScopedService, ScopedService>();
builder.Services.AddSingleton<ISingletonService, SingletonService>();

// 2. 选项模式集成
builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));

// 3. 装饰器模式
builder.Services.AddTransient<IDecoratedService, DecoratedService>()
    .Decorate<IDecoratedService, DecoratorService>();

// 4. 程序集扫描注册 (使用Scrutor)
builder.Services.Scan(scan => scan
    .FromAssemblyOf<Program>()
    .AddClasses(classes => classes.AssignableTo<IService>())
    .AsImplementedInterfaces()
    .WithScopedLifetime());

// 5. 工厂模式
builder.Services.AddTransient<IServiceFactory>(provider => 
    new ServiceFactory(provider.GetRequiredService<IServiceProvider>()));

// 6. 泛型服务注册
builder.Services.AddSingleton(typeof(IRepository<>), typeof(Repository<>));

// 7. 命名服务注册
builder.Services.AddTransient<INamedService, NamedServiceA>("ServiceA");
builder.Services.AddTransient<INamedService, NamedServiceB>("ServiceB");

// 8. 验证服务注册
builder.Services.AddOptions<AppSettings>()
    .ValidateDataAnnotations()
    .ValidateOnStart();

// 9. 生命周期事件
builder.Services.AddHostedService<AppLifetimeEvents>();

var app = builder.Build();

app.MapGet("/", (IServiceProvider provider) => 
{
    // 演示服务解析
    var transient1 = provider.GetRequiredService<ITransientService>();
    var transient2 = provider.GetRequiredService<ITransientService>();
    
    var scoped1 = provider.GetRequiredService<IScopedService>();
    var scoped2 = provider.GetRequiredService<IScopedService>();
    
    var singleton1 = provider.GetRequiredService<ISingletonService>();
    var singleton2 = provider.GetRequiredService<ISingletonService>();
    
    var decorated = provider.GetRequiredService<IDecoratedService>();
    
    var genericRepo = provider.GetRequiredService<IRepository<string>>();
    
    var namedServiceA = provider.GetRequiredServices<INamedService>()
        .First(s => s.GetType() == typeof(NamedServiceA));
    
    return Results.Ok(new 
    {
        TransientSame = transient1 == transient2,
        ScopedSame = scoped1 == scoped2,
        SingletonSame = singleton1 == singleton2,
        DecoratedResult = decorated.Execute(),
        GenericRepoType = genericRepo.GetType().Name,
        NamedServiceAType = namedServiceA.GetType().Name
    });
});

app.Run();

// 服务接口和实现
public interface ITransientService { Guid Id { get; } }
public class TransientService : ITransientService 
{ 
    public Guid Id { get; } = Guid.NewGuid(); 
}

public interface IScopedService { Guid Id { get; } }
public class ScopedService : IScopedService 
{ 
    public Guid Id { get; } = Guid.NewGuid(); 
}

public interface ISingletonService { Guid Id { get; } }
public class SingletonService : ISingletonService 
{ 
    public Guid Id { get; } = Guid.NewGuid(); 
}

// 装饰器模式示例
public interface IDecoratedService { string Execute(); }
public class DecoratedService : IDecoratedService 
{ 
    public string Execute() => "Core service"; 
}
public class DecoratorService : IDecoratedService 
{ 
    private readonly IDecoratedService _decorated;
    public DecoratorService(IDecoratedService decorated) => _decorated = decorated;
    public string Execute() => $"Decorated: {_decorated.Execute()}"; 
}

// 程序集扫描示例
public interface IService { }
public class ServiceA : IService { }
public class ServiceB : IService { }

// 工厂模式
public interface IServiceFactory 
{ 
    T Create<T>() where T : notnull; 
}
public class ServiceFactory : IServiceFactory 
{ 
    private readonly IServiceProvider _provider;
    public ServiceFactory(IServiceProvider provider) => _provider = provider;
    public T Create<T>() where T : notnull => _provider.GetRequiredService<T>(); 
}

// 泛型仓储
public interface IRepository<T> { }
public class Repository<T> : IRepository<T> { }

// 命名服务
public interface INamedService { }
public class NamedServiceA : INamedService { }
public class NamedServiceB : INamedService { }

// 选项配置
public class AppSettings 
{ 
    public string ConnectionString { get; set; } = string.Empty; 
}

// 生命周期事件
public class AppLifetimeEvents : IHostedService 
{
    private readonly IHostApplicationLifetime _appLifetime;
    
    public AppLifetimeEvents(IHostApplicationLifetime appLifetime) => _appLifetime = appLifetime;
    
    public Task StartAsync(CancellationToken cancellationToken)
    {
        _appLifetime.ApplicationStarted.Register(OnStarted);
        _appLifetime.ApplicationStopping.Register(OnStopping);
        _appLifetime.ApplicationStopped.Register(OnStopped);
        return Task.CompletedTask;
    }
    
    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    
    private void OnStarted() => Console.WriteLine("Application started");
    private void OnStopping() => Console.WriteLine("Application stopping");
    private void OnStopped() => Console.WriteLine("Application stopped");
}

// 扩展方法
public static class ServiceCollectionExtensions 
{
    public static IServiceCollection AddTransient<TService, TImplementation>(this IServiceCollection services, string name)
        where TService : class
        where TImplementation : class, TService
    {
        services.AddTransient<TImplementation>();
        services.AddTransient<TService>(provider => 
            provider.GetRequiredService<TImplementation>());
        return services;
    }
    
    public static IEnumerable<T> GetRequiredServices<T>(this IServiceProvider provider)
    {
        return provider.GetServices<T>().Where(s => s != null);
    }
}