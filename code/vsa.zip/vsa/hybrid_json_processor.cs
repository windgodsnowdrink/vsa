#:sdk Microsoft.NET.Sdk.Web
#:package System.Text.Json@8.0.0
#:package MessagePack@2.5.122
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Buffers;
using System.Text.Json;
using MessagePack;

public class HybridJsonProcessor
{
    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        WriteIndented = false,
        DefaultBufferSize = 4096
    };

    public byte[] SerializeToJson<T>(T value)
    {
        using var memory = MemoryPool<byte>.Shared.Rent(1024);
        var span = memory.Memory.Span;
        var writer = new Utf8JsonWriter(span);
        JsonSerializer.Serialize(writer, value, _jsonOptions);
        return span[..writer.BytesWritten].ToArray();
    }

    public T? DeserializeFromJson<T>(ReadOnlySpan<byte> data)
    {
        return JsonSerializer.Deserialize<T>(data, _jsonOptions);
    }
}