#:sdk Microsoft.NET.Sdk
#:package IP2Region@2.11.0
#:package Microsoft.Extensions.Caching.Memory@8.0.0
#:package Microsoft.Extensions.Options@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable

using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using IP2Region;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace Ip2RegionIntegration
{
    /*
    services.AddIp2Region(options => 
    {
        options.DbPath = "path/to/ip2region.db";
        options.CacheType = Ip2RegionCacheType.Memory;
        options.CacheExpiration = TimeSpan.FromHours(1);
        options.RedisConnectionString = "localhost:6379";
        options.EnableDistributedTracing = true;
        options.TracingEndpoint = "http://localhost:9411";
        options.ObjectPoolSize = 200; // 自定义对象池大小
    });
    */

    public enum Ip2RegionCacheType
    {
        None,
        Memory,
        Distributed
    }

    public class Ip2RegionOptions
    {
        public string DbPath { get; set; } = "ip2region.db";
        public Ip2RegionCacheType CacheType { get; set; } = Ip2RegionCacheType.Memory;
        public TimeSpan CacheExpiration { get; set; } = TimeSpan.FromMinutes(30);
        public string RedisConnectionString { get; set; }
        public bool EnableDistributedTracing { get; set; }
        public string TracingEndpoint { get; set; }
        public int ObjectPoolSize { get; set; } = 100;
    }

    public interface IIp2RegionService
    {
        Task<string> SearchAsync(string ip, CancellationToken cancellationToken = default);
        Task<RegionInfo> SearchWithInfoAsync(string ip, CancellationToken cancellationToken = default);
    }

    public class RegionInfo
    {
        public string Country { get; set; }
        public string Region { get; set; }
        public string Province { get; set; }
        public string City { get; set; }
        public string Isp { get; set; }
    }

    public class Ip2RegionService : IIp2RegionService, IDisposable
    {
        private readonly DbSearcher _searcher;
        private readonly IMemoryCache _memoryCache;
        private readonly Ip2RegionOptions _options;
        private readonly ObjectPool<DbSearcher> _searcherPool;
        private readonly ILogger<Ip2RegionService> _logger;
        private readonly ActivitySource _activitySource;

        public Ip2RegionService(
            IOptions<Ip2RegionOptions> options, 
            IMemoryCache memoryCache = null,
            ILogger<Ip2RegionService> logger = null,
            ObjectPool<DbSearcher> searcherPool = null)
        {
            _options = options.Value;
            _memoryCache = memoryCache;
            _logger = logger;
            _searcherPool = searcherPool;
            _activitySource = new ActivitySource(nameof(Ip2RegionService));
            
            if (!File.Exists(_options.DbPath))
                throw new FileNotFoundException($"IP数据库文件 {_options.DbPath} 不存在");
                
            _searcher = new DbSearcher(_options.DbPath);
        }

        public async Task<string> SearchAsync(string ip, CancellationToken cancellationToken = default)
        {
            using var activity = _options.EnableDistributedTracing ? 
                _activitySource.StartActivity($"{nameof(SearchAsync)}:{ip}") : null;
            
            if (_options.CacheType == Ip2RegionCacheType.None)
            {
                if (_searcherPool != null)
                {
                    var searcher = _searcherPool.Get();
                    try {
                        return searcher.MemorySearch(ip)?.Region;
                    }
                    finally {
                        _searcherPool.Return(searcher);
                    }
                }
                return _searcher.MemorySearch(ip)?.Region;
            }

            return await _memoryCache.GetOrCreateAsync(ip, async entry =>
            {
                entry.SetAbsoluteExpiration(_options.CacheExpiration);
                
                if (_searcherPool != null)
                {
                    var searcher = _searcherPool.Get();
                    try {
                        return await Task.FromResult(searcher.MemorySearch(ip)?.Region);
                    }
                    finally {
                        _searcherPool.Return(searcher);
                    }
                }
                
                return await Task.FromResult(_searcher.MemorySearch(ip)?.Region);
            });
        }

        public async Task<RegionInfo> SearchWithInfoAsync(string ip, CancellationToken cancellationToken = default)
        {
            var region = await SearchAsync(ip, cancellationToken);
            if (string.IsNullOrEmpty(region))
                return null;
                
            var parts = region.Split('|');
            return new RegionInfo
            {
                Country = parts[0],
                Region = parts[1],
                Province = parts[2],
                City = parts[3],
                Isp = parts[4]
            };
        }
    }

    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddIp2Region(this IServiceCollection services, Action<Ip2RegionOptions> configureOptions)
        {
            services.Configure(configureOptions);
            
            var options = new Ip2RegionOptions();
            configureOptions(options);
            
            if (options.CacheType == Ip2RegionCacheType.Memory)
                services.AddMemoryCache();
            
            // 添加对象池
            services.AddSingleton<ObjectPool<DbSearcher>>(sp => 
            {
                var policy = new DefaultPooledObjectPolicy<DbSearcher>(() => new DbSearcher(options.DbPath));
                return new DefaultObjectPool<DbSearcher>(policy, options.ObjectPoolSize);
            });
            
            // 添加分布式追踪
            if (options.EnableDistributedTracing)
            {
                services.AddOpenTelemetry()
                    .WithTracing(builder => 
                    {
                        builder.AddSource(nameof(Ip2RegionService));
                        builder.AddOtlpExporter(opt => 
                        {
                            opt.Endpoint = new Uri(options.TracingEndpoint);
                        });
                    });
            }
            
            services.AddSingleton<IIp2RegionService, Ip2RegionService>();
            
            return services;
        }
    }
    
    public void Dispose()
    {
        _searcher?.Dispose();
        _activitySource?.Dispose();
    }
}