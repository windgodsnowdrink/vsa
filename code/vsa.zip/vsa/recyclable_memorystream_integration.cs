// 文件头部包含完整版权和版本信息
#region 配置选项
/// <summary>
/// RecyclableMemoryStream配置选项
/// </summary>
public class RecyclableMemoryStreamOptions
{
    /// <summary>
    /// 块大小(字节)
    /// </summary>
    public int BlockSize { get; set; } = 1024 * 1024; // 默认1MB

    /// <summary>
    /// 大缓冲区大小(字节)
    /// </summary>
    public int LargeBufferSize { get; set; } = 8 * 1024 * 1024; // 默认8MB

    /// <summary>
    /// 最大自由大缓冲区数量
    /// </summary>
    public int MaximumFreeLargeBuffers { get; set; } = 4;

    /// <summary>
    /// 最大自由块数量
    /// </summary>
    public int MaximumFreeSmallBuffers { get; set; } = 256;

    /// <summary>
    /// 是否生成堆栈跟踪
    /// </summary>
    public bool GenerateCallStacks { get; set; } = false;

    /// <summary>
    /// 是否聚合缓冲区
    /// </summary>
    public bool AggressiveBufferReturn { get; set; } = true;

    /// <summary>
    /// 最大流容量(字节)
    /// </summary>
    public long MaximumStreamCapacity { get; set; } = 1024 * 1024 * 1024; // 默认1GB
}

#region 服务接口
/// <summary>
/// 内存流池服务接口
/// </summary>
public interface IMemoryStreamPoolService
{
    /// <summary>
    /// 获取内存流
    /// </summary>
    RecyclableMemoryStream GetStream();

    /// <summary>
    /// 获取带标签的内存流
    /// </summary>
    RecyclableMemoryStream GetStream(string tag);

    /// <summary>
    /// 获取带初始容量的内存流
    /// </summary>
    RecyclableMemoryStream GetStream(string tag, int requiredSize);

    /// <summary>
    /// 获取带初始缓冲区的内存流
    /// </summary>
    RecyclableMemoryStream GetStream(string tag, byte[] buffer);

    /// <summary>
    /// 获取带初始缓冲区和偏移量的内存流
    /// </summary>
    RecyclableMemoryStream GetStream(string tag, byte[] buffer, int offset, int count);
}

#region 实现类
/// <summary>
/// 内存流池服务实现
/// </summary>
public class MemoryStreamPoolService : IMemoryStreamPoolService, IDisposable
{
    private readonly RecyclableMemoryStreamManager _memoryManager;
    private readonly ILogger<MemoryStreamPoolService> _logger;

    public MemoryStreamPoolService(
        IOptions<RecyclableMemoryStreamOptions> options,
        ILogger<MemoryStreamPoolService> logger)
    {
        var opts = options.Value;
        _memoryManager = new RecyclableMemoryStreamManager(
            opts.BlockSize,
            opts.LargeBufferSize,
            opts.MaximumFreeLargeBuffers,
            opts.MaximumFreeSmallBuffers)
        {
            GenerateCallStacks = opts.GenerateCallStacks,
            AggressiveBufferReturn = opts.AggressiveBufferReturn,
            MaximumStreamCapacity = opts.MaximumStreamCapacity
        };
        _logger = logger;
    }

    public RecyclableMemoryStream GetStream() => _memoryManager.GetStream();

    public RecyclableMemoryStream GetStream(string tag) => _memoryManager.GetStream(tag);

    public RecyclableMemoryStream GetStream(string tag, int requiredSize) => 
        _memoryManager.GetStream(tag, requiredSize);

    public RecyclableMemoryStream GetStream(string tag, byte[] buffer) => 
        _memoryManager.GetStream(tag, buffer);

    public RecyclableMemoryStream GetStream(string tag, byte[] buffer, int offset, int count) => 
        _memoryManager.GetStream(tag, buffer, offset, count);

    public void Dispose()
    {
        _memoryManager.FreeLargePoolBuffers();
        _memoryManager.FreeSmallPoolBuffers();
    }
}

#region DI扩展
/// <summary>
/// 服务集合扩展方法
/// </summary>
public static class RecyclableMemoryStreamExtensions
{
    /// <summary>
    /// 添加RecyclableMemoryStream服务
    /// </summary>
    public static IServiceCollection AddRecyclableMemoryStreamServices(
        this IServiceCollection services,
        Action<RecyclableMemoryStreamOptions> configureOptions = null)
    {
        services.AddOptions<RecyclableMemoryStreamOptions>()
            .Configure(configureOptions ?? (opts => { }))
            .ValidateDataAnnotations();

        services.AddSingleton<IMemoryStreamPoolService, MemoryStreamPoolService>();
        return services;
    }
}

#region 示例用法
/// <summary>
/// 演示如何使用内存流池服务
/// </summary>
public static class RecyclableMemoryStreamExample
{
    public static void Demo()
    {
        var services = new ServiceCollection();
        services.AddLogging();
        services.AddRecyclableMemoryStreamServices(opts =>
        {
            opts.BlockSize = 128 * 1024; // 128KB
            opts.LargeBufferSize = 2 * 1024 * 1024; // 2MB
            opts.MaximumFreeLargeBuffers = 8;
        });

        using var provider = services.BuildServiceProvider();
        var streamPool = provider.GetRequiredService<IMemoryStreamPoolService>();

        // 使用池化内存流
        using var stream = streamPool.GetStream("demo");
        var buffer = Encoding.UTF8.GetBytes("Hello, RecyclableMemoryStream!");
        stream.Write(buffer, 0, buffer.Length);

        Console.WriteLine("RecyclableMemoryStream demo completed.");
    }
}