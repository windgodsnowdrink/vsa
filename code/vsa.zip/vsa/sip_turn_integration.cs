#:sdk Microsoft.NET.Sdk.Web
#:package SIPSorcery@6.0.0
#:package SIPSorcery.Net@6.0.0
#:package System.Threading.Channels@8.0.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Buffers;
using System.Net;
using System.Threading.Channels;
using SIPSorcery.SIP;
using SIPSorcery.Net;

// 1. TURN客户端实现(高性能优化)
[SkipLocalsInit]
public sealed class TURNClient : IDisposable
{
    private readonly ThreadLocal<Span<byte>> _buffer;
    private readonly ObjectPool<TURNMessage> _messagePool;
    private readonly ChannelWriter<TURNResult> _resultChannel;
    
    public TURNClient(Channel<TURNResult> resultChannel)
    {
        _buffer = new(() => stackalloc byte[1024]);
        _messagePool = new DefaultObjectPool<TURNMessage>(
            new TURNMessagePooledPolicy(), 1000);
        _resultChannel = resultChannel.Writer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe Task AllocateAsync(IPEndPoint turnServer, string username, string password)
    {
        var buffer = _buffer.Value;
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0) // Cache-line对齐
            {
                var message = _messagePool.Get();
                try
                {
                    // 构建TURN分配请求
                    message.Header = new TURNHeader()
                    {
                        MessageType = TURNMessageTypes.AllocateRequest,
                        TransactionId = Guid.NewGuid().ToString()[..12]
                    };
                    
                    // 添加认证信息
                    message.AddAttribute(new TURNAttribute(TURNAttributeTypes.Username, username));
                    message.AddAttribute(new TURNAttribute(TURNAttributeTypes.Password, password));
                    
                    // 发送请求并处理响应
                    // ... TURN协议处理逻辑 ...
                    
                    _resultChannel.TryWrite(new TURNResult(turnServer, message));
                }
                finally
                {
                    _messagePool.Return(message);
                }
            }
        }
        return Task.CompletedTask;
    }
}

// 2. SIP信令引擎(集成TURN)
[SkipLocalsInit]
public sealed class SIPSignalingEngine : ISIPSignalingEngine
{
    private readonly SIPTransport _transport;
    private readonly ChannelWriter<SIPEvent> _eventChannel;
    private readonly ThreadLocal<Span<byte>> _buffer;
    private readonly TURNClient _turnClient;
    
    public SIPSignalingEngine(
        SIPTransport transport,
        Channel<SIPEvent> eventChannel,
        TURNClient turnClient)
    {
        _transport = transport;
        _eventChannel = eventChannel.Writer;
        _buffer = new(() => stackalloc byte[2048]);
        _turnClient = turnClient;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task ProcessRequestAsync(SIPRequest request)
    {
        Span<byte> buffer = _buffer.Value;
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0)
            {
                // 处理SIP请求前先建立TURN通道
                await _turnClient.AllocateAsync(
                    new IPEndPoint(IPAddress.Parse("turn.sipsorcery.com"), 3478),
                    "username", "password");
                
                // ... SIP消息处理逻辑 ...
                await _eventChannel.WriteAsync(new SIPEvent(request));
            }
        }
    }
}

// 3. 主程序集成
var builder = WebApplication.CreateBuilder();

// 配置高性能通道
var sipChannel = Channel.CreateBounded<SIPEvent>(10000);
var turnChannel = Channel.CreateBounded<TURNResult>(10000);

// 注册TURN客户端
builder.Services.AddSingleton<TURNClient>(sp => 
    new TURNClient(turnChannel));

// 注册SIP引擎
builder.Services.AddSingleton<ISIPSignalingEngine>(sp => 
    new SIPSignalingEngine(
        new SIPTransport(),
        sipChannel,
        sp.GetRequiredService<TURNClient>()));

// 配置后台服务
builder.Services.AddHostedService<SIPEventProcessor>();

var app = builder.Build();
app.MapGet("/", () => "SIP/TURN Integration Ready");
app.Run();