using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Hosting;
using Wolverine;
using System.Buffers;
using System.Runtime.CompilerServices;

public class CacheHeartbeatService : BackgroundService
{
    private readonly HybridCache _cache;
    private readonly IMessageBus _bus;
    private readonly TimeWheel _timeWheel;
    private const string HeartbeatKey = "heartbeat";
    private DateTimeOffset _lastHeartbeat = DateTimeOffset.MinValue;
    
    public CacheHeartbeatService(HybridCache cache, IMessageBus bus, IOptions<CacheHeartbeatOptions> options)
    {
        _cache = cache;
        _bus = bus;
        _timeWheel = new TimeWheel(TimeSpan.FromMilliseconds(100), 30);
    }

    public void RecordHeartbeat()
    {
        _lastHeartbeat = DateTimeOffset.UtcNow;
        _cache.Set(HeartbeatKey, _lastHeartbeat, TimeSpan.FromSeconds(5));
    }

    private async void CheckHeartbeat(object state)
    {
        var lastStored = await _cache.TryGetValueAsync<DateTimeOffset>(HeartbeatKey);
        if (!lastStored.HasValue || (DateTimeOffset.UtcNow - lastStored.Value).TotalSeconds > 3)
        {
            // 执行业务逻辑
            OnHeartbeatTimeout();
        }
    }

    protected virtual async Task OnHeartbeatTimeout(CancellationToken cancellationToken)
    {
        await _bus.PublishAsync(new HeartbeatTimeoutEvent(HeartbeatKey), cancellationToken);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(100));
        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            _timeWheel.Advance();
            await CheckHeartbeat(stoppingToken);
        }
    }

    private async Task CheckHeartbeat(CancellationToken cancellationToken)
    {
        var lastStored = await _cache.TryGetValueAsync<DateTimeOffset>(HeartbeatKey, cancellationToken);
        if (!lastStored.HasValue || (DateTimeOffset.UtcNow - lastStored.Value).TotalSeconds > 3)
        {
            await OnHeartbeatTimeout(cancellationToken);
        }
    }
}

public class CacheHeartbeatOptions
{
    public int HeartbeatCheckIntervalSeconds { get; set; } = 1;
}

public class HeartbeatTimeoutEvent
{
    public string Key { get; }
    public HeartbeatTimeoutEvent(string key) => Key = key;
}

public class TimeWheel
{
    private readonly TimeSpan _slotDuration;
    private readonly int _slotCount;
    private readonly MemoryPool<byte> _memoryPool = MemoryPool<byte>.Shared;
    private int _currentSlot;

    public TimeWheel(TimeSpan slotDuration, int slotCount)
    {
        _slotDuration = slotDuration;
        _slotCount = slotCount;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public void Advance()
    {
        _currentSlot = (_currentSlot + 1) % _slotCount;
    }
}

public static class CacheHeartbeatExtensions
{
    public static IServiceCollection AddCacheHeartbeat(this IServiceCollection services, Action<CacheHeartbeatOptions> configureOptions)
    {
        services.Configure(configureOptions);
        services.AddSingleton<CacheHeartbeatService>();
        services.AddWolverine(opts =>
        {
            opts.Discovery.IncludeAssembly(typeof(CacheHeartbeatExtensions).Assembly);
        });
        return services;
    }
}