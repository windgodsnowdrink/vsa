#:sdk Microsoft.NET.Sdk.Web
#:package Minio@7.1.0
#:package System.IO.Pipelines@7.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable

using System.IO.Pipelines;
using Microsoft.AspNetCore.Mvc;

/*
# 多线程分块上传
curl -X POST -F "file=@largefile.zip" http://localhost/api/minioupload/multipart

# 流式上传
curl -X POST -F "file=@largefile.zip" http://localhost/api/minioupload/stream
*/
[ApiController]
[Route("api/[controller]")]
public class MinioUploadController : ControllerBase
{
    private readonly AdvancedMinioService _minioService;
    private readonly ObjectPool<Memory<byte>> _bufferPool;

    public MinioUploadController(
        AdvancedMinioService minioService,
        ObjectPool<Memory<byte>> bufferPool)
    {
        _minioService = minioService;
        _bufferPool = bufferPool;
    }

    // 多线程分块上传接口
    [HttpPost("multipart")]
    public async Task<IActionResult> MultipartUpload(
        [FromForm] IFormFile file,
        [FromQuery] string bucket = "default")
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded");

        using var stream = file.OpenReadStream();
        await _minioService.MultiThreadUploadAsync(bucket, file.FileName, stream);
        
        return Ok(new { file.FileName, file.Length });
    }

    // 流式上传接口
    [HttpPost("stream")]
    public async Task<IActionResult> StreamUpload(
        [FromForm] IFormFile file,
        [FromQuery] string bucket = "default")
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded");

        var pipe = new Pipe();
        var writingTask = WriteToPipeAsync(file, pipe.Writer);
        var uploadingTask = _minioService.StreamUploadAsync(bucket, file.FileName, pipe.Reader);

        await Task.WhenAll(writingTask, uploadingTask);
        return Ok(new { file.FileName, file.Length });
    }

    [HttpPost("batch")]
    public async Task<IActionResult> BatchUpload(
        [FromForm] IEnumerable<IFormFile> files,
        [FromQuery] string bucket = "default")
    {
        if (files == null || !files.Any())
            return BadRequest("No files uploaded");

        var tasks = files.Select(file => 
        {
            using var stream = file.OpenReadStream();
            return _minioService.MultiThreadUploadAsync(bucket, file.FileName, stream);
        });

        await Task.WhenAll(tasks);
        return Ok(new { Count = files.Count() });
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task WriteToPipeAsync(IFormFile file, PipeWriter writer)
    {
        var buffer = _bufferPool.Get();
        try
        {
            using var stream = file.OpenReadStream();
            while (true)
            {
                var bytesRead = await stream.ReadAsync(buffer);
                if (bytesRead == 0) break;

                var memory = writer.GetMemory(buffer.Length);
                buffer.CopyTo(memory.Span);
                writer.Advance(bytesRead);

                var result = await writer.FlushAsync();
                if (result.IsCompleted) break;
            }
        }
        finally
        {
            _bufferPool.Return(buffer);
            await writer.CompleteAsync();
        }
    }

    // 添加以下新方法到MinioUploadController类中
    
    // 1. 带进度回调的分块上传
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    [HttpPost("multipart-with-progress")]
    public async Task<IActionResult> MultipartUploadWithProgress(
        [FromForm] IFormFile file,
        [FromQuery] string bucket = "default",
        [FromServices] IHubContext<UploadProgressHub> hubContext = null)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded");
    
        var uploadId = Guid.NewGuid().ToString();
        using var stream = file.OpenReadStream();
        
        var progressChannel = Channel.CreateBounded<UploadProgress>(new BoundedChannelOptions(1000)
        {
            SingleReader = true,
            FullMode = BoundedChannelFullMode.DropOldest
        });
    
        // 启动后台进度推送任务
        _ = Task.Run(async () => 
        {
            await foreach (var progress in progressChannel.Reader.ReadAllAsync())
            {
                await hubContext.Clients.Group(uploadId)
                    .SendAsync("ProgressUpdate", new 
                    {
                        UploadId = uploadId,
                        progress.BytesTransferred,
                        progress.Percentage
                    });
            }
        });
    
        await _minioService.MultiThreadUploadWithProgressAsync(
            bucket, 
            file.FileName, 
            stream,
            progressChannel.Writer);
    
        return Ok(new { UploadId = uploadId, file.FileName });
    }
    
    // 2. 加密上传接口
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    [HttpPost("encrypted")]
    public async Task<IActionResult> EncryptedUpload(
        [FromForm] EncryptedFileRequest request,
        [FromQuery] string bucket = "default")
    {
        using var cryptoStream = new CryptoStream(
            request.File.OpenReadStream(),
            _cryptoService.CreateEncryptor(),
            CryptoStreamMode.Read);
    
        await _minioService.StreamUploadAsync(
            bucket,
            request.File.FileName,
            PipeReader.Create(cryptoStream));
    
        return Ok(new { request.File.FileName });
    }
    
    // 3. 断点续传接口
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    [HttpPost("resumable")]
    public async Task<IActionResult> ResumableUpload(
        [FromForm] ResumableUploadRequest request,
        [FromQuery] string bucket = "default")
    {
        var uploadContext = await _minioService.GetUploadContextAsync(
            bucket, 
            request.File.FileName,
            request.UploadId);
    
        using var stream = request.File.OpenReadStream();
        stream.Seek(uploadContext.CompletedSize, SeekOrigin.Begin);
    
        await _minioService.ResumeMultipartUploadAsync(
            bucket,
            request.File.FileName,
            request.UploadId,
            stream,
            uploadContext.CompletedParts);
    
        return Ok(new { request.File.FileName, request.UploadId });
    }
    
    // 4. 批量删除接口
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    [HttpDelete("batch")]
    public async Task<IActionResult> BatchDelete(
        [FromBody] BatchDeleteRequest request,
        [FromQuery] string bucket = "default")
    {
        var tasks = request.ObjectKeys.Select(key => 
            _minioService.DeleteObjectAsync(bucket, key));
    
        await Task.WhenAll(tasks);
        return Ok(new { DeletedCount = request.ObjectKeys.Count() });
    }
    
    // 添加以下DTO类
    public record UploadProgress(long BytesTransferred, double Percentage);
    public record EncryptedFileRequest(IFormFile File, string EncryptionKey);
    public record ResumableUploadRequest(IFormFile File, string UploadId);
    public record BatchDeleteRequest(IEnumerable<string> ObjectKeys);

    // 添加下载接口
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    [HttpGet("download")]
    public async Task<IActionResult> Download(
        [FromQuery] string objectName,
        [FromQuery] string bucket = "default",
        [FromQuery] bool useCache = true)
    {
        try
        {
            var result = await _minioService.DownloadFileAsync(bucket, objectName, useCache);
            return File(result, "application/octet-stream", objectName);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 添加缓存管理接口
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    [HttpPost("cache/clear")]
    public async Task<IActionResult> ClearCache(
        [FromBody] CacheClearRequest request,
        [FromQuery] string bucket = "default")
    {
        await _minioService.ClearCacheAsync(bucket, request.ObjectNames);
        return Ok(new { ClearedCount = request.ObjectNames.Count() });
    }

    // 添加预加载缓存接口
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    [HttpPost("cache/preload")]
    public async Task<IActionResult> PreloadCache(
        [FromBody] CachePreloadRequest request,
        [FromQuery] string bucket = "default")
    {
        var tasks = request.ObjectNames.Select(name => 
            _minioService.PreloadCacheAsync(bucket, name));
        
        await Task.WhenAll(tasks);
        return Ok(new { PreloadedCount = request.ObjectNames.Count() });
    }

    // 添加以下DTO类
    public record CacheClearRequest(IEnumerable<string> ObjectNames);
    public record CachePreloadRequest(IEnumerable<string> ObjectNames);
}