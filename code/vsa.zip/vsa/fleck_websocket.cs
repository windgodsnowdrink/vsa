#:sdk Microsoft.NET.Sdk.Web
#:package Fleck@2.0.0
#:package System.Threading.Channels@8.0.0
#:package MessagePack@2.5.122
#:package Microsoft.Extensions.Caching.StackExchangeRedis@8.0.0
#:package Microsoft.AspNetCore.Authentication.JwtBearer@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Fleck;
using System.Threading.Channels;
using MessagePack;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder();

// 1. 横向扩展支持 - Redis分布式缓存
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = "localhost:6379";
    options.InstanceName = "FleckWebSocket_";
});

// 2. 安全认证 - JWT Bearer
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(5)
        };
    });

// 3. 高性能通道 (RingBuffer + Disruptor模式)
var messageChannel = Channel.CreateBounded<WebSocketMessage>(
    new BoundedChannelOptions(10000)
    {
        SingleReader = true,
        AllowSynchronousContinuations = true,
        FullMode = BoundedChannelFullMode.Wait
    });

// 4. 消息持久化处理器
builder.Services.AddSingleton<IMessagePersistence>(sp =>
    new RedisMessagePersistence(
        sp.GetRequiredService<IDistributedCache>(),
        new ThreadLocal<Span<byte>>(() => stackalloc byte[1024])));

// 5. 零拷贝处理器
builder.Services.AddSingleton<IMessageProcessor>(sp => 
    new FleckMessageProcessor(
        messageChannel,
        sp.GetRequiredService<IMessagePersistence>(),
        new ThreadLocal<Span<byte>>(() => stackalloc byte[1024])));

var app = builder.Build();

// 6. Fleck WebSocket服务器
var server = new WebSocketServer("ws://0.0.0.0:8181");
server.Start(socket =>
{
    socket.OnOpen = () => Console.WriteLine($"Connection opened: {socket.ConnectionInfo.Id}");
    socket.OnClose = () => Console.WriteLine($"Connection closed: {socket.ConnectionInfo.Id}");
    socket.OnMessage = message => ProcessMessage(socket, message);
});

app.MapGet("/", () => "Fleck WebSocket Ready");
app.Run();

[MethodImpl(MethodImplOptions.AggressiveOptimization)]
private unsafe void ProcessMessage(IWebSocketConnection socket, string message)
{
    Span<byte> buffer = stackalloc byte[1024];
    fixed (byte* ptr = buffer)
    {
        if ((long)ptr % 64 == 0)
        {
            var msg = new WebSocketMessage
            {
                ConnectionId = socket.ConnectionInfo.Id,
                Payload = MessagePackSerializer.Serialize(message),
                Timestamp = DateTimeOffset.UtcNow
            };
            messageChannel.Writer.TryWrite(msg);
        }
    }
}

// 消息持久化接口
public interface IMessagePersistence
{
    Task PersistAsync(WebSocketMessage message);
    Task<IEnumerable<WebSocketMessage>> RetrieveAsync(Guid connectionId);
}

// Redis消息持久化实现
[SkipLocalsInit]
public class RedisMessagePersistence : IMessagePersistence
{
    private readonly IDistributedCache _cache;
    private readonly ThreadLocal<Span<byte>> _buffer;

    public RedisMessagePersistence(IDistributedCache cache, ThreadLocal<Span<byte>> buffer)
    {
        _cache = cache;
        _buffer = buffer;
    }

    public async Task PersistAsync(WebSocketMessage message)
    {
        var key = $"ws:msg:{message.ConnectionId}:{message.Timestamp.ToUnixTimeMilliseconds()}";
        var value = MessagePackSerializer.Serialize(message);
        await _cache.SetAsync(key, value);
    }

    public async Task<IEnumerable<WebSocketMessage>> RetrieveAsync(Guid connectionId)
    {
        // 实现从Redis检索消息的逻辑
    }
}

// 增强版消息处理器
[SkipLocalsInit]
public class FleckMessageProcessor : IMessageProcessor
{
    private readonly ChannelReader<WebSocketMessage> _reader;
    private readonly IMessagePersistence _persistence;
    private readonly ThreadLocal<Span<byte>> _buffer;
    
    public FleckMessageProcessor(
        Channel<WebSocketMessage> channel, 
        IMessagePersistence persistence,
        ThreadLocal<Span<byte>> buffer)
    {
        _reader = channel.Reader;
        _persistence = persistence;
        _buffer = buffer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe void StartProcessing(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            Span<byte> buffer = _buffer.Value;
            fixed (byte* ptr = buffer)
            {
                if ((long)ptr % 64 == 0 && _reader.TryRead(out var message))
                {
                    // 持久化消息
                    _ = _persistence.PersistAsync(message);
                    
                    // SIMD优化处理
                }
            }
        }
    }
}

// 增强版WebSocket消息
[MessagePackObject]
public class WebSocketMessage
{
    [Key(0)]
    public Guid ConnectionId { get; set; }
    
    [Key(1)]
    public byte[] Payload { get; set; }
    
    [Key(2)]
    public DateTimeOffset Timestamp { get; set; }
    
    [Key(3)]
    public ClaimsPrincipal? User { get; set; }
    
    [Key(4)]
    public Dictionary<string, string>? Metadata { get; set; }
}