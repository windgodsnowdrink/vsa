#:sdk Microsoft.NET.Sdk.Web
#:package Grafana.SDK@4.0.0
#:package Microsoft.Extensions.Http.Polly@8.0.0
#:package Prometheus.Client.AspNetCore@5.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Diagnostics;
using System.Net.Http;
using Grafana.SDK;
using Grafana.SDK.Models;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Prometheus.Client.AspNetCore;

public static class GrafanaExtensions
{
    public static IServiceCollection AddGrafanaIntegration(
        this IServiceCollection services,
        Action<GrafanaOptions> configureOptions)
    {
        services.Configure(configureOptions);
        
        services.AddMemoryCache();
        services.AddHttpClient<GrafanaClient>()
            .AddPolicyHandler(PollyExtensions.GetRetryPolicy())
            .AddPolicyHandler(PollyExtensions.GetCircuitBreakerPolicy());
        
        services.AddSingleton<IGrafanaDashboardManager, GrafanaDashboardManager>();
        services.AddHostedService<GrafanaInitializationService>();
        
        // 添加OpenTelemetry监控
        services.AddOpenTelemetry()
            .WithMetrics(metrics => metrics
                .AddMeter("Grafana.Integration")
                .AddPrometheusExporter());
        
        return services;
    }

    public static IApplicationBuilder UseGrafanaMetrics(this IApplicationBuilder app)
    {
        app.UsePrometheusServer();
        return app;
    }
}

public class GrafanaOptions
{
    public string ApiUrl { get; set; } = "http://localhost:3000";
    public string ApiKey { get; set; } = string.Empty;
    public List<DashboardTemplate> DefaultDashboards { get; set; } = new();
}

public class GrafanaClient
{
    private readonly HttpClient _httpClient;
    private readonly IOptions<GrafanaOptions> _options;
    private readonly Channel<DashboardTemplate> _dashboardChannel;
    private readonly IMemoryCache _cache;

    public GrafanaClient(
        HttpClient httpClient, 
        IOptions<GrafanaOptions> options,
        IMemoryCache cache)
    {
        _httpClient = httpClient;
        _options = options;
        _cache = cache;
        _dashboardChannel = Channel.CreateBounded<DashboardTemplate>(1000);
        _ = ProcessDashboardQueueAsync();
    }

    private async Task ProcessDashboardQueueAsync()
    {
        await foreach (var template in _dashboardChannel.Reader.ReadAllAsync())
        {
            await ProcessDashboardBatchAsync(template);
        }
    }

    private async Task ProcessDashboardBatchAsync(DashboardTemplate template)
    {
        var cacheKey = $"dashboard_{template.Title}";
        if (_cache.TryGetValue(cacheKey, out _)) return;

        using var aes = Aes.Create();
        aes.Key = Encoding.UTF8.GetBytes(_options.Value.ApiKey.PadRight(32).Substring(0, 32));
        aes.IV = new byte[16];

        var encryptedContent = EncryptDashboardContent(template, aes);
        await SendToGrafanaAsync(encryptedContent);

        _cache.Set(cacheKey, true, TimeSpan.FromMinutes(5));
    }

    public async Task EnsureDashboardAsync(DashboardTemplate template, CancellationToken ct)
    {
        // 实现仪表盘创建/更新逻辑
    }
}

public interface IGrafanaDashboardManager
{
    Task EnsureDashboardsAsync(CancellationToken ct);
}

public class GrafanaDashboardManager : IGrafanaDashboardManager
{
    private readonly GrafanaClient _client;
    private readonly IOptions<GrafanaOptions> _options;

    public GrafanaDashboardManager(GrafanaClient client, IOptions<GrafanaOptions> options)
    {
        _client = client;
        _options = options;
    }

    public async Task EnsureDashboardsAsync(CancellationToken ct)
    {
        foreach (var template in _options.Value.DefaultDashboards)
        {
            await _client.EnsureDashboardAsync(template, ct);
        }
    }
}

public class GrafanaInitializationService : BackgroundService
{
    private readonly IGrafanaDashboardManager _dashboardManager;

    public GrafanaInitializationService(IGrafanaDashboardManager dashboardManager)
    {
        _dashboardManager = dashboardManager;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await _dashboardManager.EnsureDashboardsAsync(stoppingToken);
    }
}

public static class PollyExtensions
{
    public static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(3, retryAttempt => 
                TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
    }
    
    public static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .CircuitBreakerAsync(5, TimeSpan.FromSeconds(30));
    }
}

// 示例使用
/*
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddGrafanaIntegration(options => {
    options.ApiKey = "your_api_key";
    options.DefaultDashboards.Add(new DashboardTemplate {
        Title = "API Metrics",
        Panels = new List<Panel> {
            new TimeSeriesPanel { Title = "Request Rate", Metrics = "rate(http_requests_total[1m])" },
            new TimeSeriesPanel { Title = "Error Rate", Metrics = "rate(http_errors_total[1m])" }
        }
    });
});

var app = builder.Build();
app.UseGrafanaMetrics();
app.Run();
*/