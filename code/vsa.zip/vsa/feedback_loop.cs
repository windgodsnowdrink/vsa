#:sdk Microsoft.NET.Sdk.Web
#:package System.Threading.Tasks.Dataflow@8.0.0

public class FeedbackProcessor
{
    private readonly TransformBlock<TodoEvent, TodoEvent> _initialProcessor;
    private readonly TransformBlock<TodoEvent, TodoEvent> _feedbackProcessor;
    private readonly BufferBlock<TodoEvent> _feedbackBuffer;

    public FeedbackProcessor()
    {
        _initialProcessor = new TransformBlock<TodoEvent, TodoEvent>(todo =>
        {
            // 初始处理逻辑
            return todo;
        });

        _feedbackProcessor = new TransformBlock<TodoEvent, TodoEvent>(todo =>
        {
            // 反馈处理逻辑
            return todo;
        });

        _feedbackBuffer = new BufferBlock<TodoEvent>();

        // 建立反馈循环
        _initialProcessor.LinkTo(_feedbackProcessor);
        _feedbackProcessor.LinkTo(_feedbackBuffer);
        _feedbackBuffer.LinkTo(_initialProcessor);
    }
}