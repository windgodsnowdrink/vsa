#:sdk Microsoft.NET.Sdk.Web
#:package Polly@8.0.0
#:package System.Threading.Channels@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Polly;
using System.Threading.Channels;

var builder = WebApplication.CreateBuilder();

// 弹性策略配置
builder.Services.AddRefitClient<IUserService>()
    .AddPolicyHandler(Policy<HttpResponseMessage>
        .Handle<HttpRequestException>()
        .OrResult(r => (int)r.StatusCode >= 500)
        .WaitAndRetryAsync(3, _ => TimeSpan.FromSeconds(1)))
    .AddPolicyHandler(Policy<HttpResponseMessage>
        .Handle<HttpRequestException>()
        .CircuitBreakerAsync(5, TimeSpan.FromSeconds(30)));

// 对象池优化
builder.Services.AddSingleton<ObjectPool<Memory<byte>>>(sp => 
    new DefaultObjectPool<Memory<byte>>(new MemoryPooledObjectPolicy(), 1000));