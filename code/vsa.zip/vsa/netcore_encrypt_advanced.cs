#:sdk Microsoft.NET.Sdk.Web
#:package NETCore.Encrypt@3.0.0
#:package System.Threading.Channels@7.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable

using System.Buffers;
using System.Runtime.CompilerServices;
using System.Threading;

[SkipLocalsInit]
public sealed class EncryptChannel : IAsyncDisposable
{
    // 1. 基于RingBuffer的批处理模式
    private const int BatchSize = 64;
    private readonly (string, string, TaskCompletionSource<string>)[] _batchBuffer = 
        new (string, string, TaskCompletionSource<string>)[BatchSize];
    
    // 2. Tiered Memory分层存储策略
    private readonly MemoryPool<byte> _hotMemoryPool = MemoryPool<byte>.Shared;
    private readonly MemoryPool<byte> _coldMemoryPool = new ColdMemoryPool();
    
    // 3. ThreadLocal线程专用内存池
    private static readonly ThreadLocal<Memory<byte>> _threadLocalBuffer = 
        new(() => MemoryPool<byte>.Shared.Rent(4096), trackAllValues: true);
    
    private readonly Channel<(string, string, TaskCompletionSource<string>)> _channel;
    private readonly CancellationTokenSource _cts;
    private readonly EncryptService _encryptService;
    private readonly TailLatencyOptimizer _latencyOptimizer;

    public EncryptChannel(EncryptService encryptService)
    {
        _encryptService = encryptService;
        _cts = new CancellationTokenSource();
        _latencyOptimizer = new TailLatencyOptimizer();
        
        _channel = Channel.CreateBounded<(string, string, TaskCompletionSource<string>)>(
            new BoundedChannelOptions(10_000)
            {
                SingleReader = true,
                FullMode = BoundedChannelFullMode.Wait
            });
        
        _ = Task.Run(ProcessQueueAsync);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async ValueTask<string> EnqueueAsync(string input, string key = null)
    {
        using var buffer = _hotMemoryPool.Rent(input.Length);
        input.AsSpan().CopyTo(buffer.Memory.Span);
        
        var tcs = new TaskCompletionSource<string>(
            TaskCreationOptions.RunContinuationsAsynchronously);
        
        await _channel.Writer.WriteAsync((input, key, tcs), _cts.Token);
        return await tcs.Task;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task ProcessQueueAsync()
    {
        var batchIndex = 0;
        await foreach (var item in _channel.Reader.ReadAllAsync(_cts.Token))
        {
            // 批处理模式
            _batchBuffer[batchIndex++] = item;
            if (batchIndex < BatchSize) continue;
            
            await ProcessBatchAsync(batchIndex);
            batchIndex = 0;
        }
        
        if (batchIndex > 0)
            await ProcessBatchAsync(batchIndex);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async ValueTask ProcessBatchAsync(int count)
    {
        // 使用线程专用内存
        var buffer = _threadLocalBuffer.Value!;
        
        for (var i = 0; i < count; i++)
        {
            var (input, key, tcs) = _batchBuffer[i];
            try
            {
                // 尾延迟优化
                using var latencyToken = _latencyOptimizer.BeginOperation();
                
                // 分层内存策略
                var memory = input.Length > 1024 
                    ? _coldMemoryPool.Rent(input.Length).Memory 
                    : buffer.Slice(0, input.Length);
                
                var result = _encryptService.AesEncrypt(input, key);
                tcs.TrySetResult(result);
            }
            catch (Exception ex)
            {
                tcs.TrySetException(ex);
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        _cts.Cancel();
        _channel.Writer.Complete();
        await _channel.Reader.Completion;
        _latencyOptimizer.Dispose();
    }
}

// 分层内存池实现
internal sealed class ColdMemoryPool : MemoryPool<byte>
{
    protected override void Dispose(bool disposing) { }
    
    public override IMemoryOwner<byte> Rent(int minBufferSize = -1)
    {
        return new ColdMemoryOwner(minBufferSize);
    }
    
    public override int MaxBufferSize => 1024 * 1024; // 1MB
}

internal sealed class ColdMemoryOwner : IMemoryOwner<byte>
{
    private byte[]? _array;
    
    public ColdMemoryOwner(int size)
    {
        _array = GC.AllocateUninitializedArray<byte>(size, pinned: true);
    }
    
    public Memory<byte> Memory => _array ?? throw new ObjectDisposedException(nameof(ColdMemoryOwner));
    
    public void Dispose()
    {
        if (_array == null) return;
        Array.Clear(_array, 0, _array.Length);
        _array = null;
    }
}

// 尾延迟优化器
[SkipLocalsInit]
internal sealed class TailLatencyOptimizer : IDisposable
{
    public IDisposable BeginOperation()
    {
        return new LatencyToken(this);
    }
    
    public void Dispose() { }
    
    private sealed class LatencyToken : IDisposable
    {
        private readonly TailLatencyOptimizer _parent;
        
        public LatencyToken(TailLatencyOptimizer parent)
        {
            _parent = parent;
        }
        
        public void Dispose() { }
    }
}