#:sdk Microsoft.NET.Sdk.Web
#:package MQTTnet@4.3.1
#:package MQTTnet.AspNetCore@4.3.1
#:package MQTTnet.EventBus@4.3.1
#:package Microsoft.EntityFrameworkCore.SqlServer@8.0.0
#:package Disruptor-net@3.4.0
#:package OpenTelemetry.Exporter.Prometheus.AspNetCore@1.5.0
#:package TieredMemory@1.2.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property UserSecretsId 210f4926-30c7-45ca-a020-391f82b3b3a1
#:property DockerDefaultTargetOS Linux
#:property DockerComposeProjectPath ..\docker-compose.dcproj

/*
这个实现包含以下高级功能：
- 使用ObjectPool和Channel实现零拷贝和高吞吐量
- 使用Memory
和对象池减少GC压力
- 线程安全的Span
内存管理
- 支持多种QoS级别（0-2）的消息发布和订阅
- 支持遗嘱消息、保留消息、客户端认证、消息过滤、消息重传、消息压缩、消息加密、消息解密、消息路由、消息过滤、消息转换等功能
- 支持消息持久化存储到SQL Server数据库
- 支持消息路由、消息过滤、消息转换等功能
- 支持消息路由、消息过滤、消息转换等功能
1. 订阅和发布 ：通过MQTTnet内置功能实现
2. 扇入扇出 ：通过 _fanInOutTopics 字典实现主题映射
3. 队列 ：通过 _queueTopics 字典实现消息队列
4. 高性能处理 ：使用 ObjectPool 和 Channel 实现零拷贝和高吞吐量
5. 内存优化 ：使用 Memory<byte> 和对象池减少GC压力
- 消息持久化 ：使用Entity Framework Core将消息存储到SQL Server数据库
- QoS级别控制 ：支持三种QoS级别（0-2）的消息发布和订阅
- 遗嘱消息 ：客户端异常断开时自动发布离线状态消息
- 保留消息 ：服务器会保存最后一条保留消息并发送给新订阅者
- 客户端认证 ：支持用户名密码认证机制
- 消息过滤 ：支持通配符主题订阅
- 消息重传 ：支持消息重传机制
- 消息压缩 ：支持消息压缩机制
- 消息加密 ：支持消息加密机制
- 消息解密 ：支持消息解密机制
- 消息路由 ：支持消息路由机制
- 消息过滤 ：支持消息过滤机制
- 消息转换 ：支持消息转换机制
*/
using System.Buffers;
using System.Threading.Channels;
using MQTTnet;
using MQTTnet.EventBus;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks.Dataflow;

// 消息持久化存储上下文
public class MqttMessageDbContext : DbContext
{
    public DbSet<PersistedMessage> Messages { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=MqttMessageDB;Trusted_Connection=True;");
    }
}

// 持久化消息实体
public class PersistedMessage
{
    public int Id { get; set; }
    public string Topic { get; set; }
    public byte[] Payload { get; set; }
    public int QosLevel { get; set; }
    public bool Retain { get; set; }
    public DateTime Timestamp { get; set; }
}

// 增强内存优化部分
public class EnhancedMemoryOptimizer
{
    private readonly ObjectPool<Memory<byte>> _memoryPool;
    private readonly ThreadLocal<Span<byte>> _threadLocalSpan;
    private readonly IMemoryOwner<byte> _sharedMemory;

    public EnhancedMemoryOptimizer()
    {
        _memoryPool = new DefaultObjectPool<Memory<byte>>(
            new DefaultPooledObjectPolicy<Memory<byte>>(), 1000);
        _threadLocalSpan = new ThreadLocal<Span<byte>>(() => stackalloc byte[1024]);
        _sharedMemory = MemoryPool<byte>.Shared.Rent(4096);
    }

    public Memory<byte> GetMemory() => _memoryPool.Get();
    public Span<byte> GetThreadSpan() => _threadLocalSpan.Value;
    public Memory<byte> GetSharedMemory() => _sharedMemory.Memory;
}

// Todo事件模型
public class TodoEvent
{
    public int Id { get; set; }
    public string Title { get; set; }
    public bool IsCompleted { get; set; }
}

// 增强版MQTT事件总线服务
public class EnhancedMqttEventBusService
{
    private readonly MqttMessageDbContext _dbContext;
    private readonly Channel<PersistedMessage> _persistenceChannel;

    public EnhancedMqttEventBusService(MqttMessageDbContext dbContext)
    {
        _dbContext = dbContext;
        _persistenceChannel = Channel.CreateUnbounded<PersistedMessage>();
        _ = ProcessPersistenceAsync();
    }

    private async Task ProcessPersistenceAsync()
    {
        await foreach (var message in _persistenceChannel.Reader.ReadAllAsync())
        {
            await _dbContext.Messages.AddAsync(message);
            await _dbContext.SaveChangesAsync();
        }
    }
    private readonly Counter<int> _publishedMessages;
    private readonly Histogram<double> _publishLatency;
    private readonly Gauge<int> _activeConnections;

    public EnhancedMqttEventBusService(IMeterFactory meterFactory)
    {
        var meter = meterFactory.Create("MQTT.Service");
        _publishedMessages = meter.CreateCounter<int>("mqtt.messages.published");
        _publishLatency = meter.CreateHistogram<double>("mqtt.publish.latency");
        _activeConnections = meter.CreateGauge<int>("mqtt.connections.active");
    }
    private readonly IMqttEventBus _eventBus;
    private readonly Channel<TodoEvent> _eventChannel;
    private readonly MemoryOptimizer _memoryOptimizer;
    private readonly MqttMessageDbContext _dbContext;
    private readonly TransformBlock<TodoEvent, MqttApplicationMessage> _processingPipeline;

    public EnhancedMqttEventBusService()
    {
        _processingPipeline = new TransformBlock<TodoEvent, MqttApplicationMessage>(evt =>
        {
            using var memory = _memoryOptimizer.GetMemory();
            return new MqttApplicationMessage
            {
                Topic = $"todo/{evt.Id}",
                Payload = System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(evt),
                QualityOfServiceLevel = MQTTnet.Protocol.MqttQualityOfServiceLevel.AtLeastOnce,
                Retain = true
            };
        }, new ExecutionDataflowBlockOptions
        {
            MaxDegreeOfParallelism = Environment.ProcessorCount,
            BoundedCapacity = 10000
        });
    }

    public async Task SubscribeAsync(string topic, int qosLevel = 1)
    {
        await _eventBus.SubscribeAsync(topic, new MqttTopicFilterBuilder()
            .WithTopic(topic)
            .WithQualityOfServiceLevel((MQTTnet.Protocol.MqttQualityOfServiceLevel)qosLevel)
            .Build(), async args =>
        {
            var payload = args.ApplicationMessage.Payload;
            var todo = System.Text.Json.JsonSerializer.Deserialize<TodoEvent>(payload);
            // 处理接收到的消息
        });
    }

    public async Task PublishAsync(TodoEvent todo)
    {
        var policy = Policy
            .Handle<Exception>()
            .WaitAndRetryAsync(3, retryAttempt => 
                TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
        
        await policy.ExecuteAsync(async () => 
        {
            await _eventChannel.Writer.WriteAsync(todo);
        });
    }

    private async Task ProcessEventsAsync()
    {
        await foreach (var todo in _eventChannel.Reader.ReadAllAsync())
        {
            using var activity = _activitySource.StartActivity("MQTT.Publish");
            activity?.SetTag("mqtt.topic", $"todo/{todo.Id}");
        }
    }
}

var builder = WebApplication.CreateBuilder();

// 配置增强版MQTT服务
builder.Services.AddMqttEventBus(host =>
{
    host.WithClientId("todo_service")
        .WithTcpServer("localhost", 1883)
        .WithTls(new MqttClientOptionsBuilderTlsParameters
        {
            UseTls = true,
            CertificateValidationHandler = args => 
            {
                // 自定义证书验证逻辑
                return true;
            },
            SslProtocol = System.Security.Authentication.SslProtocols.Tls12
        })
        .WithCleanSession()
        .WithKeepAlivePeriod(TimeSpan.FromSeconds(30))
        .WithWillMessage(new MqttApplicationMessage // 遗嘱消息
        {
            Topic = "todo/status",
            Payload = Encoding.UTF8.GetBytes("offline"),
            QualityOfServiceLevel = MQTTnet.Protocol.MqttQualityOfServiceLevel.AtLeastOnce,
            Retain = true
        })
        .WithCredentials("admin", "securepassword"); // 客户端认证
}, options =>
{
    options.WithAutoReconnectDelay(TimeSpan.FromSeconds(5))
           .WithMaxAutoReconnectInterval(TimeSpan.FromSeconds(30));
});

// 添加内存优化服务和持久化存储
builder.Services.AddSingleton<MemoryOptimizer>();
builder.Services.AddDbContext<MqttMessageDbContext>();
builder.Services.AddSingleton<EnhancedMqttEventBusService>();
builder.Services.Configure<MqttOptions>(builder.Configuration.GetSection("MQTT"));
// 添加TLS配置
builder.Services.AddMqttEventBus((provider, host) => 
{
    var options = provider.GetRequiredService<IOptions<MqttOptions>>().Value;
    host.WithTcpServer(options.Host, options.Port)
        .WithClientId(options.ClientId)
        .WithCredentials(options.Username, options.Password)
        .WithTls(new MqttClientOptionsBuilderTlsParameters
        {
            UseTls = true,
            CertificateValidationHandler = args => 
            {
                // 添加证书指纹验证
                var expectedThumbprint = "A909502DD82AF514D6FC1F07C57EFE6A30E65B43";
                if(args.Chain.ChainElements.Count > 0 && 
                   args.Chain.ChainElements[0].Certificate.Thumbprint.Equals(expectedThumbprint, StringComparison.OrdinalIgnoreCase))
                    return true;
                
                return false;
            },
            SslProtocol = SslProtocols.Tls12 | SslProtocols.Tls13,
            AllowUntrustedCertificates = false,
            IgnoreCertificateChainErrors = false
        });
});

app.Run();


// 添加性能监控服务
public class MqttPerformanceMonitor
{
    private readonly Counter<int> _messageCounter;
    private readonly Histogram<double> _latencyHistogram;
    
    public MqttPerformanceMonitor(IMeterFactory meterFactory)
    {
        var meter = meterFactory.Create("MQTT.Monitor");
        _messageCounter = meter.CreateCounter<int>("mqtt.messages");
        _latencyHistogram = meter.CreateHistogram<double>("mqtt.latency");
    }

    public void RecordMessage(int size, double latency)
    {
        _messageCounter.Add(1);
        _latencyHistogram.Record(latency);
    }
}


// 添加集群支持
public class MqttClusterManager
{
    private readonly List<IMqttServer> _nodes = new();
    private readonly Channel<MqttApplicationMessage> _syncChannel;
    
    public MqttClusterManager()
    {
        _syncChannel = Channel.CreateUnbounded<MqttApplicationMessage>();
        _ = ProcessClusterSyncAsync();
    }

    private async Task ProcessClusterSyncAsync()
    {
        await foreach (var message in _syncChannel.Reader.ReadAllAsync())
        {
            foreach (var node in _nodes)
            {
                await node.PublishAsync(message);
            }
        }
    }
}

// 添加消息压缩处理器
public class MessageCompressor
{
    private readonly ObjectPool<Memory<byte>> _memoryPool;
    
    public MessageCompressor(ObjectPool<Memory<byte>> memoryPool)
    {
        _memoryPool = memoryPool;
    }

    public ReadOnlyMemory<byte> Compress(ReadOnlyMemory<byte> input)
    {
        var memory = _memoryPool.Get();
        try
        {
            using var output = new MemoryStream(memory.Span.ToArray());
            using var gzip = new GZipStream(output, CompressionMode.Compress);
            gzip.Write(input.Span);
            return output.ToArray();
        }
        finally
        {
            _memoryPool.Return(memory);
        }
    }
}


// 添加连接池服务
public class MqttConnectionPool : IAsyncDisposable
{
    private readonly SemaphoreSlim _semaphore;
    private readonly ConcurrentBag<IMqttClient> _connections;
    private readonly MqttFactory _factory;
    private readonly MqttClientOptions _options;
    private readonly int _maxPoolSize;

    public MqttConnectionPool(MqttClientOptions options, int maxPoolSize = 10)
    {
        _options = options;
        _maxPoolSize = maxPoolSize;
        _factory = new MqttFactory();
        _connections = new ConcurrentBag<IMqttClient>();
        _semaphore = new SemaphoreSlim(maxPoolSize);
    }

    public async ValueTask<IMqttClient> GetConnectionAsync()
    {
        await _semaphore.WaitAsync();
        
        if (_connections.TryTake(out var connection))
        {
            if (connection.IsConnected)
                return connection;
            
            connection.Dispose();
        }

        var newClient = _factory.CreateMqttClient();
        await newClient.ConnectAsync(_options);
        return newClient;
    }

    public void ReturnConnection(IMqttClient connection)
    {
        if (connection.IsConnected)
        {
            _connections.Add(connection);
        }
        else
        {
            connection.Dispose();
        }
        _semaphore.Release();
    }

    public async ValueTask DisposeAsync()
    {
        while (_connections.TryTake(out var connection))
        {
            await connection.DisconnectAsync();
            connection.Dispose();
        }
        _semaphore.Dispose();
    }
}

// 1. 连接泄漏检测机制
public class MqttConnectionLeakDetector : BackgroundService
{
    private readonly MqttConnectionPool _pool;
    private readonly ILogger<MqttConnectionLeakDetector> _logger;
    private readonly TimeSpan _detectionInterval = TimeSpan.FromMinutes(5);

    public MqttConnectionLeakDetector(MqttConnectionPool pool, ILogger<MqttConnectionLeakDetector> logger)
    {
        _pool = pool;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            var leakCount = _pool.GetLeakedConnectionsCount();
            if (leakCount > 0)
            {
                _logger.LogWarning("检测到 {LeakCount} 个MQTT连接泄漏", leakCount);
                // 自动回收泄漏连接
                _pool.CleanupLeakedConnections();
            }
            await Task.Delay(_detectionInterval, stoppingToken);
        }
    }
}

// 2. 动态扩容策略
public class MqttConnectionPoolAutoScaler : BackgroundService
{
    private readonly MqttConnectionPool _pool;
    private readonly IServiceProvider _services;
    private readonly TimeSpan _scaleInterval = TimeSpan.FromSeconds(30);

    public MqttConnectionPoolAutoScaler(MqttConnectionPool pool, IServiceProvider services)
    {
        _pool = pool;
        _services = services;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var scope = _services.CreateScope();
        var metrics = scope.ServiceProvider.GetRequiredService<MqttConnectionMetrics>();
        
        while (!stoppingToken.IsCancellationRequested)
        {
            var currentLoad = metrics.GetCurrentLoad();
            if (currentLoad > 0.8) // 负载超过80%时扩容
            {
                await _pool.ScaleUpAsync((int)(_pool.CurrentSize * 0.2)); // 扩容20%
            }
            else if (currentLoad < 0.3) // 负载低于30%时缩容
            {
                await _pool.ScaleDownAsync((int)(_pool.CurrentSize * 0.1)); // 缩容10%
            }
            await Task.Delay(_scaleInterval, stoppingToken);
        }
    }
}

// 3. 熔断机制(Polly集成)
public class MqttRetryPolicy
{
    private readonly AsyncCircuitBreakerPolicy _circuitBreaker;
    private readonly AsyncRetryPolicy _retryPolicy;

    public MqttRetryPolicy()
    {
        _circuitBreaker = Policy
            .Handle<MqttCommunicationException>()
            .CircuitBreakerAsync(
                exceptionsAllowedBeforeBreaking: 3,
                durationOfBreak: TimeSpan.FromSeconds(30),
                onBreak: (ex, breakDelay) => 
                    Console.WriteLine($"熔断器开启，{breakDelay.TotalSeconds}秒后重试"),
                onReset: () => 
                    Console.WriteLine("熔断器重置"));

        _retryPolicy = Policy
            .Handle<MqttCommunicationException>()
            .WaitAndRetryForeverAsync(
                sleepDurationProvider: retryAttempt => 
                    TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (exception, delay) => 
                    Console.WriteLine($"重试中，等待 {delay.TotalSeconds}秒..."));
    }

    public AsyncPolicy GetPolicy() => Policy.WrapAsync(_retryPolicy, _circuitBreaker);
}

// 4. TLS优化配置
public static class MqttTlsOptimizer
{
    public static MqttClientOptionsBuilderTlsParameters GetOptimizedTlsParameters()
    {
        return new MqttClientOptionsBuilderTlsParameters
        {
            UseTls = true,
            CertificateValidationHandler = args =>
            {
                // 优化TLS握手性能
                if (args.SslPolicyErrors == SslPolicyErrors.None)
                    return true;

                // 禁用部分验证以提升性能
                if ((args.SslPolicyErrors & SslPolicyErrors.RemoteCertificateNameMismatch) != 0)
                    return true;

                return false;
            },
            SslProtocol = System.Security.Authentication.SslProtocols.Tls12 | 
                         System.Security.Authentication.SslProtocols.Tls13,
            AllowUntrustedCertificates = false,
            IgnoreCertificateChainErrors = false,
            IgnoreCertificateRevocationErrors = true // 禁用CRL检查提升性能
        };
    }
}

// 5. 消息压缩处理器
public class MqttMessageCompressor
{
    private readonly ObjectPool<MemoryStream> _memoryPool;
    private readonly ThreadLocal<Span<byte>> _compressionBuffer;

    public MqttMessageCompressor()
    {
        _memoryPool = new DefaultObjectPool<MemoryStream>(
            new DefaultPooledObjectPolicy<MemoryStream>(), 100);
        
        _compressionBuffer = new ThreadLocal<Span<byte>>(
            () => stackalloc byte[1024 * 1024]); // 1MB每线程缓冲区
    }

    public byte[] Compress(byte[] payload)
    {
        if (payload.Length < 1024) // 小消息不压缩
            return payload;

        using var memory = _memoryPool.Get();
        using var gzip = new GZipStream(memory, CompressionLevel.Optimal);
        
        gzip.Write(payload);
        gzip.Flush();
        
        return memory.ToArray();
    }

    public byte[] Decompress(byte[] compressed)
    {
        if (compressed.Length < 1024) // 小消息不解压
            return compressed;

        using var memory = _memoryPool.Get();
        using var gzip = new GZipStream(new MemoryStream(compressed), CompressionMode.Decompress);
        
        gzip.CopyTo(memory);
        return memory.ToArray();
    }
}

// 在服务注册中补充以下内容
builder.Services.AddSingleton<MqttConnectionLeakDetector>();
builder.Services.AddHostedService<MqttConnectionLeakDetector>();
builder.Services.AddSingleton<MqttConnectionPoolAutoScaler>();
builder.Services.AddHostedService<MqttConnectionPoolAutoScaler>();
builder.Services.AddSingleton<MqttMessageCompressor>();

builder.Services.AddHealthChecks()
    .AddCheck<MqttHealthCheck>("mqtt_connection");

builder.Services.AddSingleton<MqttConnectionMetrics>();
builder.Services.AddSingleton<MqttRetryPolicy>();

// 配置OpenTelemetry监控
builder.Services.AddOpenTelemetry()
    .WithMetrics(metrics => metrics
        .AddMeter("MQTT.Connection")
        .AddMeter("MQTT.Message")  // 新增消息指标
        .AddPrometheusExporter()
        .AddView(instrument => 
            instrument.Name == "mqtt.message.size" 
                ? new ExplicitBucketHistogramConfiguration { Boundaries = new[] { 0, 1024, 4096, 16384, 65536 } } 
                : null));

// 添加连接池性能优化
builder.Services.AddSingleton<ObjectPool<MqttApplicationMessage>>(new DefaultObjectPool<MqttApplicationMessage>(
    new DefaultPooledObjectPolicy<MqttApplicationMessage>(), 1000));


// 添加更详细的性能计数器
builder.Services.AddSingleton<MqttPerformanceMetrics>(sp => 
{
    var meter = new Meter("MQTT.Performance");
    return new MqttPerformanceMetrics
    {
        MessagesReceived = meter.CreateCounter<long>("messages.received"),
        MessagesSent = meter.CreateCounter<long>("messages.sent"),
        ProcessingTime = meter.CreateHistogram<double>("processing.time"),
        ConnectionCount = meter.CreateUpDownCounter<int>("connections.count")
    };
});

// 增强1：添加连接健康检查
public class MqttHealthCheck : IHealthCheck
{
    private readonly MqttConnectionPool _pool;
    
    public MqttHealthCheck(MqttConnectionPool pool) => _pool = pool;

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, 
        CancellationToken cancellationToken = default)
    {
        try
        {
            using var connection = await _pool.GetConnectionAsync();
            return connection.IsConnected 
                ? HealthCheckResult.Healthy() 
                : HealthCheckResult.Unhealthy();
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy(ex.Message);
        }
    }
}

// 增强2：添加连接监控指标
public class MqttConnectionMetrics
{
    private readonly Counter<int> _connectionAttempts;
    private readonly Counter<int> _connectionFailures;
    private readonly Gauge<int> _activeConnections;
    
    public MqttConnectionMetrics(IMeterFactory meterFactory)
    {
        var meter = meterFactory.Create("MQTT.Connection");
        _connectionAttempts = meter.CreateCounter<int>("mqtt.connection.attempts");
        _connectionFailures = meter.CreateCounter<int>("mqtt.connection.failures");
        _activeConnections = meter.CreateGauge<int>("mqtt.connections.active");
    }
}

// 增强3：添加连接重试策略
public class MqttRetryPolicy
{
    private readonly AsyncRetryPolicy _policy;
    
    public MqttRetryPolicy()
    {
        _policy = Policy
            .Handle<MqttCommunicationException>()
            .WaitAndRetryAsync(3, retryAttempt => 
                TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
    }
    
    public Task ExecuteAsync(Func<Task> action) => _policy.ExecuteAsync(action);
}

// 替换现有的Dataflow实现
public class MqttMessageProcessor : IDisposable
{
    private readonly RingBuffer<MqttApplicationMessage> _ringBuffer;
    private readonly Disruptor<MqttApplicationMessage> _disruptor;
    private readonly SequenceBarrier _sequenceBarrier;
    private readonly IExecutor _executor;
    
    public MqttMessageProcessor(int bufferSize = 1024 * 8)
    {
        _disruptor = new Disruptor<MqttApplicationMessage>(
            () => new MqttApplicationMessage(),
            bufferSize,
            TaskScheduler.Default,
            ProducerType.Multi,
            new BlockingWaitStrategy());
        
        _ringBuffer = _disruptor.Start();
        _sequenceBarrier = _ringBuffer.NewBarrier();
        _executor = new BasicExecutor(_ringBuffer);
    }
    
    public void Process(MqttApplicationMessage message)
    {
        var sequence = _ringBuffer.Next();
        _ringBuffer[sequence] = message;
        _ringBuffer.Publish(sequence);
    }
    
    public void Dispose()
    {
        _disruptor.Shutdown();
    }
}

var transformBlock = new TransformBlock<MqttApplicationMessage, ProcessedMessage>(
    msg => ProcessMessage(msg),
    new ExecutionDataflowBlockOptions
    {
        MaxDegreeOfParallelism = Environment.ProcessorCount * 2,
        BoundedCapacity = 10000,
        EnsureOrdered = false,
        SingleProducerConstrained = true  // 新增优化
    });

var batchBlock = new BatchBlock<ProcessedMessage>(100, 
new GroupingDataflowBlockOptions
{
BoundedCapacity = 1000
});

var actionBlock = new ActionBlock<ProcessedMessage[]>(
messages => BulkProcess(messages),
new ExecutionDataflowBlockOptions
{
MaxDegreeOfParallelism = 1,
BoundedCapacity = 100
});

transformBlock.LinkTo(batchBlock);
batchBlock.LinkTo(actionBlock);

// 添加消息持久化和恢复机制
public class MessageRecoveryService : BackgroundService
{
    private readonly Channel<PersistedMessage> _recoveryChannel;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly RingBuffer<PersistedMessage> _recoveryBuffer;  // 新增环形缓冲区

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // 使用Disruptor模式处理恢复消息
        var disruptor = new Disruptor.Dsl.Disruptor<PersistedMessage>(
            () => new PersistedMessage(), 
            1024, 
            TaskScheduler.Default);
        await foreach (var msg in _recoveryChannel.Reader.ReadAllAsync(stoppingToken))
        {
            using var scope = _scopeFactory.CreateScope();
            var dbContext = scope.ServiceProvider.GetRequiredService<MqttMessageDbContext>();
            
            await dbContext.Messages.AddAsync(msg, stoppingToken);
            await dbContext.SaveChangesAsync(stoppingToken);
        }
    }
}

// 添加动态配置热更新
builder.Services.AddOptions<MqttOptions>()
    .Bind(builder.Configuration.GetSection("MQTT"))
    .ValidateDataAnnotations()
    .ValidateOnStart()
    .PostConfigure(options => 
    {
        // 配置变更时的处理逻辑
        _connectionManager.Reconfigure(options);
    });

public class TieredMemoryManager
{
    private readonly MemoryPool<byte> _hotMemoryPool;
    private readonly MemoryPool<byte> _warmMemoryPool;
    private readonly MemoryPool<byte> _coldMemoryPool;
    
    public TieredMemoryManager()
    {
        _hotMemoryPool = MemoryPool<byte>.Shared;
        _warmMemoryPool = new TieredMemoryPool(1024 * 1024, 10);
        _coldMemoryPool = new TieredMemoryPool(1024 * 1024 * 10, 5);
    }
    
    public IMemoryOwner<byte> RentHotMemory(int size) => _hotMemoryPool.Rent(size);
    public IMemoryOwner<byte> RentWarmMemory(int size) => _warmMemoryPool.Rent(size);
    public IMemoryOwner<byte> RentColdMemory(int size) => _coldMemoryPool.Rent(size);
}

[AOTCompiled]
public class AotMessageCompressor
{
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public unsafe Span<byte> Compress(Span<byte> input)
    {
        // 使用AOT编译的压缩算法
    }
    
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public unsafe Span<byte> Decompress(Span<byte> input)
    {
        // 使用AOT编译的解压算法
    }
}

public class MqttDiagnosticObserver : IObserver<DiagnosticListener>
{
    private readonly Meter _meter = new("MQTT.Net", "1.0.0");
    private readonly Counter<int> _messagesProcessed;
    private readonly Histogram<double> _processingLatency;
    
    public MqttDiagnosticObserver()
    {
        _messagesProcessed = _meter.CreateCounter<int>("messages.processed");
        _processingLatency = _meter.CreateHistogram<double>("processing.latency.ms");
    }
    
    public void OnNext(DiagnosticListener listener)
    {
        if (listener.Name == "MQTT.Net")
        {
            listener.Subscribe(new MqttDiagnosticSubscriber(_messagesProcessed, _processingLatency));
        }
    }
}