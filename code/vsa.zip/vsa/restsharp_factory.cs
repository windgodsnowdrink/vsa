#:sdk Microsoft.NET.Sdk.Web
#:package RestSharp@110.0.0
#:package Microsoft.Extensions.Options@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using RestSharp;
using System.Threading.Channels;

var builder = WebApplication.CreateBuilder();

// 配置选项模式
builder.Services.Configure<RestClientOptions>(options =>
{
    options.BaseUrl = "https://api.example.com";
    options.Timeout = 3000;
});

// 高性能客户端工厂
builder.Services.AddSingleton<IRestClientFactory>(sp => 
    new ChannelRestClientFactory(
        Channel.CreateBounded<RestRequest>(10000),
        new ThreadLocal<Span<byte>>(() => stackalloc byte[512]),
        sp.GetRequiredService<IOptions<RestClientOptions>>()));

var app = builder.Build();
app.MapGet("/", () => "RestSharp Factory Ready");
app.Run();

public class ChannelRestClientFactory : IRestClientFactory
{
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public IRestClient CreateClient()
    {
        // 实现细节...
    }
}