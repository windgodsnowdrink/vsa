#:sdk Microsoft.NET.Sdk.Web
#:package Prometheus.Client@4.3.0
#:package System.Threading.Channels@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Prometheus.Client;
using System.Threading.Channels;

var builder = WebApplication.CreateBuilder();

// 指标收集器
builder.Services.AddSingleton<IMetricCollector>(sp => 
    new PrometheusMetricCollector(
        Channel.CreateBounded<MetricEvent>(10000),
        new ThreadLocal<Span<byte>>(() => stackalloc byte[128])));

// OpenTelemetry集成
builder.Services.AddOpenTelemetry()
    .WithMetrics(b => b.AddPrometheusExporter());