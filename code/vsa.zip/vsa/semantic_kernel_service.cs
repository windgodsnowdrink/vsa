#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.SemanticKernel@1.0.0
#:package Microsoft.SemanticKernel.Plugins.Core@1.0.0
#:package Microsoft.SemanticKernel.Connectors.Ollama@1.0.0
#:package System.Threading.Channels@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using System.Threading.Channels;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Plugins.Core;

// 1. AI代理处理器(Disruptor模式)
[SkipLocalsInit]
public sealed class AiAgentProcessor : IAsyncDisposable
{
    private readonly Channel<AgentRequest> _requestChannel;
    private readonly IKernel _kernel;
    private readonly CancellationTokenSource _cts = new();
    private readonly TailLatencyOptimizer _latencyOptimizer;

    public AiAgentProcessor(IKernel kernel)
    {
        _kernel = kernel;
        _latencyOptimizer = new TailLatencyOptimizer();
        
        // Disruptor模式通道配置
        _requestChannel = Channel.CreateBounded<AgentRequest>(new BoundedChannelOptions(10000)
        {
            SingleReader = true,
            AllowSynchronousContinuations = true,
            FullMode = BoundedChannelFullMode.DropOldest
        });
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task EnqueueRequestAsync(AgentRequest request)
    {
        await _requestChannel.Writer.WriteAsync(request);
    }

    private async Task ProcessRequestsAsync()
    {
        await foreach (var request in _requestChannel.Reader.ReadAllAsync(_cts.Token))
        {
            _latencyOptimizer.Optimize(() => 
            {
                var result = ExecuteAgentRequest(request);
                request.CompletionSource.SetResult(result);
            });
        }
    }

    private async Task<string> ExecuteAgentRequest(AgentRequest request)
    {
        // 使用Semantic Kernel处理请求
        var function = _kernel.Functions.GetFunction(request.PluginName, request.FunctionName);
        var result = await _kernel.RunAsync(request.Input, function);
        return result.GetValue<string>();
    }

    public async ValueTask DisposeAsync()
    {
        _cts.Cancel();
        _requestChannel.Writer.Complete();
    }
}

// 2. 主程序集成
var builder = WebApplication.CreateBuilder(args);

// 配置Semantic Kernel
builder.Services.AddSingleton<IKernel>(sp => 
{
    var kernel = Kernel.CreateBuilder()
        .AddOllamaChatCompletion(
            modelId: " deepseek-r1:8b",
            endpoint: new Uri("http://localhost:11434"),
            serviceId: "deepseek")
        .Build();
    
    // 注册核心插件
    kernel.ImportPluginFromType<TimePlugin>();
    return kernel;
});

// 注册AI代理处理器
builder.Services.AddSingleton<AiAgentProcessor>();

var app = builder.Build();

// AI代理端点
app.MapPost("/ai-agent", async (AgentRequest request, AiAgentProcessor processor) =>
{
    await processor.EnqueueRequestAsync(request);
    return await request.CompletionSource.Task;
});

app.Run();

// 3. 辅助类
public record AgentRequest(
    string PluginName,
    string FunctionName,
    string Input)
{
    public TaskCompletionSource<string> CompletionSource { get; } = new();
}