#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.Kiota.Http.HttpClientLibrary@1.0.0
#:package Microsoft.Kiota.Serialization.Json@1.0.0
#:package Microsoft.Kiota.Abstractions@1.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Threading.Channels;
using Microsoft.Kiota.Http;
using Microsoft.Kiota.Abstractions;
using Microsoft.Kiota.Serialization.Json;

var builder = WebApplication.CreateBuilder();

// 1. 配置Kiota客户端
builder.Services.AddSingleton<RequestAdapter>(sp => 
    new HttpClientRequestAdapter(
        new AnonymousAuthenticationProvider(),
        new JsonSerializationWriterFactory(),
        new JsonParseNodeFactory(),
        new HttpClient())
    {
        BaseUrl = "https://api.example.com"
    });

// 2. 高性能代码生成通道
var codeGenChannel = Channel.CreateBounded<string>(
    new BoundedChannelOptions(10000)
    {
        SingleReader = true,
        AllowSynchronousContinuations = true
    });

// 3. 零拷贝代码生成器
builder.Services.AddSingleton<IKiotaCodeGenerator>(sp => 
    new ChannelKiotaCodeGenerator(
        codeGenChannel,
        new ThreadLocal<Span<byte>>(() => stackalloc byte[1024])));

var app = builder.Build();
app.MapGet("/", () => "Kiota Integration Ready");
app.Run();

// 高性能代码生成器
[SkipLocalsInit]
public class ChannelKiotaCodeGenerator : IKiotaCodeGenerator
{
    private readonly ChannelWriter<string> _writer;
    private readonly ThreadLocal<Span<byte>> _buffer;
    
    public ChannelKiotaCodeGenerator(Channel<string> channel, ThreadLocal<Span<byte>> buffer)
    {
        _writer = channel.Writer;
        _buffer = buffer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe void Generate(string openApiSpec)
    {
        Span<byte> buffer = stackalloc byte[1024];
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0) // Cache-line对齐
            {
                // SIMD优化处理OpenAPI规范
                _writer.TryWrite(openApiSpec);
            }
        }
    }
}