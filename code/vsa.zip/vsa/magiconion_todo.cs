#:sdk Microsoft.NET.Sdk.Web
#:package MagicOnion@5.0.0
#:package Grpc.AspNetCore@2.62.0
#:package MessagePack@2.5.122
#:package System.Threading.Channels@8.0.0
#:package OpenTelemetry.Exporter.Prometheus.AspNetCore@1.5.0
#:package OpenTelemetry.Extensions.Hosting@1.5.0
#:package Linkerd.Client@0.3.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using MagicOnion;
using MagicOnion.Server;
using MessagePack;
using System.Threading.Channels;
using OpenTelemetry.Metrics;
using OpenTelemetry.Trace;
using Linkerd;

var builder = WebApplication.CreateBuilder();

// 1. 分布式追踪配置
builder.Services.AddOpenTelemetry()
    .WithTracing(tracing => tracing
        .AddAspNetCoreInstrumentation()
        .AddGrpcClientInstrumentation()
        .AddMagicOnionInstrumentation()
        .AddOtlpExporter())
    .WithMetrics(metrics => metrics
        .AddAspNetCoreInstrumentation()
        .AddPrometheusExporter());

// 2. 服务网格集成
builder.Services.AddLinkerdClient(options =>
{
    options.ControlPlaneAddr = "linkerd-proxy-api:8086";
    options.EnableTLS = true;
});

// 3. 高性能Todo通道
var todoChannel = Channel.CreateBounded<TodoOperation>(
    new BoundedChannelOptions(10000)
    {
        SingleReader = true,
        AllowSynchronousContinuations = true
    });

// 4. 零拷贝Todo处理器
builder.Services.AddSingleton<ITodoProcessor>(sp => 
    new ChannelTodoProcessor(
        todoChannel,
        new ThreadLocal<Span<byte>>(() => stackalloc byte[512])));

// 5. 性能监控指标
builder.Services.AddSingleton<MeterProvider>(_ => 
    Sdk.CreateMeterProviderBuilder()
        .AddMeter("TodoService")
        .AddPrometheusExporter()
        .Build());

var app = builder.Build();

// 启用OpenTelemetry Prometheus端点
app.UseOpenTelemetryPrometheusScrapingEndpoint();
app.MapMagicOnionService();
app.MapGet("/", () => "MagicOnion Todo Ready");
app.Run();

// 增强的Todo处理器
[SkipLocalsInit]
public class ChannelTodoProcessor : ITodoProcessor
{
    private readonly Counter<int> _processedCount;
    private readonly Histogram<double> _processLatency;
    
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe void Process(TodoOperation operation)
    {
        using var _ = _processLatency.NewTimer();
        
        Span<byte> buffer = stackalloc byte[512];
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0) // Cache-line对齐
            {
                // SIMD优化处理Todo操作
                _processedCount.Add(1);
            }
        }
    }
}

// 扩展MagicOnion服务接口
public interface ITodoService : IService<ITodoService>
{
    UnaryResult<TodoItem> GetTodoAsync(int id);
    UnaryResult<TodoItem> AddTodoAsync(TodoItem item);
    UnaryResult<bool> CompleteTodoAsync(int id);
    ServerStreamingResult<TodoItem> WatchTodosAsync();
    
    // 新增监控端点
    UnaryResult<MetricsSnapshot> GetMetricsAsync();
}

// 指标快照DTO
[MessagePackObject]
public class MetricsSnapshot
{
    [Key(0)]
    public long ProcessedCount { get; set; }
    
    [Key(1)]
    public double AvgLatencyMs { get; set; }
    
    [Key(2)]
    public double P99LatencyMs { get; set; }
}

[MessagePackObject]
public class TodoItem
{
    [Key(0)]
    public int Id { get; set; }
    [Key(1)]
    public string Title { get; set; }
    [Key(2)]
    public bool IsCompleted { get; set; }
}