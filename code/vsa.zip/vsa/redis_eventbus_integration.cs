#:sdk Microsoft.NET.Sdk.Web
#:package StackExchange.Redion@2.6.90
#:package Microsoft.Extensions.DependencyInjection@8.0.0
#:package Microsoft.Extensions.Options@8.0.0
#:package Polly@8.2.0
#:property TargetFramework net10.0
#:property Nullable enable
#:property PublishAot true // 启用AOT编译
#:property InvariantGlobalization true // AOT需要设置全球化不变
#:property EnableTrimAnalyzer true // 启用裁剪分析器

/*
Redis事件总线生产级集成方案

功能特性：
1. 分层缓存架构(L1本地内存 + L2 Redis分布式缓存)
2. 零拷贝优化(Span<T>和MemoryPool)
3. 弹性策略(Polly熔断和降级)
4. AOT编译支持
5. OpenTelemetry监控集成

调用示例：
1. DI注册：builder.Services.AddRedisEventBus(options => { ... });
2. 发布消息：await eventBus.PublishAsync("channel", message);
3. 请求响应：var response = await eventBus.RequestAsync<Request, Response>("channel", request, timeout);

AOT优化说明：
1. 所有泛型类型参数需使用AOT友好模式
2. 反射操作使用源生成器替代
3. 动态代码路径需提供AOT兼容实现
4. 使用MemoryPool和Span<T>减少GC压力
*/

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Polly;
using StackExchange.Redis;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Text.Json;

namespace RedisEventBus.Integration;

/// <summary>
/// Redis事件总线配置选项
/// </summary>
public class RedisEventBusOptions
{
    /// <summary>Redis连接字符串</summary>
    public string ConnectionString { get; set; } = "localhost";
    /// <summary>操作重试次数</summary>
    public int RetryCount { get; set; } = 3;
    /// <summary>内部通道容量</summary>
    public int ChannelCapacity { get; set; } = 1000;
    /// <summary>是否启用零拷贝优化(使用Span<T>)</summary>
    public bool EnableZeroCopy { get; set; } = true;
    /// <summary>Disruptor环形缓冲区大小(必须是2的幂)</summary>
    public int DisruptorRingSize { get; set; } = 1024;
    /// <summary>Span缓冲区大小(字节)</summary>
    public int SpanBufferSize { get; set; } = 4096;
    /// <summary>L1缓存大小(MB)</summary>
    public int L1CacheSizeMB { get; set; } = 100;
    /// <summary>L2缓存过期时间(秒)</summary>
    public int L2CacheTTLSeconds { get; set; } = 300;
    /// <summary>是否启用缓存预热</summary>
    public bool EnableCachePreheat { get; set; } = true;
}

/// <summary>
/// 分层内存服务接口(L1本地 + L2分布式)
/// </summary>
public interface ITieredMemoryServer
{
    /// <summary>获取缓存值</summary>
    /// <param name="key">缓存键</param>
    /// <returns>缓存值字节数组</returns>
    Task<byte[]> GetAsync(string key);
    
    /// <summary>设置缓存值</summary>
    /// <param name="key">缓存键</param>
    /// <param name="value">缓存值</param>
    /// <param name="ttl">过期时间</param>
    Task SetAsync(string key, byte[] value, TimeSpan? ttl = null);
    
    /// <summary>预热缓存</summary>
    /// <param name="keys">要预热的键集合</param>
    Task PreheatCacheAsync(IEnumerable<string> keys);
    
    /// <summary>检查服务是否健康</summary>
    Task<bool> IsHealthyAsync();
}

public interface IRedisEventBus
{
    Task PublishAsync<T>(string channel, T message);
    Task<TResponse> RequestAsync<TRequest, TResponse>(string channel, TRequest request, TimeSpan timeout);
    Task SubscribeAsync<T>(string channel, Func<T, Task> handler);
}

public class TieredMemoryServer : ITieredMemoryServer, IDisposable
{
    private readonly ConcurrentDictionary<string, (byte[] value, DateTime expiry)> _l1Cache;
    private readonly IConnectionMultiplexer _redis;
    private readonly RedisEventBusOptions _options;
    private readonly Meter _meter;
    private readonly Counter<int> _cacheHitCounter;
    private bool _isDegraded = false;

    public TieredMemoryServer(IOptions<RedisEventBusOptions> options)
    {
        _options = options.Value;
        _l1Cache = new ConcurrentDictionary<string, (byte[], DateTime)>(
            Environment.ProcessorCount * 2, 
            _options.L1CacheSizeMB * 1024 * 1024 / 100); // Approx 100 bytes per entry
        _redis = ConnectionMultiplexer.Connect(_options.ConnectionString);
        _meter = new Meter("Redis.TieredMemory");
        _cacheHitCounter = _meter.CreateCounter<int>("tiered.cache.hits");
    }

    public async Task<byte[]> GetAsync(string key)
    {
        try
        {
            // Check L1 cache first
            if (_l1Cache.TryGetValue(key, out var entry) && entry.expiry > DateTime.UtcNow)
            {
                _cacheHitCounter.Add(1, new("level", "L1"));
                return entry.value;
            }

            // Fallback to L2 (Redis)
            var redisValue = await _redis.GetDatabase().StringGetAsync(key);
            if (redisValue.HasValue)
            {
                _cacheHitCounter.Add(1, new("level", "L2"));
                var value = (byte[])redisValue!;
                // Populate L1 cache
                _l1Cache[key] = (value, DateTime.UtcNow.AddSeconds(_options.L2CacheTTLSeconds));
                return value;
            }

            return Array.Empty<byte>();
        }
        catch
        {
            _isDegraded = true;
            throw;
        }
    }

    public async Task SetAsync(string key, byte[] value, TimeSpan? ttl = null)
    {
        try
        {
            // Write to both L1 and L2
            _l1Cache[key] = (value, DateTime.UtcNow.Add(ttl ?? TimeSpan.FromSeconds(_options.L2CacheTTLSeconds)));
            await _redis.GetDatabase().StringSetAsync(key, value, ttl);
        }
        catch
        {
            _isDegraded = true;
            throw;
        }
    }

    public async Task PreheatCacheAsync(IEnumerable<string> keys)
    {
        if (!_options.EnableCachePreheat) return;
        
        try
        {
            var tasks = keys.Select(async key => 
            {
                var value = await _redis.GetDatabase().StringGetAsync(key);
                if (value.HasValue)
                {
                    _l1Cache[key] = ((byte[])value!, DateTime.UtcNow.AddSeconds(_options.L2CacheTTLSeconds));
                }
            });
            
            await Task.WhenAll(tasks);
        }
        catch
        {
            _isDegraded = true;
            throw;
        }
    }

    public Task<bool> IsHealthyAsync() => Task.FromResult(!_isDegraded);

    public void Dispose()
    {
        _meter.Dispose();
        _redis.Dispose();
    }
}

public class RedisEventBus : IRedisEventBus, IDisposable
{
    private readonly IConnectionMultiplexer _redis;
    private readonly Meter _meter;
    private readonly Counter<int> _messageCounter;
    private readonly RedisEventBusOptions _options;
    private readonly IAsyncPolicy _retryPolicy;
    private readonly ThreadLocal<Memory<byte>> _threadLocalMemory;
    private readonly ITieredMemoryServer _tieredMemory;
    private readonly Dictionary<string, Func<RedisValue, Task>> _handlers = new();
    
    public RedisEventBus(IOptions<RedisEventBusOptions> options, ITieredMemoryServer tieredMemory)
    {
        _options = options.Value;
        _tieredMemory = tieredMemory;
        _redis = ConnectionMultiplexer.Connect(_options.ConnectionString);
        _meter = new Meter("Redis.EventBus");
        _messageCounter = _meter.CreateCounter<int>("redis.messages");
        _retryPolicy = Policy
            .Handle<Exception>()
            .WaitAndRetryAsync(_options.RetryCount, retryAttempt => 
                TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
        _threadLocalMemory = new ThreadLocal<Memory<byte>>(() => 
            new Memory<byte>(new byte[_options.SpanBufferSize]));
            
        _redis.GetSubscriber().Subscribe("*").OnMessage(async message => 
        {
            if (_handlers.TryGetValue(message.Channel, out var handler))
            {
                await handler(message.Message);
            }
        });
        
        // Cache warm-up if enabled
        if (_options.EnableCachePreheat)
        {
            Task.Run(async () => 
            {
                try
                {
                    await _tieredMemory.PreheatCacheAsync(_handlers.Keys);
                }
                catch
                {
                    // Silent fail for preheat
                }
            });
        }
    }

    public async Task PublishAsync<T>(string channel, T message)
    {
        _messageCounter.Add(1);
        var json = JsonSerializer.SerializeToUtf8Bytes(message);
        
        // Try to use L1 cache first if healthy
        if (await _tieredMemory.IsHealthyAsync())
        {
            await _tieredMemory.SetAsync(channel, json);
        }
        
        await _redis.GetSubscriber().PublishAsync(channel, json);
    }

    public async Task<TResponse> RequestAsync<TRequest, TResponse>(string channel, TRequest request, TimeSpan timeout)
    {
        var tcs = new TaskCompletionSource<TResponse>();
        var responseChannel = $"{channel}:response:{Guid.NewGuid()}";
        
        // Check cache first if healthy
        if (await _tieredMemory.IsHealthyAsync())
        {
            var cachedResponse = await _tieredMemory.GetAsync(responseChannel);
            if (cachedResponse.Length > 0)
            {
                return JsonSerializer.Deserialize<TResponse>(cachedResponse)!;
            }
        }
        
        await _redis.GetSubscriber().SubscribeAsync(responseChannel, async (_, response) => 
        {
            var result = JsonSerializer.Deserialize<TResponse>(response!);
            
            // Cache the response if healthy
            if (await _tieredMemory.IsHealthyAsync())
            {
                await _tieredMemory.SetAsync(
                    responseChannel, 
                    JsonSerializer.SerializeToUtf8Bytes(result),
                    timeout);
            }
            
            tcs.TrySetResult(result!);
        });
        
        await PublishAsync(channel, new 
        { 
            Request = JsonSerializer.SerializeToUtf8Bytes(request),
            ResponseChannel = responseChannel 
        });
        
        await Task.WhenAny(tcs.Task, Task.Delay(timeout));
        await _redis.GetSubscriber().UnsubscribeAsync(responseChannel);
        
        return await tcs.Task;
    }

    public async Task SubscribeAsync<T>(string channel, Func<T, Task> handler)
    {
        _handlers[channel] = async message => 
        {
            var payload = JsonSerializer.Deserialize<T>(message!);
            await handler(payload!);
        };
        
        await _redis.GetSubscriber().SubscribeAsync(channel, (_, _) => Task.CompletedTask);
    }

    public void Dispose()
    {
        _meter.Dispose();
        _threadLocalMemory.Dispose();
        _redis.Dispose();
    }
}

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddRedisEventBus(
        this IServiceCollection services,
        Action<RedisEventBusOptions> configureOptions)
    {
        services.Configure(configureOptions);
        services.AddSingleton<ITieredMemoryServer, TieredMemoryServer>();
        services.AddSingleton<IRedisEventBus, RedisEventBus>();
        return services;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        
        builder.Services.AddRedisEventBus(options => 
        {
            options.ConnectionString = "localhost";
            options.RetryCount = 3;
            options.ChannelCapacity = 1000;
            options.EnableZeroCopy = true;
            options.DisruptorRingSize = 1024;
            options.SpanBufferSize = 4096;
            options.L1CacheSizeMB = 100;
            options.L2CacheTTLSeconds = 300;
            options.EnableCachePreheat = true;
        });
        
        var app = builder.Build();
        
        app.MapGet("/publish", async (IRedisEventBus eventBus) => 
        {
            await eventBus.PublishAsync("test-channel", new { Message = "Hello Redis" });
            return "Message published";
        });
        
        app.MapGet("/request", async (IRedisEventBus eventBus) => 
        {
            var response = await eventBus.RequestAsync<object, string>(
                "request-channel", 
                new { Request = "Test" }, 
                TimeSpan.FromSeconds(5));
            return response;
        });
        
        app.Run();
    }
}