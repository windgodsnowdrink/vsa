#:sdk Microsoft.NET.Sdk
#:package DnsClient@1.7.0
#:property TargetFramework net10.0
#:property Nullable enable

using System;
using System.Collections.Concurrent;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using DnsClient;
using DnsClient.Protocol;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

public class DnsDiscoveryOptions
{
    public string Domain { get; set; } = "local.";
    public TimeSpan ScanInterval { get; set; } = TimeSpan.FromSeconds(30);
    public TimeSpan Timeout { get; set; } = TimeSpan.FromSeconds(5);
    public int RetryCount { get; set; } = 3;
    public string ServiceType { get; set; } = "_device._tcp";
}

public interface IDnsDiscoveryService : IDisposable
{
    Task RegisterServiceAsync(string serviceName, int port, IDictionary<string, string> properties);
    Task UnregisterServiceAsync();
    IObservable<DnsServiceEntry> DiscoveredDevices { get; }
    Task StartDiscoveryAsync();
    Task StopDiscoveryAsync();
}

public class DnsServiceEntry
{
    public string Name { get; set; }
    public int Port { get; set; }
    public IPAddress[] Addresses { get; set; }
    public IDictionary<string, string> Properties { get; set; }
}

public class DnsDiscoveryService : IDnsDiscoveryService
{
    private readonly DnsDiscoveryOptions _options;
    private readonly ILookupClient _lookupClient;
    private readonly ConcurrentDictionary<string, DnsServiceEntry> _discoveredDevices = new();
    private readonly Subject<DnsServiceEntry> _discoveredSubject = new();
    private IDisposable _scanSubscription;
    private string _registeredServiceName;
    private int _registeredPort;
    private IDictionary<string, string> _registeredProperties;
    private bool _disposed;

    public DnsDiscoveryService(IOptions<DnsDiscoveryOptions> options, ILookupClient lookupClient)
    {
        _options = options.Value;
        _lookupClient = lookupClient;
    }

    public IObservable<DnsServiceEntry> DiscoveredDevices => _discoveredSubject;

    public async Task RegisterServiceAsync(string serviceName, int port, IDictionary<string, string> properties)
    {
        _registeredServiceName = serviceName;
        _registeredPort = port;
        _registeredProperties = properties;

        // In production, you would register with a real DNS-SD service
        // This is a simplified implementation
    }

    public Task UnregisterServiceAsync()
    {
        _registeredServiceName = null;
        return Task.CompletedTask;
    }

    public async Task StartDiscoveryAsync()
    {
        _scanSubscription = Observable.Interval(_options.ScanInterval)
            .SelectMany(_ => DiscoverServicesAsync())
            .Subscribe(entry => 
            {
                if (_discoveredDevices.TryAdd(entry.Name, entry))
                {
                    _discoveredSubject.OnNext(entry);
                }
            });

        // Initial scan
        var entries = await DiscoverServicesAsync();
        foreach (var entry in entries)
        {
            if (_discoveredDevices.TryAdd(entry.Name, entry))
            {
                _discoveredSubject.OnNext(entry);
            }
        }
    }

    private async Task<IEnumerable<DnsServiceEntry>> DiscoverServicesAsync()
    {
        var query = $"{_options.ServiceType}.{_options.Domain}";
        var result = await _lookupClient.QueryAsync(query, QueryType.PTR);
        
        var entries = new List<DnsServiceEntry>();
        foreach (var ptrRecord in result.Answers.PtrRecords())
        {
            var srvResult = await _lookupClient.QueryAsync(ptrRecord.PtrDomainName, QueryType.SRV);
            var srvRecord = srvResult.Answers.SrvRecords().FirstOrDefault();
            
            if (srvRecord != null)
            {
                var txtResult = await _lookupClient.QueryAsync(ptrRecord.PtrDomainName, QueryType.TXT);
                var txtRecord = txtResult.Answers.TxtRecords().FirstOrDefault();
                
                var aResult = await _lookupClient.QueryAsync(srvRecord.Target, QueryType.A);
                var aRecords = aResult.Answers.ARecords().Select(a => a.Address).ToArray();
                
                var properties = txtRecord?.Text.FirstOrDefault()?
                    .Split(';')
                    .Select(p => p.Split('='))
                    .Where(p => p.Length == 2)
                    .ToDictionary(p => p[0], p => p[1]) ?? new Dictionary<string, string>();
                
                entries.Add(new DnsServiceEntry
                {
                    Name = ptrRecord.PtrDomainName,
                    Port = srvRecord.Port,
                    Addresses = aRecords,
                    Properties = properties
                });
            }
        }
        
        return entries;
    }

    public Task StopDiscoveryAsync()
    {
        _scanSubscription?.Dispose();
        _scanSubscription = null;
        _discoveredDevices.Clear();
        return Task.CompletedTask;
    }

    public void Dispose()
    {
        if (_disposed) return;

        _scanSubscription?.Dispose();
        _discoveredSubject.Dispose();
        _disposed = true;
    }
}

public static class DnsDiscoveryExtensions
{
    public static IServiceCollection AddDnsDiscoveryService(this IServiceCollection services, Action<DnsDiscoveryOptions> configure)
    {
        services.Configure(configure);
        services.AddSingleton<ILookupClient>(new LookupClient());
        services.AddSingleton<IDnsDiscoveryService, DnsDiscoveryService>();
        return services;
    }
}

// Usage example:
// var services = new ServiceCollection();
// services.AddDnsDiscoveryService(options => 
// {
//     options.ServiceType = "_myapp._tcp";
//     options.ScanInterval = TimeSpan.FromMinutes(1);
// });
// var provider = services.BuildServiceProvider();
// var dnsDiscovery = provider.GetRequiredService<IDnsDiscoveryService>();
// await dnsDiscovery.RegisterServiceAsync("MyDevice", 8080, new Dictionary<string, string> { ["key"] = "value" });
// await dnsDiscovery.StartDiscoveryAsync();