#:sdk Microsoft.NET.Sdk
#:package ImageGlass.Core@9.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Buffers;
using System.Threading.Channels;
using ImageGlass.Core;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.ObjectPool;

public interface IImageGlassProcessingService
{
    ValueTask<byte[]> ResizeImageAsync(byte[] imageData, int width, int height);
    ValueTask<byte[]> ApplyFilterAsync(byte[] imageData, FilterType filterType);
    ValueTask<byte[]> ConvertFormatAsync(byte[] imageData, ImageFormat format);
}

public class ImageGlassProcessingService : IImageGlassProcessingService
{
    private readonly ObjectPool<ImageGlassImage> _imagePool;
    private readonly Channel<ImageProcessingContext> _processingChannel;
    
    public ImageGlassProcessingService(ObjectPool<ImageGlassImage> imagePool)
    {
        _imagePool = imagePool;
        _processingChannel = Channel.CreateBounded<ImageProcessingContext>(1000);
        StartProcessingWorkers(4);
    }
    
    private void StartProcessingWorkers(int workerCount)
    {
        for (int i = 0; i < workerCount; i++)
        {
            _ = Task.Run(async () =>
            {
                await foreach (var context in _processingChannel.Reader.ReadAllAsync())
                {
                    using var image = _imagePool.Get();
                    // 处理逻辑
                }
            });
        }
    }
    
    public async ValueTask<byte[]> ResizeImageAsync(byte[] imageData, int width, int height)
    {
        using var image = _imagePool.Get();
        image.Item.LoadFromMemory(imageData);
        image.Item.Resize(width, height);
        return image.Item.SaveToMemory();
    }
    
    public async ValueTask<byte[]> ApplyFilterAsync(byte[] imageData, FilterType filterType)
    {
        using var image = _imagePool.Get();
        image.Item.LoadFromMemory(imageData);
        
        switch (filterType)
        {
            case FilterType.GaussianBlur:
                image.Item.ApplyGaussianBlur(5);
                break;
            case FilterType.Sharpen:
                image.Item.ApplySharpen();
                break;
        }
        
        return image.Item.SaveToMemory();
    }
    
    public async ValueTask<byte[]> ConvertFormatAsync(byte[] imageData, ImageFormat format)
    {
        using var image = _imagePool.Get();
        image.Item.LoadFromMemory(imageData);
        return image.Item.SaveToMemory(format.ToImageGlassFormat());
    }
}

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddImageGlassProcessing(this IServiceCollection services)
    {
        services.AddSingleton<ObjectPool<ImageGlassImage>>(sp =>
        {
            var policy = new ImageGlassImagePooledObjectPolicy();
            return new DefaultObjectPool<ImageGlassImage>(policy, 10);
        });
        
        services.AddSingleton<IImageGlassProcessingService, ImageGlassProcessingService>();
        return services;
    }
}

public enum FilterType { GaussianBlur, Sharpen }
public enum ImageFormat { Jpg, Png, Bmp }