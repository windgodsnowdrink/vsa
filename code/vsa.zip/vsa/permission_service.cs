#:sdk Microsoft.NET.Sdk
#:package Microsoft.AspNetCore.Authorization@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0

public interface IPermissionService
{
    Task<bool> HasPermissionAsync(string permission);
    Task<bool> HasRoleAsync(string role);
}

public class PermissionService : IPermissionService
{
    private readonly IHttpContextAccessor _httpContext;
    private readonly IAuthorizationService _authService;

    public PermissionService(
        IHttpContextAccessor httpContext,
        IAuthorizationService authService)
    {
        _httpContext = httpContext;
        _authService = authService;
    }

    public async Task<bool> HasPermissionAsync(string permission)
    {
        var user = _httpContext.HttpContext?.User;
        if(user == null) return false;
        
        var result = await _authService.AuthorizeAsync(
            user, null, new PermissionRequirement(permission));
            
        return result.Succeeded;
    }

    public async Task<bool> HasRoleAsync(string role)
    {
        var user = _httpContext.HttpContext?.User;
        return user?.IsInRole(role) ?? false;
    }
}

public class PermissionRequirement : IAuthorizationRequirement
{
    public string Permission { get; }
    
    public PermissionRequirement(string permission)
    {
        Permission = permission;
    }
}

public class PermissionHandler : AuthorizationHandler<PermissionRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        PermissionRequirement requirement)
    {
        if(context.User.HasClaim(c => 
            c.Type == "permission" && 
            c.Value == requirement.Permission))
        {
            context.Succeed(requirement);
        }
        return Task.CompletedTask;
    }
}