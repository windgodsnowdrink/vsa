#:sdk Microsoft.NET.Sdk.Web
#:package LibVLCSharp@3.8.0
#:package LibVLCSharp.WPF@3.8.0
#:package System.Threading.Channels@8.0.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Buffers;
using System.Threading.Channels;
using LibVLCSharp.Shared;
using LibVLCSharp.WPF;

// 1. 视频流处理器(高性能实现)
[SkipLocalsInit]
public sealed class VideoStreamProcessor : IDisposable
{
    private readonly LibVLC _libVlc;
    private readonly ThreadLocal<Span<byte>> _buffer;
    private readonly ObjectPool<MediaPlayer> _playerPool;
    private readonly Channel<VideoFrame> _frameChannel;
    
    public VideoStreamProcessor()
    {
        _libVlc = new LibVLC();
        _buffer = new(() => stackalloc byte[4096 * 4096 * 4]); // 4K帧缓冲区
        _playerPool = new DefaultObjectPool<MediaPlayer>(
            new MediaPlayerPooledPolicy(_libVlc), 4);
        _frameChannel = Channel.CreateBounded<VideoFrame>(1000);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe void ProcessStream(string streamUrl)
    {
        var player = _playerPool.Get();
        try
        {
            using var media = new Media(_libVlc, streamUrl);
            player.Play(media);
            
            // 设置视频回调
            player.SetVideoFormatCallbacks(SetupVideoFormat, CleanupVideoFormat);
            player.SetVideoCallbacks(LockVideo, null, DisplayVideo);
        }
        finally
        {
            _playerPool.Return(player);
        }
    }

    private unsafe IntPtr LockVideo(IntPtr opaque, IntPtr planes)
    {
        Span<byte> buffer = _buffer.Value;
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0) // Cache-line对齐
            {
                Marshal.WriteIntPtr(planes, (IntPtr)ptr);
                return (IntPtr)ptr;
            }
        }
        return IntPtr.Zero;
    }
}

// 2. 音频流处理器(零拷贝优化)
[SkipLocalsInit]
public sealed class AudioStreamProcessor : IDisposable
{
    private readonly LibVLC _libVlc;
    private readonly ThreadLocal<Span<byte>> _buffer;
    private readonly ObjectPool<Equalizer> _equalizerPool;
    
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe void ProcessAudio(string audioUrl)
    {
        using var mediaPlayer = new MediaPlayer(_libVlc);
        using var media = new Media(_libVlc, audioUrl);
        
        var equalizer = _equalizerPool.Get();
        try
        {
            mediaPlayer.SetEqualizer(equalizer);
            mediaPlayer.Play(media);
            
            // 设置音频回调
            mediaPlayer.SetAudioFormatCallbacks(SetupAudioFormat, CleanupAudioFormat);
            mediaPlayer.SetAudioCallbacks(PlayAudio, null, null, null);
        }
        finally
        {
            _equalizerPool.Return(equalizer);
        }
    }
}

// 3. 主程序集成
var builder = WebApplication.CreateBuilder();

// 注册流处理器服务
builder.Services.AddSingleton<VideoStreamProcessor>();
builder.Services.AddSingleton<AudioStreamProcessor>();

var app = builder.Build();
app.MapGet("/", () => "LibVLCSharp Streaming Ready");
app.Run();