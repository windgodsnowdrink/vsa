using System.Reflection;
using System.Buffers;
using System.Threading.Channels;
using System.Runtime.Loader;
using System.Security.Cryptography;
using Microsoft.Extensions.ObjectPool;

public static class SerilogExtensibilityExtensions
{
    /// <summary>
    /// 添加自定义Sink模板支持
    /// </summary>
    public static LoggerConfiguration WithFileRotation(this LoggerConfiguration config, 
        string pathTemplate = "logs/{Date}-{Hour}.log",
        RollingInterval rollingInterval = RollingInterval.Day,
        int retainedFileCountLimit = 31,
        long? fileSizeLimitBytes = 1073741824) // 1GB
    {
        return config.WriteTo.File(
            path: pathTemplate,
            rollingInterval: rollingInterval,
            retainedFileCountLimit: retainedFileCountLimit,
            fileSizeLimitBytes: fileSizeLimitBytes,
            rollOnFileSizeLimit: true,
            hooks: new LogFileLifecycleHooks());
    }

    /// <summary>
    /// 添加插件式架构支持
    /// </summary>
    public static LoggerConfiguration WithPlugins(
        this LoggerConfiguration config, 
        string pluginsDirectory,
        Action<AssemblyLoadContext, Assembly> onPluginLoaded = null)
    {
        var loadContext = new AssemblyLoadContext("SerilogPlugins", true);
        
        foreach (var pluginPath in Directory.GetFiles(pluginsDirectory, "*.dll"))
        {
            try
            {
                var assembly = loadContext.LoadFromAssemblyPath(pluginPath);
                var pluginTypes = assembly.GetTypes()
                    .Where(t => typeof(ISerilogPlugin).IsAssignableFrom(t) && !t.IsAbstract);
                
                foreach (var type in pluginTypes)
                {
                    var plugin = (ISerilogPlugin)Activator.CreateInstance(type);
                    plugin.Configure(config);
                }
                
                onPluginLoaded?.Invoke(loadContext, assembly);
            }
            catch (Exception ex)
            {
                Log.Warning(ex, "Failed to load plugin {PluginPath}", pluginPath);
            }
        }
        
        return config;
    }

    /// <summary>
    /// 添加自定义Enricher支持
    /// </summary>
    public static LoggerConfiguration WithCustomEnricher<T>
        (this LoggerConfiguration config, 
        Action<T> configure = null) where T : ILogEventEnricher
    {
        var enricher = Activator.CreateInstance<T>();
        configure?.Invoke(enricher);
        return config.Enrich.With(enricher);
    }
}

public interface ISerilogPlugin
{
    void Configure(LoggerConfiguration configuration);
}

public class HighPerformanceLogQueue
{
    private readonly Channel<LogEvent> _channel;
    private readonly ArrayPool<byte> _bufferPool;
    private readonly Aes _aes;
    
    public HighPerformanceLogQueue(int capacity = 10000)
    {
        _channel = Channel.CreateBounded<LogEvent>(capacity);
        _bufferPool = ArrayPool<byte>.Shared;
        _aes = Aes.Create();
        _aes.GenerateKey();
        _aes.GenerateIV();
    }
    
    public async ValueTask EnqueueAsync(LogEvent logEvent)
    {
        await _channel.Writer.WriteAsync(logEvent);
    }
    
    public IAsyncEnumerable<LogEvent> DequeueAsync(CancellationToken cancellationToken)
    {
        return _channel.Reader.ReadAllAsync(cancellationToken);
    }
    
    public byte[] RentBuffer(int size) => _bufferPool.Rent(size);
    
    public void ReturnBuffer(byte[] buffer) => _bufferPool.Return(buffer);
}

public static class DataMaskingExtensions
{
    public static LoggerConfiguration WithDataMasking(
        this LoggerConfiguration config, 
        params string[] sensitiveProperties)
    {
        return config.Enrich.With(new DataMaskingEnricher(sensitiveProperties));
    }
}

public class DataMaskingEnricher : ILogEventEnricher
{
    private readonly string[] _sensitiveProperties;
    
    public DataMaskingEnricher(string[] sensitiveProperties)
    {
        _sensitiveProperties = sensitiveProperties;
    }
    
    public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
    {
        foreach (var prop in logEvent.Properties.Where(p => 
            _sensitiveProperties.Contains(p.Key)))
        {
            logEvent.AddOrUpdateProperty(propertyFactory
                .CreateProperty(prop.Key, "******"));
        }
    }
}

public static class SerilogExtensibilityProductionExtensions
{
    public static IServiceCollection AddSerilogExtensibility(this IServiceCollection services)
    {
        services.AddSingleton<AssemblyLoadContext>(sp => 
            new AssemblyLoadContext("SerilogPlugins", true));
            
        services.AddSingleton<HighPerformanceLogQueue>();
        services.AddSingleton<DataMaskingEnricher>();
        
        // Prometheus metrics
        services.AddSingleton<SerilogMetrics>();
        
        // OpenTelemetry integration
        services.AddOpenTelemetry()
            .WithMetrics(metrics => metrics
                .AddMeter("Serilog.Metrics"))
            .WithTracing(tracing => tracing
                .AddSource("Serilog.Tracing"));
        
        return services;
    }
}