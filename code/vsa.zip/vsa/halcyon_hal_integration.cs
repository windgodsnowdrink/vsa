#:sdk Microsoft.NET.Sdk.Web
#:package Halcyon@2.4.0
#:package Microsoft.AspNetCore.Mvc.Versioning@5.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Halcyon.HAL;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder();

// 配置HAL支持
builder.Services.AddControllers()
    .AddHalcyon();

// 添加分层内存管理
builder.Services.AddTieredMemory(options =>
{
    options.EnableThreadLocalSpan = true;
    options.CacheLineAlignment = 64;
});

// 添加零拷贝序列化
builder.Services.AddZeroCopySerialization();

var app = builder.Build();

app.UseRouting();

// 示例HAL响应
app.MapGet("/products/{id}", (int id) =>
{
    var product = new ProductResource 
    { 
        Id = id, 
        Name = "示例产品", 
        Price = 99.99m 
    };

    // 使用Span优化内存分配
    var halResponse = new HALResponse(product)
        .AddLinks(new Link[] {
            new Link("self", $"/products/{id}"),
            new Link("collection", "/products")
        });

    return Results.Ok(halResponse);
});

app.Run();

// 示例资源模型
public class ProductResource
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}