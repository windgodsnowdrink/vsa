#:sdk Microsoft.NET.Sdk
#:package NetServerCore@2.0.0
#:package Microsoft.Extensions.Http@8.0.0
#:package OpenTelemetry.Extensions.Hosting@1.7.0
#:package System.Threading.RateLimiting@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using System.Net;
using System.Net.Sockets;
using System.Threading.Channels;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

public class NetServerCoreOptions
{
    public int MaxConnections { get; set; } = 1000;
    public int ReceiveBufferSize { get; set; } = 8192;
    public int SendBufferSize { get; set; } = 8192;
    public TimeSpan HeartbeatInterval { get; set; } = TimeSpan.FromSeconds(30);
    public ProtocolType ProtocolType { get; set; } = ProtocolType.Tcp;
    public IPEndPoint EndPoint { get; set; } = new IPEndPoint(IPAddress.Any, 5000);
    
    // 新增配置项
    public bool EnableDistributedRouting { get; set; } = false;
    public string[]? RoutingNodes { get; set; }
    public int TokenBucketCapacity { get; set; } = 1000;
    public int TokensPerPeriod { get; set; } = 100;
    public TimeSpan ReplenishmentPeriod { get; set; } = TimeSpan.FromSeconds(1);
    public bool EnableOpenTelemetry { get; set; } = true;
}

public interface INetServerCoreService
{
    Task StartAsync(CancellationToken cancellationToken);
    Task StopAsync(CancellationToken cancellationToken);
    ValueTask SendAsync(ReadOnlyMemory<byte> data, CancellationToken cancellationToken = default);
    
    // 新增接口方法
    ValueTask RouteMessageAsync(string nodeId, ReadOnlyMemory<byte> data, CancellationToken cancellationToken = default);
    ValueTask BroadcastAsync(ReadOnlyMemory<byte> data, CancellationToken cancellationToken = default);
}

public class NetServerCoreService : INetServerCoreService, IAsyncDisposable
{
    private readonly NetServerCoreOptions _options;
    private readonly Channel<ReadOnlyMemory<byte>> _messageChannel;
    private readonly ILogger<NetServerCoreService> _logger;
    private Socket? _socket;
    private Task? _processingTask;
    private CancellationTokenSource? _cts;

    public NetServerCoreService(
        IOptions<NetServerCoreOptions> options,
        ILogger<NetServerCoreService> logger)
    {
        _options = options.Value;
        _logger = logger;
        _messageChannel = Channel.CreateBounded<ReadOnlyMemory<byte>>(new BoundedChannelOptions(10000)
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleReader = true,
            SingleWriter = false
        });
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        _socket = new Socket(_options.EndPoint.AddressFamily, SocketType.Stream, _options.ProtocolType);
        _socket.Bind(_options.EndPoint);
        _socket.Listen(_options.MaxConnections);

        _processingTask = Task.Run(() => ProcessMessagesAsync(_cts.Token));
        _logger.LogInformation("NetServerCore started on {EndPoint}", _options.EndPoint);
    }

    public async Task StopAsync(CancellationToken cancellationToken)
    {
        _cts?.Cancel();
        _socket?.Dispose();
        if (_processingTask != null)
            await _processingTask;
    }

    public ValueTask SendAsync(ReadOnlyMemory<byte> data, CancellationToken cancellationToken = default)
    {
        return _messageChannel.Writer.WriteAsync(data, cancellationToken);
    }

    private async Task ProcessMessagesAsync(CancellationToken cancellationToken)
    {
        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                var data = await _messageChannel.Reader.ReadAsync(cancellationToken);
                // 处理消息逻辑
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("Message processing stopped");
        }
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync(default);
        _cts?.Dispose();
    }
}

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddNetServerCore(this IServiceCollection services, Action<NetServerCoreOptions> configure)
    {
        services.Configure(configure);
        services.AddSingleton<INetServerCoreService, NetServerCoreService>();
        services.AddHostedService(provider => (NetServerCoreService)provider.GetRequiredService<INetServerCoreService>());
        return services;
    }
}