#:sdk Microsoft.NET.Sdk.Web
#:package System.Text.Json@8.0.0
#:package Microsoft.IO.RecyclableMemoryStream@3.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Buffers;
using System.IO.Pipelines;
using System.Text.Json;
using Microsoft.IO;

public class IpcJsonSerializer : IAsyncDisposable
{
    private readonly Pipe _pipe;
    private readonly RecyclableMemoryStreamManager _memoryManager;
    private readonly Task _processingTask;
    private readonly CancellationTokenSource _cts = new();

    public IpcJsonSerializer()
    {
        _memoryManager = new RecyclableMemoryStreamManager();
        _pipe = new Pipe(new PipeOptions(
            pool: _memoryManager,
            readerScheduler: PipeScheduler.Inline,
            writerScheduler: PipeScheduler.Inline,
            pauseWriterThreshold: 1024 * 1024,
            resumeWriterThreshold: 512 * 1024,
            minimumSegmentSize: 4096));

        _processingTask = Task.Run(ProcessPipeAsync);
    }

    public async ValueTask SerializeAsync<T>(T value)
    {
        using var memoryStream = _memoryManager.GetStream();
        await JsonSerializer.SerializeAsync(memoryStream, value, new JsonSerializerOptions
        {
            WriteIndented = false,
            DefaultBufferSize = 4096,
            MaxDepth = 64,
            ReferenceHandler = ReferenceHandler.IgnoreCycles
        });

        memoryStream.Position = 0;
        await memoryStream.CopyToAsync(_pipe.Writer, _cts.Token);
        await _pipe.Writer.FlushAsync(_cts.Token);
    }

    public async ValueTask<T?> DeserializeAsync<T>()
    {
        var result = await JsonSerializer.DeserializeAsync<T>(_pipe.Reader.AsStream(), new JsonSerializerOptions
        {
            DefaultBufferSize = 4096,
            MaxDepth = 64,
            PropertyNameCaseInsensitive = true
        }, _cts.Token);

        return result;
    }

    private async Task ProcessPipeAsync()
    {
        while (!_cts.IsCancellationRequested)
        {
            var readResult = await _pipe.Reader.ReadAsync(_cts.Token);
            if (readResult.IsCompleted || readResult.IsCanceled)
                break;

            _pipe.Reader.AdvanceTo(readResult.Buffer.End);
        }
    }

    public async ValueTask DisposeAsync()
    {
        _cts.Cancel();
        await _processingTask;
        _pipe.Reader.Complete();
        _pipe.Writer.Complete();
    }
}

// 启动配置
var builder = WebApplication.CreateBuilder();
builder.Services.AddSingleton<IpcJsonSerializer>();

var app = builder.Build();
app.MapGet("/", () => "IPC JSON Serializer Ready");
app.Run();