#:sdk Microsoft.NET.Sdk.Web
#:package System.Threading.Tasks.Dataflow@8.0.0
#:package MassTransit@8.2.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Threading.Tasks.Dataflow;

public class SagaOrchestrator
{
    private readonly TransformBlock<SagaCommand, SagaStep> _commandBlock;
    private readonly ActionBlock<SagaStep> _executionBlock;
    private readonly BufferBlock<SagaStep> _compensationBlock;

    public SagaOrchestrator()
    {
        var options = new ExecutionDataflowBlockOptions
        {
            BoundedCapacity = 10000,
            MaxDegreeOfParallelism = 1, // Saga需要顺序执行
            EnsureOrdered = true
        };

        _commandBlock = new TransformBlock<SagaCommand, SagaStep>(cmd =>
        {
            // 命令转换逻辑
            return new SagaStep(cmd);
        }, options);

        _executionBlock = new ActionBlock<SagaStep>(async step =>
        {
            try
            {
                // 执行步骤逻辑
                await step.ExecuteAsync();
            }
            catch
            {
                _compensationBlock.Post(step);
                throw;
            }
        }, options);

        _compensationBlock = new BufferBlock<SagaStep>();
        
        _commandBlock.LinkTo(_executionBlock);
    }
}

public record SagaCommand(string Id);
public record SagaStep(SagaCommand Command);