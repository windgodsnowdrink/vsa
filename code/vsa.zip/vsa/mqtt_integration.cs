#:sdk Microsoft.NET.Sdk.Web
#:package MagicOnion@5.0.0
#:package MQTTnet@4.1.5
#:package System.Threading.Channels@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using MagicOnion;
using MQTTnet;
using MQTTnet.Client;
using System.Threading.Channels;

var builder = WebApplication.CreateBuilder();

// 1. MQTT客户端配置
builder.Services.AddSingleton<IMqttClient>(sp => 
    new MqttFactory().CreateMqttClient());

// 2. 高性能消息通道
var mqttChannel = Channel.CreateBounded<MqttMessage>(
    new BoundedChannelOptions(10000)
    {
        SingleReader = true,
        AllowSynchronousContinuations = true,
        FullMode = BoundedChannelFullMode.Wait
    });

// 3. 零拷贝消息处理器
builder.Services.AddSingleton<IMqttProcessor>(sp => 
    new ChannelMqttProcessor(
        mqttChannel,
        new ThreadLocal<Span<byte>>(() => stackalloc byte[1024])));

var app = builder.Build();
app.MapGet("/", () => "MQTT Integration Ready");
app.Run();

// MQTT消息处理器
[SkipLocalsInit]
public class ChannelMqttProcessor : IMqttProcessor
{
    private readonly ChannelWriter<MqttMessage> _writer;
    private readonly ThreadLocal<Span<byte>> _buffer;
    
    public ChannelMqttProcessor(Channel<MqttMessage> channel, ThreadLocal<Span<byte>> buffer)
    {
        _writer = channel.Writer;
        _buffer = buffer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe void Process(MqttMessage message)
    {
        Span<byte> buffer = stackalloc byte[1024];
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0) // Cache-line对齐
            {
                // SIMD优化处理MQTT消息
                _writer.TryWrite(message);
            }
        }
    }
}

[MessagePackObject]
public class MqttMessage
{
    [Key(0)]
    public string Topic { get; set; }
    
    [Key(1)]
    public byte[] Payload { get; set; }
    
    [Key(2)]
    public MqttQualityOfServiceLevel Qos { get; set; }
}