#:sdk Microsoft.NET.Sdk
#:package MassTransit@8.2.2
#:package MassTransit.RabbitMQ@8.2.2
#:package MassTransit.EntityFrameworkCore@8.2.2
#:package Microsoft.Extensions.Hosting@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System;
using System.Threading.Tasks;
using MassTransit;
using MassTransit.EntityFrameworkCoreIntegration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

/// <summary>
/// MassTransit配置选项
/// </summary>
public sealed class MassTransitOptions
{
    /// <summary>
    /// RabbitMQ连接字符串
    /// </summary>
    public string RabbitMqConnectionString { get; set; } = "amqp://localhost";
    
    /// <summary>
    /// 重试次数
    /// </summary>
    public int RetryCount { get; set; } = 3;
    
    /// <summary>
    /// 并发消息处理数量
    /// </summary>
    public int ConcurrentMessageLimit { get; set; } = 10;
    
    /// <summary>
    /// 消息过期时间(秒)
    /// </summary>
    public int MessageTtl { get; set; } = 86400;
}

/// <summary>
/// 订单消息事件
/// </summary>
public record OrderCreatedEvent(Guid OrderId, string CustomerName, decimal Amount, DateTimeOffset Timestamp);

/// <summary>
/// 订单处理消费者
/// </summary>
public sealed class OrderCreatedConsumer : IConsumer<OrderCreatedEvent>
{
    private readonly ILogger<OrderCreatedConsumer> _logger;

    public OrderCreatedConsumer(ILogger<OrderCreatedConsumer> logger)
    {
        _logger = logger;
    }

    public async Task Consume(ConsumeContext<OrderCreatedEvent> context)
    {
        _logger.LogInformation("Processing order {OrderId} for {CustomerName}", 
            context.Message.OrderId, context.Message.CustomerName);
        
        // 模拟业务处理
        await Task.Delay(100);
        
        // 可以发布新事件
        await context.Publish(new OrderProcessedEvent(
            context.Message.OrderId, 
            DateTimeOffset.UtcNow));
    }
}

/// <summary>
/// 订单处理完成事件
/// </summary>
public record OrderProcessedEvent(Guid OrderId, DateTimeOffset ProcessedTime);

/// <summary>
/// 订单状态Saga状态机
/// </summary>
public sealed class OrderStateMachine : MassTransitStateMachine<OrderState>
{
    public OrderStateMachine()
    {
        InstanceState(x => x.CurrentState);
        
        Event(() => OrderCreated, x => x.CorrelateById(context => context.Message.OrderId));
        Event(() => OrderProcessed, x => x.CorrelateById(context => context.Message.OrderId));
        
        Initially(
            When(OrderCreated)
                .Then(context => 
                {
                    context.Saga.CustomerName = context.Message.CustomerName;
                    context.Saga.Amount = context.Message.Amount;
                })
                .TransitionTo(Processing));
                
        During(Processing,
            When(OrderProcessed)
                .Finalize());
                
        SetCompletedWhenFinalized();
    }
    
    public State Processing { get; private set; }
    public Event<OrderCreatedEvent> OrderCreated { get; private set; }
    public Event<OrderProcessedEvent> OrderProcessed { get; private set; }
}

/// <summary>
/// 订单Saga状态
/// </summary>
public class OrderState : SagaStateMachineInstance
{
    public Guid CorrelationId { get; set; }
    public string CurrentState { get; set; }
    public string CustomerName { get; set; }
    public decimal Amount { get; set; }
}

/// <summary>
/// Saga持久化DbContext
/// </summary>
public class OrderStateDbContext : SagaDbContext
{
    public OrderStateDbContext(DbContextOptions<OrderStateDbContext> options)
        : base(options)
    {
    }

    protected override IEnumerable<ISagaClassMap> Configurations
    {
        get { yield return new OrderStateMap(); }
    }
}

/// <summary>
/// Saga状态映射
/// </summary>
public class OrderStateMap : SagaClassMap<OrderState>
{
    protected override void Configure(EntityTypeBuilder<OrderState> entity, ModelBuilder model)
    {
        entity.Property(x => x.CurrentState).HasMaxLength(64);
        entity.Property(x => x.CustomerName).HasMaxLength(256);
    }
}

/// <summary>
/// DI容器扩展方法
/// </summary>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddMassTransitProduction(this IServiceCollection services, Action<MassTransitOptions> configure)
    {
        services.Configure(configure);
        
        // 添加Saga持久化
        services.AddDbContext<OrderStateDbContext>(options => 
            options.UseSqlite("Data Source=orders.db"));
        
        services.AddMassTransit(busConfigurator =>
        {
            // 配置RabbitMQ
            busConfigurator.UsingRabbitMq((context, cfg) =>
            {
                var options = context.GetRequiredService<IOptions<MassTransitOptions>>().Value;
                
                cfg.Host(options.RabbitMqConnectionString);
                
                // 配置重试策略
                cfg.UseMessageRetry(r => r.Immediate(options.RetryCount));
                
                // 配置并发限制
                cfg.PrefetchCount = options.ConcurrentMessageLimit;
                
                // 配置消息TTL
                cfg.SetQueueArgument("x-message-ttl", options.MessageTtl * 1000);
                
                // 配置消费者
                cfg.ReceiveEndpoint("order-created-queue", e =>
                {
                    e.ConcurrentMessageLimit = options.ConcurrentMessageLimit;
                    e.ConfigureConsumer<OrderCreatedConsumer>(context);
                });
                
                // 配置Saga
                cfg.ReceiveEndpoint("order-saga", e =>
                {
                    e.StateMachineSaga(new OrderStateMachine(), new OrderStateDbContext(context));
                });
            });
            
            // 注册消费者
            busConfigurator.AddConsumer<OrderCreatedConsumer>();
            
            // 注册Saga
            busConfigurator.AddSagaStateMachine<OrderStateMachine, OrderState>()
                .EntityFrameworkRepository(r =>
                {
                    r.ExistingDbContext<OrderStateDbContext>();
                    r.LockStatementProvider = new SqliteLockStatementProvider();
                });
        });
        
        return services;
    }
}

/// <summary>
/// 后台服务启动MassTransit
/// </summary>
public sealed class MassTransitBackgroundService : BackgroundService
{
    private readonly IBusControl _bus;
    
    public MassTransitBackgroundService(IBusControl bus)
    {
        _bus = bus;
    }
    
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await _bus.StartAsync(stoppingToken);
    }
    
    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        await _bus.StopAsync(cancellationToken);
        await base.StopAsync(cancellationToken);
    }
}

/// <summary>
/// 示例程序
/// </summary>
public static class Program
{
    public static async Task Main(string[] args)
    {
        var host = Host.CreateDefaultBuilder(args)
            .ConfigureServices(services =>
            {
                services.AddMassTransitProduction(options =>
                {
                    options.RabbitMqConnectionString = "amqp://localhost";
                    options.RetryCount = 5;
                    options.ConcurrentMessageLimit = 20;
                });
                
                services.AddHostedService<MassTransitBackgroundService>();
            })
            .Build();
            
        await host.RunAsync();
    }
}

// 添加更多MassTransit生产级集成示例
public static class AdvancedMassTransitScenarios
{
    // 1. 基于RabbitMQ的优先级队列实现
    public static void ConfigurePriorityQueue(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        cfg.ReceiveEndpoint(host, "priority-queue", e =>
        {
            e.PrefetchCount = 100;
            e.EnablePriority(4); // 支持4个优先级级别
            e.UseMessageRetry(r => r.Interval(5, 1000));
            
            // 消费者配置
            e.Consumer<PriorityOrderConsumer>(c =>
            {
                c.Options<BatchOptions>(o => o.SetMessageLimit(100).SetTimeLimit(1000));
                c.Message<PriorityOrder>(m => m.SetEntityName("priority-order"));
            });
        });
    }

    // 2. 基于Saga的分布式事务补偿
    public class OrderSaga : MassTransitStateMachine<OrderSagaState>
    {
        public OrderSaga()
        {
            InstanceState(x => x.CurrentState);
            
            Event(() => OrderSubmitted, x => x.CorrelateById(m => m.Message.OrderId));
            Event(() => PaymentCompleted, x => x.CorrelateById(m => m.Message.OrderId));
            Event(() => InventoryReserved, x => x.CorrelateById(m => m.Message.OrderId));
            
            Initially(
                When(OrderSubmitted)
                    .Then(ctx => ctx.Instance.OrderDate = DateTime.UtcNow)
                    .TransitionTo(Submitted)
                    .Publish(ctx => new ReserveInventory(ctx.Instance.OrderId)));
                    
            During(Submitted,
                When(PaymentCompleted)
                    .Then(ctx => ctx.Instance.PaymentDate = DateTime.UtcNow)
                    .If(ctx => ctx.Instance.InventoryReserved,
                        then => then.TransitionTo(Completed)
                            .Finalize()));
                            
            SetCompletedWhenFinalized();
        }
        
        // 状态定义
        public State Submitted { get; private set; }
        public State Completed { get; private set; }
        
        // 事件定义
        public Event<OrderSubmitted> OrderSubmitted { get; private set; }
        public Event<PaymentCompleted> PaymentCompleted { get; private set; }
        public Event<InventoryReserved> InventoryReserved { get; private set; }
    }

    // 3. 基于RateLimiter的流量控制
    public static void ConfigureRateLimitedEndpoint(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        var rateLimiter = RateLimiter.CreateSlidingWindow(100, TimeSpan.FromSeconds(1));
        
        cfg.ReceiveEndpoint(host, "rate-limited-queue", e =>
        {
            e.UseRateLimit(rateLimiter);
            e.UseConcurrencyLimit(10);
            
            e.Consumer<RateLimitedConsumer>(c =>
            {
                c.UseMessageRetry(r => r.Interval(3, 1000));
                c.UseInMemoryOutbox();
            });
        });
    }

    // 4. 基于Kafka的批量消息处理
    public static void ConfigureKafkaBatchConsumer(IKafkaBusFactoryConfigurator cfg)
    {
        cfg.TopicEndpoint<BatchMessage>("batch-topic", "consumer-group", e =>
        {
            e.AutoOffsetReset = AutoOffsetReset.Latest;
            e.ConfigureBatch<BatchMessage>(b =>
            {
                b.MessageLimit = 1000;
                b.TimeLimit = TimeSpan.FromMilliseconds(500);
                b.ConcurrencyLimit = 10;
            });
            
            e.Handler<BatchMessage>(async context =>
            {
                await ProcessBatchAsync(context.Message);
            });
        });
    }

    // 5. 基于条件路由的消息分发
    public static void ConfigureConditionalRouting(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        cfg.ReceiveEndpoint(host, "order-processing", e =>
        {
            e.UseMessageRetry(r => r.Interval(3, 1000));
            
            e.Consumer<OrderConsumer>(c =>
            {
                c.Message<Order>(m => 
                {
                    // 根据订单金额路由到不同处理逻辑
                    m.UseContext((ctx, msg) => msg.Amount > 1000 ? "high-value" : "normal");
                });
            });
        });
    }

    // 6. 延迟消息处理
    public static void ConfigureMessageTransformation(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        // 消息转换器实现
        cfg.Transform<OrderCreatedEvent>(x =>
        {
            x.Replace = true;
            x.SetTransformFactory(context => new OrderTransformedEvent(context.Message.OrderId));
        });
    }

    public static void ConfigureConditionalRouting(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        // 条件路由实现
        cfg.Send<OrderCreatedEvent>(x =>
        {
            x.UseRoutingKeyFormatter(context => context.Message.Priority.ToString());
            x.BindQueue("orders", e => e.RoutingKey = "1");
        });
    }

    public static void ConfigureExceptionHandling(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        // 异常处理和死信队列
        cfg.ReceiveEndpoint("order-queue", e =>
        {
            e.UseMessageRetry(r => r.Interval(5, 1000));
            e.ConfigureDeadLetterQueue("order-queue-dead-letter");
            e.DiscardFaultedMessages();
        });
    }

    public static void ConfigureDelayedMessage(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        cfg.ReceiveEndpoint(host, "delayed-orders", e =>
        {
            // 使用RabbitMQ延迟插件
            e.UseDelayedRedelivery(r => r.Interval(5, TimeSpan.FromSeconds(30)));
            
            e.Consumer<DelayedOrderConsumer>(c =>
            {
                c.UseScheduledRedelivery(r => r.Intervals(TimeSpan.FromMinutes(5), TimeSpan.FromMinutes(15)));
            });
        });
    }

    // 7. 异常处理和死信队列
    public static void ConfigureErrorHandling(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        cfg.ReceiveEndpoint(host, "order-errors", e =>
        {
            e.BindDeadLetterQueue(host, "order-processing");
            
            e.Consumer<ErrorOrderConsumer>(c =>
            {
                c.UseMessageRetry(r => 
                {
                    r.Interval(3, TimeSpan.FromSeconds(10));
                    r.Ignore<ValidationException>();
                });
                
                c.UseCircuitBreaker(cb =>
                {
                    cb.TrackingPeriod = TimeSpan.FromMinutes(1);
                    cb.TripThreshold = 15;
                    cb.ActiveThreshold = 10;
                });
            });
        });
    }

    // 8. 消息转换器
    public static void ConfigureMessageTransformer(IRabbitMqBusFactoryConfigurator cfg, IRabbitMqHost host)
    {
        cfg.ReceiveEndpoint(host, "order-transform", e =>
        {
            e.UseTransform<Order>(x => 
            {
                x.Replace(c => new TransformedOrder(c.Message.Id, c.Message.Amount * 1.1m));
            });
            
            e.Consumer<TransformedOrderConsumer>();
        });
    }
}