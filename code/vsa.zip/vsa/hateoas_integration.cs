#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.AspNetCore.Mvc.NewtonsoftJson@6.0.0
#:package Microsoft.Extensions.Caching.Memory@6.0.0
#:package Microsoft.AspNetCore.Mvc.Versioning@5.0.0
#:package Prometheus.Client.AspNetCore@4.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.AspNetCore.Mvc.Versioning;
using Prometheus.Client;
using Prometheus.Client.AspNetCore;

public record Link(string Href, string Rel, string Method);

public abstract class Resource
{
    [JsonPropertyName("_links")]
    public List<Link> Links { get; set; } = new();

    public void AddLink(string href, string rel, string method)
    {
        Links.Add(new Link(href, rel, method));
    }
}

public record Product(int Id, string Name, decimal Price) : Resource;

[ApiController]
[Route("api/v{version:apiVersion}/[controller]")]
[ApiVersion("1.0")]
public class ProductsController : ControllerBase
{
    private static readonly List<Product> _products = new()
    {
        new(1, "Product 1", 10.99m),
        new(2, "Product 2", 20.99m)
    };

    private readonly IMemoryCache _cache;
    private static readonly IMetricFamily<ICounter> _apiCallsCounter = 
        Metrics.DefaultFactory.CreateCounter("hateoas_api_calls_total", "Total API calls count", "method", "version");

    public ProductsController(IMemoryCache cache)
    {
        _cache = cache;
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        _apiCallsCounter.WithLabels("GET", "1.0").Inc();
        
        const string cacheKey = "products_all";
        
        if (_cache.TryGetValue(cacheKey, out List<Product> cachedProducts))
        {
            return Ok(new 
            {
                _links = new List<Link>
                {
                    new("/api/v1/products", "self", "GET"),
                    new("/api/v1/products", "create", "POST")
                },
                items = cachedProducts
            });
        }

        var products = _products.Select(p =>
        {
            p.AddLink($"/api/v1/products/{p.Id}", "self", "GET");
            p.AddLink($"/api/v1/products/{p.Id}", "update", "PUT");
            p.AddLink($"/api/v1/products/{p.Id}", "delete", "DELETE");
            return p;
        }).ToList();

        _cache.Set(cacheKey, products, TimeSpan.FromMinutes(5));
        
        var resource = new
        {
            _links = new List<Link>
            {
                new("/api/v1/products", "self", "GET"),
                new("/api/v1/products", "create", "POST")
            },
            items = products
        };

        return Ok(resource);
    }

    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var product = _products.FirstOrDefault(p => p.Id == id);
        if (product == null) return NotFound();

        product.AddLink($"/api/products/{product.Id}", "self", "GET");
        product.AddLink($"/api/products", "collection", "GET");
        product.AddLink($"/api/products/{product.Id}", "update", "PUT");
        product.AddLink($"/api/products/{product.Id}", "delete", "DELETE");

        return Ok(product);
    }

    [HttpPost]
    public IActionResult Create([FromBody] Product product)
    {
        _products.Add(product);
        return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        
        // 添加内存缓存
        builder.Services.AddMemoryCache();
        
        // 配置API版本控制
        builder.Services.AddApiVersioning(options =>
        {
            options.DefaultApiVersion = new ApiVersion(1, 0);
            options.AssumeDefaultVersionWhenUnspecified = true;
            options.ReportApiVersions = true;
        });
        
        builder.Services.AddControllers()
            .AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
                options.SerializerSettings.Formatting = Newtonsoft.Json.Formatting.Indented;
            });

        var app = builder.Build();
        
        // 添加Prometheus监控
        app.UsePrometheusServer();
        
        app.UseRouting();
        app.UseEndpoints(endpoints => endpoints.MapControllers());
        
        app.Run();
    }
}