#:sdk Microsoft.NET.Sdk.Web
#:package Grpc.AspNetCore@2.62.0
#:package protobuf-net.Grpc@1.0.693
#:package Linkerd.Client@0.3.0
#:package OpenTelemetry.Exporter.OpenTelemetryProtocol@1.6.0
#:package Polly@8.0.0
#:package Microsoft.Extensions.Http.Polly@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Grpc.Core;
using ProtoBuf;
using System.Threading.Channels;
using System.Runtime.CompilerServices;
using Linkerd;
using OpenTelemetry.Trace;
using OpenTelemetry.Resources;
using Polly;

var builder = WebApplication.CreateBuilder();

// 1. 服务网格集成 (Linkerd)
builder.Services.AddLinkerdClient(options =>
{
    options.ControlPlaneAddr = "linkerd-proxy-api:8086";
    options.EnableTLS = true;
});

// 2. 分布式追踪 (OpenTelemetry)
builder.Services.AddOpenTelemetry()
    .WithTracing(tracing => tracing
        .SetResourceBuilder(ResourceBuilder.CreateDefault()
            .AddService("GrpcTodoService")
            .AddTelemetrySdk())
        .AddAspNetCoreInstrumentation(o => 
        {
            o.RecordException = true;
            o.EnableGrpcAspNetCoreSupport = true;
        })
        .AddGrpcClientInstrumentation()
        .AddOtlpExporter(o => 
            o.Endpoint = new Uri("http://localhost:4317")));

// 3. 混沌工程支持 (Polly)
builder.Services.AddHttpClient("chaos-http")
    .AddPolicyHandler(Policy<HttpResponseMessage>
        .Handle<Exception>()
        .CircuitBreakerAsync(5, TimeSpan.FromSeconds(30)))
    .AddPolicyHandler(Policy<HttpResponseMessage>
        .HandleResult(r => (int)r.StatusCode >= 500)
        .WaitAndRetryAsync(3, _ => TimeSpan.FromSeconds(1)));

// 1. gRPC服务配置
builder.Services.AddGrpc(options => 
{
    options.MaxReceiveMessageSize = 10 * 1024 * 1024; // 10MB
    options.EnableDetailedErrors = true;
    options.Interceptors.Add<ChaosInterceptor>();
    options.Interceptors.Add<TracingInterceptor>();
});

// 2. 高性能通道
var todoChannel = Channel.CreateBounded<TodoItem>(
    new BoundedChannelOptions(10000)
    {
        SingleReader = true,
        AllowSynchronousContinuations = true,
        FullMode = BoundedChannelFullMode.Wait
    });

// 3. 零拷贝处理器
builder.Services.AddSingleton<ITodoProcessor>(sp => 
    new TodoChannelProcessor(
        todoChannel,
        new ThreadLocal<Span<byte>>(() => stackalloc byte[1024])));

var app = builder.Build();
app.MapGrpcService<TodoService>();
app.MapGet("/", () => "gRPC Todo Service Ready");
app.Run();

// ProtoBuf契约定义
[ProtoContract]
public class TodoItem
{
    [ProtoMember(1)]
    public int Id { get; set; }
    
    [ProtoMember(2)]
    public string Title { get; set; }
    
    [ProtoMember(3)]
    public bool IsCompleted { get; set; }
}

// gRPC服务接口
[ServiceContract]
public interface ITodoService
{
    [OperationContract]
    ValueTask<TodoItem> GetTodoAsync(int id);
    
    [OperationContract]
    IAsyncEnumerable<TodoItem> StreamTodosAsync();
}

// gRPC服务实现
public class TodoService : ITodoService
{
    private readonly ITodoProcessor _processor;
    
    public TodoService(ITodoProcessor processor)
    {
        _processor = processor;
    }

    public async ValueTask<TodoItem> GetTodoAsync(int id)
    {
        // ... existing code ...
    }

    public async IAsyncEnumerable<TodoItem> StreamTodosAsync()
    {
        // ... existing code ...
    }
}

// 高性能处理器
[SkipLocalsInit]
public class TodoChannelProcessor : ITodoProcessor
{
    private readonly ChannelWriter<TodoItem> _writer;
    private readonly ThreadLocal<Span<byte>> _buffer;
    
    public TodoChannelProcessor(Channel<TodoItem> channel, ThreadLocal<Span<byte>> buffer)
    {
        _writer = channel.Writer;
        _buffer = buffer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe void Process(TodoItem item)
    {
        Span<byte> buffer = _buffer.Value;
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0) // Cache-line对齐
            {
                // SIMD优化处理
                _writer.TryWrite(item);
            }
        }
    }
}

// 5. 新增拦截器类
[SkipLocalsInit]
public class TracingInterceptor : Interceptor
{
    private readonly ActivitySource _source = new("GrpcTodoService");
    
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public override async Task<TResponse> UnaryServerHandler<TRequest, TResponse>(
        TRequest request, 
        ServerCallContext context,
        UnaryServerMethod<TRequest, TResponse> continuation)
    {
        using var activity = _source.StartActivity(context.Method);
        return await base.UnaryServerHandler(request, context, continuation);
    }
}

public class ChaosInterceptor : Interceptor
{
    private readonly Random _random = new();
    
    public override async Task<TResponse> UnaryServerHandler<TRequest, TResponse>(
        TRequest request, 
        ServerCallContext context,
        UnaryServerMethod<TRequest, TResponse> continuation)
    {
        // 5%概率模拟失败
        if (_random.Next(100) < 5)
            throw new RpcException(new Status(StatusCode.Unavailable, "Chaos engineering test"));
            
        return await base.UnaryServerHandler(request, context, continuation);
    }
}