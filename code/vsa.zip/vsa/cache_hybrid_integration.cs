#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.Extensions.Caching.Hybrid@8.0.0
#:package Microsoft.Extensions.Caching.StackExchangeRedis@8.0.0
#:package Microsoft.Extensions.Hosting@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using StackExchange.Redis;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// 1. 定义缓存策略配置
public class CachePolicyOptions
{
    public TimeSpan LocalCacheExpiration { get; set; } = TimeSpan.FromMinutes(5);
    public TimeSpan DistributedCacheExpiration { get; set; } = TimeSpan.FromHours(1);
    public TimeSpan StaleDataExpiration { get; set; } = TimeSpan.FromMinutes(30);
}

// 2. 定义缓存服务接口
public interface IProductService 
{ 
    Task<Product?> GetProductAsync(int id, CancellationToken cancellationToken = default);
    Task SetProductAsync(Product product, CancellationToken cancellationToken = default);
    Task<IReadOnlyDictionary<int, Product?>> GetProductsAsync(IReadOnlyCollection<int> ids, CancellationToken cancellationToken = default);
    Task SetProductsAsync(IReadOnlyCollection<Product> products, CancellationToken cancellationToken = default);
    Task RemoveProductsAsync(IReadOnlyCollection<int> ids, CancellationToken cancellationToken = default);
}

public interface IProductRepository
{
    Task<Product?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<Product>> GetByIdsAsync(IReadOnlyCollection<int> ids, CancellationToken cancellationToken = default);
}

public record Product(int Id, string Name, decimal Price);

// 3. 实现混合缓存服务
public class ProductService : IProductService
{
    private readonly HybridCache _cache;
    private readonly ILogger<ProductService> _logger;
    
    public ProductService(HybridCache cache, ILogger<ProductService> logger)
    {
        _cache = cache;
        _logger = logger;
    }

    public async Task<Product?> GetProductAsync(int id, CancellationToken cancellationToken = default)
    {
        var cacheKey = $"product:{id}";
        
        return await _cache.GetOrCreateAsync(
            cacheKey,
            async (cancel) =>
            {
                _logger.LogInformation("Cache miss for product {ProductId}, fetching from database", id);
                
                // 模拟数据库查询
                await Task.Delay(100, cancel);
                return new Product(id, $"Product {id}", id * 10);
            },
            cancellationToken: cancellationToken);
    }

    public async Task SetProductAsync(Product product, CancellationToken cancellationToken = default)
    {
        var cacheKey = $"product:{product.Id}";
        await _cache.SetAsync(cacheKey, product, cancellationToken: cancellationToken);
    }
}

// 4. 缓存事件处理器
public class CacheEventHandler : IHostedService
{
    private readonly HybridCache _cache;
    private readonly ILogger<CacheEventHandler> _logger;
    private IDisposable? _subscription;

    public CacheEventHandler(HybridCache cache, ILogger<CacheEventHandler> logger)
    {
        _cache = cache;
        _logger = logger;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _subscription = _cache.Subscribe((key, operation) =>
        {
            _logger.LogInformation("Cache {Operation} for key: {Key}", operation, key);
        });
        
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        _subscription?.Dispose();
        return Task.CompletedTask;
    }
}

// 5. 缓存预热中间件
public class CacheWarmupMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IProductService _productService;
    private readonly ILogger<CacheWarmupMiddleware> _logger;

    public CacheWarmupMiddleware(
        RequestDelegate next,
        IProductService productService,
        ILogger<CacheWarmupMiddleware> logger)
    {
        _next = next;
        _productService = productService;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Path == "/")
        {
            // 预热前10个产品缓存
            var tasks = Enumerable.Range(1, 10)
                .Select(id => _productService.GetProductAsync(id));
                
            await Task.WhenAll(tasks);
            _logger.LogInformation("Cache warmup completed for 10 products");
        }
        
        await _next(context);
    }
}

// 6. 扩展方法
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddHybridCacheServices(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // 配置Redis
        var redisConnection = configuration.GetConnectionString("Redis");
        services.AddStackExchangeRedisCache(options =>
        {
            options.Configuration = redisConnection;
            options.InstanceName = "SampleApp:";
        });
        
        // 配置混合缓存
        services.AddHybridCache(options =>
        {
            // 本地内存缓存配置
            options.LocalCache = new MemoryCacheOptions
            {
                SizeLimit = 1024,
                ExpirationScanFrequency = TimeSpan.FromMinutes(1)
            };
            
            // 分布式缓存后备配置
            options.DistributedCacheEntryOptions = new()
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1)
            };
            
            // 其他高级配置
            options.MaximumStateTime = TimeSpan.FromMinutes(30);
            options.DefaultEntryOptions = new()
            {
                LocalCacheExpiration = TimeSpan.FromMinutes(5),
                DistributedCacheExpiration = TimeSpan.FromHours(1)
            };
        });
        
        // 注册缓存策略配置
        services.Configure<CachePolicyOptions>(configuration.GetSection("CachePolicy"));
        
        // 注册服务
        services.AddSingleton<IProductService, ProductService>();
        services.AddSingleton<IHostedService, CacheEventHandler>();
        
        return services;
    }
}

// 7. 主程序
var builder = WebApplication.CreateBuilder(args);

// 添加混合缓存服务
builder.Services.AddHybridCacheServices(builder.Configuration);

// 添加中间件
builder.Services.AddScoped<CacheWarmupMiddleware>();

var app = builder.Build();

// 使用缓存预热中间件
app.UseMiddleware<CacheWarmupMiddleware>();

// API端点
app.MapGet("/products/{id}", async (int id, IProductService service) =>
{
    var product = await service.GetProductAsync(id);
    return product is not null ? Results.Ok(product) : Results.NotFound();
});

app.MapPost("/products", async (Product product, IProductService service) =>
{
    await service.SetProductAsync(product);
    return Results.Created($"products/{product.Id}", product);
});

app.MapGet("/cache-stats", (HybridCache cache) =>
{
    var stats = cache.GetStatistics();
    return Results.Ok(new
    {
        stats.TotalHits,
        stats.LocalHits,
        stats.DistributedHits,
        stats.TotalMisses
    });
});

app.Run();

// 8. 性能优化扩展
public static class HybridCacheExtensions
{
    public static async Task<T?> GetOrCreateAsync<T>(
        this HybridCache cache,
        string key,
        Func<CancellationToken, Task<T>> factory,
        TimeSpan? localExpiry = null,
        TimeSpan? distributedExpiry = null,
        CancellationToken cancellationToken = default)
    {
        var result = await cache.GetOrCreateAsync(
            key,
            async (cancel) => new HybridCacheItem<T>(await factory(cancel)),
            new HybridCacheEntryOptions
            {
                LocalCacheExpiration = localExpiry,
                DistributedCacheExpiration = distributedExpiry
            },
            cancellationToken);
            
        return result?.Value;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static async Task<T?> GetOrCreateInlineAsync<T>(
        this HybridCache cache,
        string key,
        Func<CancellationToken, Task<T>> factory,
        CancellationToken cancellationToken = default)
    {
        return await GetOrCreateAsync(cache, key, factory, cancellationToken: cancellationToken);
    }
}