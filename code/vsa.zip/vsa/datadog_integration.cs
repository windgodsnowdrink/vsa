#:sdk Microsoft.NET.Sdk.Web
#:package Datadog.Trace@3.0.0
#:package Datadog.Monitoring.Distribution@1.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Datadog.Trace;
using Datadog.Trace.ClrProfiler;
using Datadog.Trace.Configuration;

var builder = WebApplication.CreateBuilder();

// 配置DataDog监控服务
builder.Services.AddDataDogMonitoring(options =>
{
    // 基础配置
    options.ServiceName = "SampleApp";
    options.Environment = "Production";
    
    // APM配置
    options.TracerSettings = new TracerSettings
    {
        AnalyticsEnabled = true,
        RuntimeMetricsEnabled = true,
        LogInjectionEnabled = true,
        StartupDiagnosticLogEnabled = true
    };
    
    // 分布式追踪
    options.DistributedTracingEnabled = true;
    options.KafkaIntegrationEnabled = true;
    options.RabbitMQIntegrationEnabled = true;
    
    // 性能优化
    options.UseThreadLocalBuffers = true;
    options.BufferSize = 1024 * 1024; // 1MB缓冲
});

// 自定义指标处理器
builder.Services.AddSingleton<IMetricsProcessor, DataDogMetricsProcessor>();

var app = builder.Build();

// 启用DataDog中间件
app.UseDataDogTracing();

// 自定义监控点示例
app.MapGet("/api/orders", ([FromServices] IDataDogClient client) =>
{
    using (var scope = client.StartActive("order.query"))
    {
        // 记录自定义指标
        client.Increment("orders.request_count");
        return Results.Ok();
    }
});

app.MapGet("/", () => "DataDog Monitoring Ready");
app.Run();

// 高性能指标处理器
public class DataDogMetricsProcessor : IMetricsProcessor
{
    private readonly ThreadLocal<Span<byte>> _threadLocalBuffer = 
        new(() => stackalloc byte[256]);
    
    public void Process(MetricData data)
    {
        var buffer = _threadLocalBuffer.Value;
        // 零拷贝处理指标数据
    }
}