#:sdk Microsoft.NET.Sdk.Web
#:package ACME.NET@3.0.0
#:package Microsoft.Extensions.Caching.Memory@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0

using System.Security.Cryptography.X509Certificates;
using ACME.NET;

[SkipLocalsInit]
public class AcmeDotNetService
{
    private readonly MemoryCache _nonceCache;
    private readonly AcmeClient _client;
    
    public async Task<X509Certificate2> RequestCertificateAsync(string domain)
    {
        // 使用内存缓存管理ACME nonce
        var nonce = await _client.GetNonceAsync();
        _nonceCache.Set(domain, nonce, TimeSpan.FromMinutes(5));
        
        // 创建ACME账户
        var account = await _client.CreateAccountAsync(
            new[] { $"mailto:admin@{domain}" },
            termsOfServiceAgreed: true);
            
        // 完成DNS挑战
        var challenge = await _client.CreateDnsChallenge(domain);
        await _client.CompleteChallenge(challenge);
        
        // 生成证书
        return await _client.GenerateCertificate(
            new[] { domain },
            keyAlgorithm: KeyAlgorithm.ES256);
    }
}