#:sdk Microsoft.NET.Sdk.Web
#:package CsGo@1.0.0
#:package Microsoft.Extensions.Hosting@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Threading.Channels;
using CsGo;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace CsGoIntegration
{
    public class CsGoOptions
{
    public bool MetricsEnabled { get; set; } = true;
    public bool TracingEnabled { get; set; } = true;
    public TimeSpan HealthCheckInterval { get; set; } = TimeSpan.FromMinutes(1);
    public int BufferSize { get; set; } = 8192;
    public bool ZeroCopyEnabled { get; set; } = true;
    public int MemoryPoolSize { get; set; } = 1024 * 1024;
    public int RetryCount { get; set; } = 3;
    public TimeSpan RetryInterval { get; set; } = TimeSpan.FromSeconds(1);
    public double FailureThreshold { get; set; } = 0.5;
    public TimeSpan SamplingDuration { get; set; } = TimeSpan.FromMinutes(1);
    public TimeSpan MinimumThroughput { get; set; } = TimeSpan.FromSeconds(10);
    public bool MultiTenantEnabled { get; set; }
    public string TenantHeaderName { get; set; } = "X-Tenant-ID";
    public string ServerAddress { get; set; }
        // 并发控制配置
        public int MaxConcurrentProcesses { get; set; } = 10;
        public int ProcessQueueCapacity { get; set; } = 1000;
        public TimeSpan ProcessTimeout { get; set; } = TimeSpan.FromMinutes(5);
        
        // 弹性策略
        public int RetryCount { get; set; } = 3;
        public TimeSpan RetryDelay { get; set; } = TimeSpan.FromSeconds(1);
        
        // 性能优化
        public int BufferSize { get; set; } = 8192;
        public bool ZeroCopyEnabled { get; set; } = true;
        
        // 监控配置
        public bool EnableMetrics { get; set; } = true;
        public bool EnableTracing { get; set; } = true;
    }

    public interface ICsGoService
{
    Task<ConnectionStatistics> GetConnectionStatisticsAsync(CancellationToken cancellationToken = default);
    Task<ThroughputStatistics> GetThroughputStatisticsAsync(CancellationToken cancellationToken = default);
    Task<HealthCheckResult> CheckHealthAsync(CancellationToken cancellationToken = default);
    ValueTask<IMemoryOwner<byte>> GetMemoryPoolAsync(int size, CancellationToken cancellationToken = default);
    Task ResetCircuitBreakerAsync(CancellationToken cancellationToken = default);
    Task SetTenantContextAsync(string tenantId, CancellationToken cancellationToken = default);
        // 流程控制
        Task<ProcessResult> ExecuteProcessAsync(ProcessRequest request, CancellationToken cancellationToken = default);
        Task<IEnumerable<ProcessResult>> ExecuteBatchAsync(IEnumerable<ProcessRequest> requests, CancellationToken cancellationToken = default);
        
        // 状态查询
        Task<ProcessStatus> GetProcessStatusAsync(Guid processId, CancellationToken cancellationToken = default);
        Task<SystemStatus> GetSystemStatusAsync(CancellationToken cancellationToken = default);
        
        // 弹性控制
        Task ResetCircuitBreakerAsync(CancellationToken cancellationToken = default);
        
        // 性能监控
        Task<ThroughputMetrics> GetThroughputMetricsAsync(CancellationToken cancellationToken = default);
        Task<ProcessMetrics> GetProcessMetricsAsync(CancellationToken cancellationToken = default);
    }

    public class CsGoService : ICsGoService, IAsyncDisposable
    {
        private readonly CsGoOptions _options;
        private readonly Channel<ProcessRequest> _processChannel;
        private readonly ILogger<CsGoService> _logger;
        private readonly ObjectPool<byte[]> _bufferPool;
        private readonly IProcessExecutor _processExecutor;
        private readonly IMetricsCollector _metricsCollector;

        public CsGoService(
            IOptions<CsGoOptions> options,
            ILogger<CsGoService> logger,
            ObjectPool<byte[]> bufferPool,
            IProcessExecutor processExecutor,
            IMetricsCollector metricsCollector)
        {
            _options = options.Value;
            _logger = logger;
            _bufferPool = bufferPool;
            _processExecutor = processExecutor;
            _metricsCollector = metricsCollector;
            
            // 创建有界通道
            _processChannel = Channel.CreateBounded<ProcessRequest>(
                new BoundedChannelOptions(_options.ProcessQueueCapacity)
                {
                    FullMode = BoundedChannelFullMode.Wait,
                    SingleReader = false,
                    SingleWriter = false
                });
            
            // 启动处理工作器
            StartProcessWorkers();
        }

        private void StartProcessWorkers()
        {
            for (int i = 0; i < _options.MaxConcurrentProcesses; i++)
            {
                Task.Run(async () => await ProcessWorkerAsync());
            }
        }

        private async Task ProcessWorkerAsync()
        {
            while (await _processChannel.Reader.WaitToReadAsync())
            {
                if (_processChannel.Reader.TryRead(out var request))
                {
                    try
                    {
                        using var buffer = _bufferPool.Get();
                        // 处理请求逻辑
                        await _processExecutor.ExecuteAsync(request, buffer);
                        _metricsCollector.RecordSuccess();
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Process execution failed");
                        _metricsCollector.RecordFailure();
                    }
                }
            }
        }

        public async Task<ProcessResult> ExecuteProcessAsync(ProcessRequest request, CancellationToken cancellationToken = default)
        {
            await _processChannel.Writer.WriteAsync(request, cancellationToken);
            return await _processExecutor.GetResultAsync(request.ProcessId, cancellationToken);
        }

        public async ValueTask DisposeAsync()
        {
            _processChannel.Writer.Complete();
            await Task.WhenAll(Enumerable.Range(0, _options.MaxConcurrentProcesses)
                .Select(_ => _processChannel.Reader.Completion));
        }

        // 其他接口实现...
    }

    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddCsGoService(this IServiceCollection services, Action<CsGoOptions> configureOptions)
{
    services.AddOpenTelemetry()
        .WithMetrics(metrics =>
        {
            metrics.AddMeter("CsGo");
            metrics.AddPrometheusExporter();
        })
        .WithTracing(tracing =>
        {
            tracing.AddSource("CsGo");
            tracing.AddOtlpExporter();
        });
    services.AddHealthChecks().AddCheck<CsGoHealthCheck>("csgo");
    services.AddSingleton<ObjectPoolProvider, DefaultObjectPoolProvider>();
    services.AddSingleton(provider =>
    {
        var poolProvider = provider.GetRequiredService<ObjectPoolProvider>();
        return poolProvider.Create(new DefaultPooledObjectPolicy<byte[]>());
    });
    services.AddPolicyRegistry();
    services.AddResiliencePipeline<string, HttpResponseMessage>("csgo-retry-pipeline", builder =>
    {
        builder.AddRetry(new()
        {
            MaxRetryAttempts = 3,
            ShouldHandle = new PredicateBuilder<HttpResponseMessage>()
                .HandleResult(response => !response.IsSuccessStatusCode)
                .Handle<HttpRequestException>(),
            Delay = TimeSpan.FromSeconds(1),
            BackoffType = DelayBackoffType.Exponential
        });
        builder.AddCircuitBreaker(new()
        {
            FailureRatio = 0.5,
            SamplingDuration = TimeSpan.FromMinutes(1),
            MinimumThroughput = 10,
            BreakDuration = TimeSpan.FromSeconds(30),
            ShouldHandle = new PredicateBuilder<HttpResponseMessage>()
                .HandleResult(response => !response.IsSuccessStatusCode)
                .Handle<HttpRequestException>()
        });
    });
    services.AddScoped<TenantContext>();
            services.Configure(configureOptions);
            
            // 注册服务
            services.AddSingleton<ICsGoService, CsGoService>();
            
            // 配置对象池
            services.AddSingleton<ObjectPoolProvider, DefaultObjectPoolProvider>();
            services.AddSingleton(provider => 
            {
                var poolProvider = provider.GetRequiredService<ObjectPoolProvider>();
                return poolProvider.Create(new DefaultPooledObjectPolicy<byte[]>());
            });
            
            // 配置弹性策略
            services.AddResiliencePipeline<string, ProcessResult>("CsGoPipeline", builder =>
            {
                builder.AddRetry(new()
                {
                    MaxRetryAttempts = 3,
                    Delay = TimeSpan.FromSeconds(1),
                    ShouldHandle = args => ValueTask.FromResult(args.Outcome.Exception is ProcessExecutionException)
                });
            });
            
            // 配置监控
            services.AddOpenTelemetry()
                .WithMetrics(metrics =>
                {
                    metrics.AddMeter("CsGo");
                    metrics.AddPrometheusExporter();
                })
                .WithTracing(tracing =>
                {
                    tracing.AddSource("CsGo");
                    tracing.AddOtlpExporter();
                });
            
            return services;
        }
    }
}