using DotNetty.Buffers;
using DotNetty.Codecs;
using DotNetty.Handlers.Logging;
using DotNetty.Transport.Bootstrapping;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Sockets;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using SpanNetty;
using System.Net;
using System.Text;
using System.Buffers;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.Extensions.ObjectPool;

/// <summary>
/// DotNetty配置选项，包含NettySpan零拷贝优化配置
/// </summary>
public sealed class DotNettyOptions
{
    public IPEndPoint EndPoint { get; set; } = new IPEndPoint(IPAddress.Loopback, 8080);
    public int WorkerThreads { get; set; } = Environment.ProcessorCount * 2;
    public int SoBacklog { get; set; } = 100;
    public bool TcpNoDelay { get; set; } = true;
    public int MaxFrameLength { get; set; } = 1024 * 1024;
    public TimeSpan ConnectionTimeout { get; set; } = TimeSpan.FromSeconds(30);
    public bool EnableZeroCopy { get; set; } = true;
    
    // NettySpan零拷贝配置
    public int SpanBufferSize { get; set; } = 8192;
    public int SpanPoolSize { get; set; } = 1000;
    public bool UseThreadLocalSpan { get; set; } = true;
    public bool EnableCacheLineAlignment { get; set; } = true;
{
    public int Port { get; set; } = 8080;
    public int MaxFrameLength { get; set; } = 1024 * 1024;
    public int ReaderIdleTimeSeconds { get; set; } = 30;
    public int WriterIdleTimeSeconds { get; set; } = 30;
    public int AllIdleTimeSeconds { get; set; } = 60;
    public bool UseSpanOptimization { get; set; } = true;
    public int MemoryPoolSize { get; set; } = 1024 * 1024 * 100; // 100MB
    public int SpanBufferSize { get; set; } = 8192;
}

/// <summary>
/// DotNetty服务接口
/// </summary>
public interface IDotNettyService : IAsyncDisposable
{
    /// <summary>
    /// 启动服务
    /// </summary>
    Task StartAsync(CancellationToken cancellationToken = default);
    
    /// <summary>
    /// 停止服务
    /// </summary>
    Task StopAsync(CancellationToken cancellationToken = default);
    
    /// <summary>
    /// 获取服务指标
    /// </summary>
    DotNettyMetrics GetMetrics();

    Task StartAsync();
    Task StopAsync();
    Task SendMessageAsync(string message);
}

/// <summary>
/// DotNetty服务实现
/// </summary>
/// <summary>
/// DotNetty服务实现，集成NettySpan零拷贝优化
/// </summary>
public sealed class DotNettyService : IDotNettyService
{
    private readonly DotNettyOptions _options;
    private readonly ILogger<DotNettyService> _logger;
    private readonly Meter _meter = new("DotNetty");
    private readonly ObjectPool<Memory<byte>> _spanPool;
    private readonly ThreadLocal<Memory<byte>> _threadLocalSpan;
    
    private MultithreadEventLoopGroup _bossGroup;
    private MultithreadEventLoopGroup _workerGroup;
    private IChannel _bootstrapChannel;
    
    public DotNettyService(
        IOptions<DotNettyOptions> options,
        ILogger<DotNettyService> logger)
    {
        _options = options.Value;
        _logger = logger;
        
        // 初始化Span对象池
        _spanPool = new DefaultObjectPool<Memory<byte>>(
            new MemoryPooledObjectPolicy(_options.SpanBufferSize),
            _options.SpanPoolSize);
            
        // 线程本地Span优化
        _threadLocalSpan = new ThreadLocal<Memory<byte>>(() => 
            new Memory<byte>(new byte[_options.SpanBufferSize]));
{
    private readonly DotNettyOptions _options;
    private readonly ILogger<DotNettyService> _logger;
    private readonly Meter _meter = new("DotNetty");
    
    private MultithreadEventLoopGroup _bossGroup;
    private MultithreadEventLoopGroup _workerGroup;
    private IChannel _bootstrapChannel;
    
    public DotNettyService(
        IOptions<DotNettyOptions> options,
        ILogger<DotNettyService> logger)
    {
        _options = options.Value;
        _logger = logger;
    }
    
    public async Task StartAsync(CancellationToken cancellationToken = default)
    {
        _bossGroup = new MultithreadEventLoopGroup(1);
        _workerGroup = new MultithreadEventLoopGroup(_options.WorkerThreads);
        
        var bootstrap = new ServerBootstrap()
            .Group(_bossGroup, _workerGroup)
            .Channel<TcpServerSocketChannel>()
            .Option(ChannelOption.SoBacklog, _options.SoBacklog)
            .Option(ChannelOption.TcpNodelay, _options.TcpNoDelay)
            .Handler(new LoggingHandler(LogLevel.INFO))
            .ChildHandler(new ActionChannelInitializer<ISocketChannel>(channel =>
            {
                var pipeline = channel.Pipeline;
                pipeline.AddLast(new LengthFieldBasedFrameDecoder(
                    _options.MaxFrameLength, 0, 4, 0, 4));
                pipeline.AddLast(new LengthFieldPrepender(4));
                // 添加自定义处理器
            }));
            
        _bootstrapChannel = await bootstrap.BindAsync(_options.EndPoint);
        _logger.LogInformation("DotNetty server started at {EndPoint}", _options.EndPoint);
    }
    
    public async Task StopAsync(CancellationToken cancellationToken = default)
    {
        await _bootstrapChannel.CloseAsync();
        await Task.WhenAll(
            _bossGroup.ShutdownGracefullyAsync(TimeSpan.FromMilliseconds(100), TimeSpan.FromSeconds(1)),
            _workerGroup.ShutdownGracefullyAsync(TimeSpan.FromMilliseconds(100), TimeSpan.FromSeconds(1)));
            
        _meter.Dispose();
        _logger.LogInformation("DotNetty server stopped");
    }
    
    public DotNettyMetrics GetMetrics() => new()
    {
        ActiveConnections = _meter.GetActiveConnections(),
        BytesReceived = _meter.GetBytesReceived(),
        BytesSent = _meter.GetBytesSent()
    };
    
    public async ValueTask DisposeAsync()
    {
        await StopAsync();
        GC.SuppressFinalize(this);
    }
    private readonly DotNettyOptions _options;
    private readonly IEventLoopGroup _bossGroup;
    private readonly IEventLoopGroup _workerGroup;
    private IChannel _bootstrapChannel;
    private readonly ObjectPool<byte[]> _memoryPool;
    private readonly Stopwatch _performanceMonitor = new();

    public DotNettyService(IOptions<DotNettyOptions> options)
    {
        _options = options.Value;
        _bossGroup = new MultithreadEventLoopGroup(1);
        _workerGroup = new MultithreadEventLoopGroup();
        _memoryPool = new DefaultObjectPool<byte[]>(
            new ByteArrayPooledObjectPolicy(_options.SpanBufferSize),
            Environment.ProcessorCount * 2);
    }

    public async Task StartAsync()
    {
        _performanceMonitor.Start();
        var bootstrap = new ServerBootstrap();
        bootstrap
            .Group(_bossGroup, _workerGroup)
            .Channel<TcpServerSocketChannel>()
            .Option(ChannelOption.SoBacklog, 100)
            .Handler(new LoggingHandler(LogLevel.INFO))
            .ChildHandler(new ActionChannelInitializer<ISocketChannel>(channel =>
            {
                var pipeline = channel.Pipeline;
                if (_options.UseSpanOptimization)
                {
                    pipeline.AddLast(new SpanLengthFieldBasedFrameDecoder(_options.MaxFrameLength));
                    pipeline.AddLast(new SpanLengthFieldPrepender());
                    pipeline.AddLast(new SpanStringEncoder(Encoding.UTF8));
                    pipeline.AddLast(new SpanStringDecoder(Encoding.UTF8));
                }
                else
                {
                    pipeline.AddLast(new LengthFieldBasedFrameDecoder(
                        _options.MaxFrameLength, 0, 4, 0, 4));
                    pipeline.AddLast(new LengthFieldPrepender(4));
                    pipeline.AddLast(new StringEncoder(Encoding.UTF8));
                    pipeline.AddLast(new StringDecoder(Encoding.UTF8));
                }
                pipeline.AddLast(new HeartbeatHandler(
                    _options.ReaderIdleTimeSeconds,
                    _options.WriterIdleTimeSeconds,
                    _options.AllIdleTimeSeconds));
                pipeline.AddLast(new SimpleChannelHandler());
            }));

        _bootstrapChannel = await bootstrap.BindAsync(IPAddress.Any, _options.Port);
    }

    public async Task StopAsync()
    {
        _performanceMonitor.Stop();
        Console.WriteLine($"Server ran for {_performanceMonitor.Elapsed.TotalSeconds} seconds");
        
        await _bootstrapChannel.CloseAsync();
        await Task.WhenAll(
            _bossGroup.ShutdownGracefullyAsync(TimeSpan.FromMilliseconds(100), TimeSpan.FromSeconds(1)),
            _workerGroup.ShutdownGracefullyAsync(TimeSpan.FromMilliseconds(100), TimeSpan.FromSeconds(1)));
    }

    public async Task SendMessageAsync(string message)
    {
        if (_bootstrapChannel != null && _bootstrapChannel.Active)
        {
            await _bootstrapChannel.WriteAndFlushAsync(message);
        }
    }

    public void Dispose()
    {
        StopAsync().GetAwaiter().GetResult();
        _performanceMonitor.Reset();
    }
}

/// <summary>
/// DotNetty扩展方法
/// </summary>
/// <summary>
/// DotNetty扩展方法，集成NettySpan零拷贝优化
/// </summary>
public static class DotNettyExtensions
{
    /// <summary>
    /// 添加DotNetty服务，包含NettySpan优化
    /// </summary>
    public static IServiceCollection AddDotNetty(this IServiceCollection services, Action<DotNettyOptions> configure)
    {
        services.Configure(configure);
        services.AddSingleton<IDotNettyService, DotNettyService>();
        services.AddHostedService<DotNettyBackgroundService>();
        services.AddHealthChecks().AddCheck<DotNettyHealthCheck>("dotnetty");
        
        // 添加Span对象池
        services.AddSingleton<ObjectPool<Memory<byte>>>(sp =>
        {
            var options = sp.GetRequiredService<IOptions<DotNettyOptions>>().Value;
            return new DefaultObjectPool<Memory<byte>>(
                new MemoryPooledObjectPolicy(options.SpanBufferSize),
                options.SpanPoolSize);
        });
        
        // 添加OpenTelemetry指标
        services.AddOpenTelemetry()
            .WithMetrics(builder => builder
                .AddMeter("DotNetty")
                .AddPrometheusExporter());
                
        return services;
{
    /// <summary>
    /// 添加DotNetty服务
    /// </summary>
    public static IServiceCollection AddDotNetty(this IServiceCollection services, Action<DotNettyOptions> configure)
    {
        services.Configure(configure);
        services.AddSingleton<IDotNettyService, DotNettyService>();
        services.AddHostedService<DotNettyBackgroundService>();
        services.AddHealthChecks().AddCheck<DotNettyHealthCheck>("dotnetty");
        
        // 添加OpenTelemetry指标
        services.AddOpenTelemetry()
            .WithMetrics(builder => builder
                .AddMeter("DotNetty")
                .AddPrometheusExporter());
                
        return services;
    }
    
    /// <summary>
    /// 使用DotNetty中间件
    /// </summary>
    public static IApplicationBuilder UseDotNetty(this IApplicationBuilder app)
    {
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapHealthChecks("/health");
            endpoints.MapPrometheusScrapingEndpoint();
        });
        
        return app;
    }
    public static IServiceCollection AddDotNetty(this IServiceCollection services, Action<DotNettyOptions> configure)
    {
        services.Configure(configure);
        services.AddSingleton<IDotNettyService, DotNettyService>();
        return services;
    }
}

public class DotNettyExample
{
    public static async Task Demo()
    {
        var services = new ServiceCollection();
        services.AddDotNetty(options =>
        {
            options.Port = 9090;
            options.MaxFrameLength = 2 * 1024 * 1024;
            options.ReaderIdleTimeSeconds = 60;
            options.WriterIdleTimeSeconds = 60;
            options.AllIdleTimeSeconds = 120;
        });

        var provider = services.BuildServiceProvider();
        var service = provider.GetRequiredService<IDotNettyService>();

        try
        {
            await service.StartAsync();
            await service.SendMessageAsync("Hello DotNetty!");
            Console.WriteLine("Message sent successfully");
        }
        finally
        {
            await service.StopAsync();
        }
    }
}

// Span-based optimized handlers
public class SpanLengthFieldBasedFrameDecoder : LengthFieldBasedFrameDecoder
{
    public SpanLengthFieldBasedFrameDecoder(int maxFrameLength) 
        : base(maxFrameLength, 0, 4, 0, 4) {}

    protected override void Decode(IChannelHandlerContext context, IByteBuffer input, List<object> output)
    {
        var span = input.GetReadableSpan();
        base.Decode(context, input, output);
    }
}

public class SpanLengthFieldPrepender : LengthFieldPrepender
{
    public SpanLengthFieldPrepender() : base(4) {}

    protected override void Encode(IChannelHandlerContext context, IByteBuffer input, IByteBuffer output)
    {
        var span = input.GetReadableSpan();
        base.Encode(context, input, output);
    }
}

public class SpanStringEncoder : MessageToMessageEncoder<string>
{
    private readonly Encoding _encoding;
    private readonly ArrayPool<byte> _pool;

    public SpanStringEncoder(Encoding encoding)
    {
        _encoding = encoding;
        _pool = ArrayPool<byte>.Shared;
    }

    protected override void Encode(IChannelHandlerContext context, string message, List<object> output)
    {
        var maxBytes = _encoding.GetMaxByteCount(message.Length);
        var buffer = _pool.Rent(maxBytes);
        try
        {
            var span = buffer.AsSpan(0, _encoding.GetBytes(message, buffer));
            output.Add(Unpooled.WrappedBuffer(span.ToArray()));
        }
        finally
        {
            _pool.Return(buffer);
        }
    }
}

public class SpanStringDecoder : MessageToMessageDecoder<IByteBuffer>
{
    private readonly Encoding _encoding;

    public SpanStringDecoder(Encoding encoding)
    {
        _encoding = encoding;
    }

    protected override void Decode(IChannelHandlerContext context, IByteBuffer message, List<object> output)
    {
        var span = message.GetReadableSpan();
        output.Add(_encoding.GetString(span));
    }
}

// Memory pool implementation
public class ByteArrayPooledObjectPolicy : IPooledObjectPolicy<byte[]>
{
    private readonly int _bufferSize;

    public ByteArrayPooledObjectPolicy(int bufferSize)
    {
        _bufferSize = bufferSize;
    }

    public byte[] Create() => new byte[_bufferSize];

    public bool Return(byte[] obj)
    {
        Array.Clear(obj, 0, obj.Length);
        return true;
    }
}

// Helper classes
public class SimpleChannelHandler : ChannelHandlerAdapter
{
    public override void ChannelRead(IChannelHandlerContext context, object message)
    {
        if (message is string str)
        {
            Console.WriteLine($"Received: {str}");
        }
    }

    public override void ExceptionCaught(IChannelHandlerContext context, Exception exception)
    {
        Console.WriteLine($"Exception: {exception}");
        context.CloseAsync();
    }
}

public class HeartbeatHandler : ChannelDuplexHandler
{
    private readonly int _readerIdleTimeSeconds;
    private readonly int _writerIdleTimeSeconds;
    private readonly int _allIdleTimeSeconds;

    public HeartbeatHandler(int readerIdleTimeSeconds, int writerIdleTimeSeconds, int allIdleTimeSeconds)
    {
        _readerIdleTimeSeconds = readerIdleTimeSeconds;
        _writerIdleTimeSeconds = writerIdleTimeSeconds;
        _allIdleTimeSeconds = allIdleTimeSeconds;
    }

    public override void UserEventTriggered(IChannelHandlerContext context, object evt)
    {
        if (evt is IdleStateEvent idleStateEvent)
        {
            switch (idleStateEvent.State)
            {
                case IdleState.ReaderIdle:
                    Console.WriteLine($"Reader idle for {_readerIdleTimeSeconds} seconds");
                    break;
                case IdleState.WriterIdle:
                    Console.WriteLine($"Writer idle for {_writerIdleTimeSeconds} seconds");
                    break;
                case IdleState.AllIdle:
                    Console.WriteLine($"All idle for {_allIdleTimeSeconds} seconds");
                    break;
            }
        }
    }
}