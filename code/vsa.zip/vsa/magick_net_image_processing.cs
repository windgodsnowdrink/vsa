#:sdk Microsoft.NET.Sdk
#:package Magick.NET-Q16-x64@8.5.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System;
using System.Buffers;
using System.IO;
using System.Threading.Channels;
using ImageMagick;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.ObjectPool;

// 图片处理服务接口
public interface IImageProcessingService
{
    ValueTask<byte[]> ResizeImageAsync(byte[] imageData, int width, int height);
    ValueTask<byte[]> ConvertFormatAsync(byte[] imageData, MagickFormat format);
    ValueTask<byte[]> ApplyFilterAsync(byte[] imageData, Action<IMagickImage> filter);
}

// 图片处理服务实现
public sealed class ImageProcessingService : IImageProcessingService, IDisposable
{
    private readonly ObjectPool<MagickImage> _imagePool;
    private readonly ChannelWriter<byte[]> _resultChannel;
    private readonly ThreadLocal<Span<byte>> _threadLocalBuffer;

    public ImageProcessingService(
        ObjectPool<MagickImage> imagePool,
        Channel<byte[]> resultChannel)
    {
        _imagePool = imagePool;
        _resultChannel = resultChannel.Writer;
        _threadLocalBuffer = new ThreadLocal<Span<byte>>(() => 
            new byte[4096].AsSpan());
    }

    public async ValueTask<byte[]> ResizeImageAsync(byte[] imageData, int width, int height)
    {
        var image = _imagePool.Get();
        try
        {
            image.Read(imageData);
            image.Resize(width, height);
            
            using var memoryStream = new MemoryStream();
            image.Write(memoryStream);
            var result = memoryStream.ToArray();
            
            await _resultChannel.WriteAsync(result);
            return result;
        }
        finally
        {
            _imagePool.Return(image);
        }
    }

    public async ValueTask<byte[]> ConvertFormatAsync(byte[] imageData, MagickFormat format)
    {
        var image = _imagePool.Get();
        try
        {
            image.Read(imageData);
            
            using var memoryStream = new MemoryStream();
            image.Write(memoryStream, format);
            var result = memoryStream.ToArray();
            
            await _resultChannel.WriteAsync(result);
            return result;
        }
        finally
        {
            _imagePool.Return(image);
        }
    }

    public async ValueTask<byte[]> ApplyFilterAsync(byte[] imageData, Action<IMagickImage> filter)
    {
        var image = _imagePool.Get();
        try
        {
            image.Read(imageData);
            filter.Invoke(image);
            
            using var memoryStream = new MemoryStream();
            image.Write(memoryStream);
            var result = memoryStream.ToArray();
            
            await _resultChannel.WriteAsync(result);
            return result;
        }
        finally
        {
            _imagePool.Return(image);
        }
    }

    public void Dispose()
    {
        _threadLocalBuffer.Dispose();
    }
}

// DI扩展方法
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddImageProcessingServices(this IServiceCollection services)
    {
        services.AddSingleton<ObjectPool<MagickImage>>(sp => 
            new DefaultObjectPool<MagickImage>(new MagickImagePooledObjectPolicy(), 10));
            
        services.AddSingleton<Channel<byte[]>>(_ => 
            Channel.CreateBounded<byte[]>(new BoundedChannelOptions(100)
            {
                FullMode = BoundedChannelFullMode.Wait,
                SingleReader = false,
                SingleWriter = false
            }));
            
        services.AddSingleton<IImageProcessingService, ImageProcessingService>();
        return services;
    }
}

// MagickImage对象池策略
public class MagickImagePooledObjectPolicy : PooledObjectPolicy<MagickImage>
{
    public override MagickImage Create() => new MagickImage();
    
    public override bool Return(MagickImage obj)
    {
        obj.Dispose();
        return true;
    }
}

// 示例使用
public static class Program
{
    public static async Task Main(string[] args)
    {
        var services = new ServiceCollection()
            .AddImageProcessingServices()
            .BuildServiceProvider();
            
        var imageService = services.GetRequiredService<IImageProcessingService>();
        
        var imageData = await File.ReadAllBytesAsync("test.jpg");
        var resizedImage = await imageService.ResizeImageAsync(imageData, 800, 600);
        
        await File.WriteAllBytesAsync("resized.jpg", resizedImage);
    }
}