#:sdk Microsoft.NET.Sdk.Web
#:package Finbuckle.MultiTenant@6.10.0
#:package System.Threading.Channels@8.0.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:package MemoryPack@2.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using System.Threading.Channels;
using Finbuckle.MultiTenant;
using Microsoft.Extensions.ObjectPool;
using MemoryPack;
using System.Buffers;
using System.Runtime.CompilerServices;

/*
// 在Startup.cs或Program.cs中注册服务
builder.Services.AddTenantLifecycle();

// 发布租户创建事件示例
var processor = services.GetRequiredService<TenantLifecycleProcessor>();
await processor.PublishEventAsync(new TenantLifecycleEvent
{
    EventType = TenantLifecycleEventType.TenantCreated,
    TenantId = "tenant1",
    Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
    Payload = MemoryPackSerializer.Serialize(new AppTenantInfo { ... })
});
*/

// 1. 租户生命周期事件类型
[MemoryPackable]
public enum TenantLifecycleEventType
{
    TenantCreated = 1,
    TenantUpdated = 2,
    TenantDeleted = 3,
    TenantSuspended = 4,
    TenantReactivated = 5
}

// 2. 租户生命周期事件数据(CPU cache-line对齐)
[MemoryPackable]
[SkipLocalsInit]
public partial struct TenantLifecycleEvent
{
    public TenantLifecycleEventType EventType { get; set; }
    public string TenantId { get; set; }
    public long Timestamp { get; set; }
    public ReadOnlyMemory<byte> Payload { get; set; }
}

// 3. 高性能租户生命周期事件处理器(Disruptor模式)
[SkipLocalsInit]
public sealed class TenantLifecycleProcessor : BackgroundService
{
    private readonly Channel<TenantLifecycleEvent> _eventChannel;
    private readonly ObjectPool<TenantEventContext> _contextPool;
    private readonly TailLatencyOptimizer _latencyOptimizer;
    private readonly IMultiTenantStore<AppTenantInfo> _tenantStore;
    private readonly ILogger<TenantLifecycleProcessor> _logger;

    public TenantLifecycleProcessor(
        IMultiTenantStore<AppTenantInfo> tenantStore,
        ILogger<TenantLifecycleProcessor> logger)
    {
        _tenantStore = tenantStore;
        _logger = logger;
        _latencyOptimizer = new TailLatencyOptimizer();
        
        // Disruptor模式通道配置
        _eventChannel = Channel.CreateBounded<TenantLifecycleEvent>(new BoundedChannelOptions(10000)
        {
            SingleReader = true,
            AllowSynchronousContinuations = true,
            FullMode = BoundedChannelFullMode.DropOldest
        });

        // 上下文对象池
        _contextPool = new DefaultObjectPool<TenantEventContext>(
            new TenantEventContextPooledPolicy(), 1000);
    }

    // 4. 发布租户事件(零拷贝优化)
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async ValueTask PublishEventAsync(TenantLifecycleEvent @event)
    {
        await _eventChannel.Writer.WriteAsync(@event);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await foreach (var @event in _eventChannel.Reader.ReadAllAsync(stoppingToken))
        {
            var context = _contextPool.Get();
            try
            {
                await ProcessEventAsync(@event, context);
            }
            finally
            {
                _contextPool.Return(context);
            }
        }
    }

    // 5. 事件处理核心逻辑(使用Span优化)
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task ProcessEventAsync(TenantLifecycleEvent @event, TenantEventContext context)
    {
        switch (@event.EventType)
        {
            case TenantLifecycleEventType.TenantCreated:
                await HandleTenantCreated(@event, context);
                break;
            case TenantLifecycleEventType.TenantUpdated:
                await HandleTenantUpdated(@event, context);
                break;
            case TenantLifecycleEventType.TenantDeleted:
                await HandleTenantDeleted(@event, context);
                break;
            case TenantLifecycleEventType.TenantSuspended:
                await HandleTenantSuspended(@event, context);
                break;
            case TenantLifecycleEventType.TenantReactivated:
                await HandleTenantReactivated(@event, context);
                break;
        }
    }

    // 6. 具体事件处理器实现
    private async Task HandleTenantCreated(TenantLifecycleEvent @event, TenantEventContext context)
    {
        // 使用MemoryPack反序列化payload
        var tenantInfo = MemoryPackSerializer.Deserialize<AppTenantInfo>(@event.Payload.Span);
        
        // 初始化租户资源
        await InitializeTenantResources(tenantInfo);
        
        _logger.LogInformation("Tenant {TenantId} created at {Timestamp}", 
            @event.TenantId, @event.Timestamp);
    }

    private async Task InitializeTenantResources(AppTenantInfo tenantInfo)
    {
        // 这里可以添加租户数据库初始化、缓存预热等逻辑
        // 使用您现有的TenantAwareCache等组件
    }
}

// 7. 租户事件上下文(对象池优化)
[SkipLocalsInit]
public class TenantEventContext
{
    public byte[] Buffer { get; } = new byte[4096]; // Cache-line对齐
}

// 8. 上下文对象池策略
public class TenantEventContextPooledPolicy : PooledObjectPolicy<TenantEventContext>
{
    public override TenantEventContext Create() => new();

    public override bool Return(TenantEventContext obj) => true;
}

// 9. 租户生命周期服务扩展方法
public static class TenantLifecycleExtensions
{
    public static IServiceCollection AddTenantLifecycle(this IServiceCollection services)
    {
        services.AddSingleton<TenantLifecycleProcessor>();
        services.AddHostedService(provider => 
            provider.GetRequiredService<TenantLifecycleProcessor>());
        return services;
    }
}