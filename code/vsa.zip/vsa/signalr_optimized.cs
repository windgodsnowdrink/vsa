#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.AspNetCore.SignalR@8.0.0
#:package MessagePack@2.5.122
#:package BrotliSharpLib@0.3.3
#:package Microsoft.Extensions.Options@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.IO.Compression;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder();

// 1. 压缩算法动态切换
builder.Services.AddSingleton<ICompressionStrategy>(sp => 
    new AdaptiveCompressionStrategy(
        Options.Create(new CompressionOptions {
            DefaultAlgorithm = CompressionType.LZ4,
            FallbackAlgorithm = CompressionType.Brotli
        }),
        new ThreadLocal<Span<byte>>(() => stackalloc byte[1024])));

// 2. 离线消息过期策略
builder.Services.AddSingleton<IMessageExpiration>(sp => 
    new TimeBasedExpiration(
        TimeSpan.FromDays(7),
        new ThreadLocal<Span<byte>>(() => stackalloc byte[256])));

// 3. QoS动态调整机制
builder.Services.AddSingleton<IQoSAdjuster>(sp => 
    new DynamicQoSAdjuster(
        new ThreadLocal<Span<byte>>(() => stackalloc byte[512])));

var app = builder.Build();
app.MapHub<OptimizedHub>("/optimized");
app.Run();

// 自适应压缩策略
[SkipLocalsInit]
public class AdaptiveCompressionStrategy : ICompressionStrategy
{
    private readonly IOptions<CompressionOptions> _options;
    private readonly ThreadLocal<Span<byte>> _buffer;
    
    public AdaptiveCompressionStrategy(
        IOptions<CompressionOptions> options,
        ThreadLocal<Span<byte>> buffer)
    {
        _options = options;
        _buffer = buffer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe byte[] Compress(byte[] data)
    {
        Span<byte> buffer = _buffer.Value;
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0)
            {
                // 根据数据特征动态选择压缩算法
                return data.Length > 1024 ? 
                    CompressWithLZ4(data) : 
                    CompressWithBrotli(data);
            }
        }
        return data;
    }
}

// 时间过期策略
[SkipLocalsInit]
public class TimeBasedExpiration : IMessageExpiration
{
    private readonly TimeSpan _ttl;
    private readonly ThreadLocal<Span<byte>> _buffer;
    
    public TimeBasedExpiration(
        TimeSpan ttl,
        ThreadLocal<Span<byte>> buffer)
    {
        _ttl = ttl;
        _buffer = buffer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe bool IsExpired(DateTimeOffset timestamp)
    {
        Span<byte> buffer = _buffer.Value;
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0)
            {
                return DateTimeOffset.UtcNow - timestamp > _ttl;
            }
        }
        return false;
    }
}

// 动态QoS调整器
[SkipLocalsInit]
public class DynamicQoSAdjuster : IQoSAdjuster
{
    private readonly ThreadLocal<Span<byte>> _buffer;
    private int _currentLoadLevel;
    
    public DynamicQoSAdjuster(ThreadLocal<Span<byte>> buffer)
    {
        _buffer = buffer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe QoSPriority AdjustPriority(QoSPriority currentPriority)
    {
        Span<byte> buffer = _buffer.Value;
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0)
            {
                // 根据系统负载动态调整优先级
                var load = GetSystemLoad();
                return load > 70 ? 
                    DowngradePriority(currentPriority) : 
                    UpgradePriority(currentPriority);
            }
        }
        return currentPriority;
    }
}

public enum CompressionType
{
    LZ4,
    Brotli,
    GZip
}

public class CompressionOptions
{
    public CompressionType DefaultAlgorithm { get; set; }
    public CompressionType FallbackAlgorithm { get; set; }
}