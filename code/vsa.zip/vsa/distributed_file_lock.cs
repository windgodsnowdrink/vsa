#:sdk Microsoft.NET.Sdk.Web
#:package RedLock.net@2.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable

using RedLockNet;
using RedLockNet.SERedis;

var builder = WebApplication.CreateBuilder(args);

// 1. 分布式锁配置
builder.Services.AddSingleton<IDistributedLockFactory>(_ => 
    RedLockFactory.Create(new List<RedLockMultiplexer> {
        ConnectionMultiplexer.Connect("redis1:6379"),
        ConnectionMultiplexer.Connect("redis2:6379"),
        ConnectionMultiplexer.Connect("redis3:6379")
    }));

// 2. 文件锁服务
public sealed class FileLockService
{
    private readonly IDistributedLockFactory _lockFactory;
    
    public async Task<bool> TryLockFileAsync(string filePath, TimeSpan expiry)
    {
        using var redLock = await _lockFactory.CreateLockAsync(
            $"filelock:{filePath}", 
            expiry,
            TimeSpan.FromSeconds(1),
            TimeSpan.FromMilliseconds(100));
        
        return redLock.IsAcquired;
    }
}

// 分布式锁服务增强版（支持自动续期）
public sealed class DistributedLockService : BackgroundService
{
    private readonly IDistributedLockFactory _lockFactory;
    private readonly ConcurrentDictionary<string, (IRedLock, CancellationTokenSource)> _activeLocks = new();

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            await RenewLocksAsync();
            await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
        }
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task RenewLocksAsync()
    {
        foreach (var (resource, (redLock, cts)) in _activeLocks)
        {
            if (redLock.IsAcquired && redLock.InstanceSummary.ExpiryTime < DateTime.UtcNow.AddSeconds(10))
            {
                await redLock.ExtendAsync(TimeSpan.FromSeconds(30), cts.Token);
            }
        }
    }
}