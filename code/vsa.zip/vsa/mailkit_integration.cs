#:sdk Microsoft.NET.Sdk.Web
#:package MailKit@4.3.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:package System.Threading.Channels@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using System.Buffers;
using System.Threading.Channels;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using Microsoft.Extensions.ObjectPool;
using System.Runtime.CompilerServices;

// 1. 邮件配置模型(CPU cache-line对齐)
[SkipLocalsInit]
public class SmtpOptions
{
    public string Host { get; set; } = string.Empty;
    public int Port { get; set; } = 587;
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public bool UseSsl { get; set; } = true;
    public int MaxRetryCount { get; set; } = 3;
}

// 2. 高性能邮件服务(Disruptor模式)
[SkipLocalsInit]
public sealed class EmailService : BackgroundService
{
    private readonly Channel<EmailMessage> _emailChannel;
    private readonly ObjectPool<SmtpClient> _clientPool;
    private readonly SmtpOptions _options;
    private readonly TailLatencyOptimizer _latencyOptimizer;

    public EmailService(SmtpOptions options)
    {
        _options = options;
        _latencyOptimizer = new TailLatencyOptimizer();
        
        // Disruptor模式通道配置
        _emailChannel = Channel.CreateBounded<EmailMessage>(new BoundedChannelOptions(10000)
        {
            SingleReader = true,
            AllowSynchronousContinuations = true,
            FullMode = BoundedChannelFullMode.DropOldest
        });

        // SMTP客户端对象池
        _clientPool = new DefaultObjectPool<SmtpClient>(
            new SmtpClientPooledPolicy(options), 
            Environment.ProcessorCount * 2);
    }

    // 3. 发送邮件(零拷贝优化)
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async ValueTask SendEmailAsync(EmailMessage message)
    {
        await _emailChannel.Writer.WriteAsync(message);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await foreach (var message in _emailChannel.Reader.ReadAllAsync(stoppingToken))
        {
            var client = _clientPool.Get();
            try
            {
                await ProcessEmailAsync(client, message);
            }
            finally
            {
                _clientPool.Return(client);
            }
        }
    }

    // 4. 邮件处理核心逻辑
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task ProcessEmailAsync(SmtpClient client, EmailMessage message)
    {
        var mimeMessage = new MimeMessage();
        mimeMessage.From.Add(new MailboxAddress(message.FromName, message.FromEmail));
        mimeMessage.To.Add(new MailboxAddress(message.ToName, message.ToEmail));
        mimeMessage.Subject = message.Subject;

        var builder = new BodyBuilder
        {
            HtmlBody = message.HtmlBody,
            TextBody = message.TextBody
        };

        // 使用Span优化附件处理
        if (message.Attachments != null)
        {
            foreach (var attachment in message.Attachments)
            {
                using var stream = new MemoryStream(attachment.Data);
                builder.Attachments.Add(attachment.FileName, stream);
            }
        }

        mimeMessage.Body = builder.ToMessageBody();

        // 连接SMTP服务器
        if (!client.IsConnected)
        {
            await client.ConnectAsync(
                _options.Host, 
                _options.Port, 
                _options.UseSsl ? SecureSocketOptions.StartTls : SecureSocketOptions.None);
            
            if (!string.IsNullOrEmpty(_options.Username))
            {
                await client.AuthenticateAsync(_options.Username, _options.Password);
            }
        }

        // 发送邮件
        await client.SendAsync(mimeMessage);
    }
}

// 5. SMTP客户端对象池策略
public class SmtpClientPooledPolicy : PooledObjectPolicy<SmtpClient>
{
    private readonly SmtpOptions _options;

    public SmtpClientPooledPolicy(SmtpOptions options)
    {
        _options = options;
    }

    public override SmtpClient Create()
    {
        return new SmtpClient();
    }

    public override bool Return(SmtpClient obj)
    {
        if (obj.IsConnected)
        {
            obj.Disconnect(true);
        }
        return true;
    }
}

// 6. 邮件消息结构(内存优化)
[SkipLocalsInit]
public class EmailMessage
{
    public string FromName { get; set; } = string.Empty;
    public string FromEmail { get; set; } = string.Empty;
    public string ToName { get; set; } = string.Empty;
    public string ToEmail { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string HtmlBody { get; set; } = string.Empty;
    public string TextBody { get; set; } = string.Empty;
    public List<EmailAttachment>? Attachments { get; set; }
}

// 7. 邮件附件结构(使用Span优化)
[SkipLocalsInit]
public class EmailAttachment
{
    public string FileName { get; set; } = string.Empty;
    public byte[] Data { get; set; } = Array.Empty<byte>();
}

// 8. 注册服务扩展方法
public static class EmailServiceExtensions
{
    public static IServiceCollection AddEmailService(this IServiceCollection services, Action<SmtpOptions> configure)
    {
        var options = new SmtpOptions();
        configure(options);
        
        services.AddSingleton(options);
        services.TryAddSingleton<EmailService>();
        services.TryAddHostedService(provider => provider.GetRequiredService<EmailService>());
        
        return services;
    }
}

// 9. 主程序配置
var builder = WebApplication.CreateBuilder(args);

// 配置邮件服务
builder.Services.AddEmailService(options =>
{
    options.Host = "smtp.example.com";
    options.Port = 587;
    options.Username = "user@example.com";
    options.Password = "password";
    options.UseSsl = true;
});

var app = builder.Build();

// 使用示例
app.MapGet("/send-test", async (EmailService emailService) =>
{
    await emailService.SendEmailAsync(new EmailMessage
    {
        FromName = "Test Sender",
        FromEmail = "sender@example.com",
        ToName = "Test Recipient",
        ToEmail = "recipient@example.com",
        Subject = "Test Email",
        HtmlBody = "<h1>Hello World</h1><p>This is a test email</p>"
    });
    
    return "Email sent";
});

app.Run();