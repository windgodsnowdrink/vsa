#:sdk Microsoft.NET.Sdk.Web
#:package CSharp-easy-RSA-PEM@3.0.0
#:package ACMESharpCore@2.0.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Channels;
using Microsoft.Extensions.ObjectPool;

[SkipLocalsInit]
public sealed class AcmeCertificateService : BackgroundService
{
    private readonly Channel<CertificateRequest> _requestChannel;
    private readonly ObjectPool<RSA> _rsaPool;
    private readonly TailLatencyOptimizer _latencyOptimizer;
    private readonly AcmeClient _acmeClient;

    public AcmeCertificateService(AcmeClient acmeClient)
    {
        _acmeClient = acmeClient;
        _latencyOptimizer = new TailLatencyOptimizer();
        _requestChannel = Channel.CreateBounded<CertificateRequest>(
            new BoundedChannelOptions(1000)
            {
                SingleReader = true,
                FullMode = BoundedChannelFullMode.Wait
            });
        
        _rsaPool = new DefaultObjectPool<RSA>(
            new RsaPooledPolicy(2048), 
            Environment.ProcessorCount * 2);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await foreach (var request in _requestChannel.Reader.ReadAllAsync(stoppingToken))
        {
            using var latencyToken = _latencyOptimizer.BeginOperation();
            var rsa = _rsaPool.Get();
            try
            {
                var cert = await ProcessCertificateRequestAsync(request, rsa, stoppingToken);
                await SaveCertificateAsync(cert, stoppingToken);
            }
            finally
            {
                _rsaPool.Return(rsa);
            }
        }
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task<X509Certificate2> ProcessCertificateRequestAsync(
        CertificateRequest request, 
        RSA rsa,
        CancellationToken ct)
    {
        // 1. 生成CSR
        var csr = new CertificateRequest(
            $"CN={request.Domain}", 
            rsa, 
            HashAlgorithmName.SHA512, 
            RSASignaturePadding.Pkcs1);
        
        // 2. ACME注册和验证
        var acmeOrder = await _acmeClient.CreateOrderAsync(new[] { request.Domain }, ct);
        
        // 3. 完成挑战验证
        await _acmeClient.CompleteChallengeAsync(acmeOrder, ct);
        
        // 4. 获取证书
        var certPem = await _acmeClient.GetCertificateAsync(csr, ct);
        
        // 5. 转换为X509Certificate2
        return X509Certificate2.CreateFromPem(certPem);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task SaveCertificateAsync(X509Certificate2 cert, CancellationToken ct)
    {
        // 证书存储逻辑
    }
}

[SkipLocalsInit]
internal sealed class RsaPooledPolicy : PooledObjectPolicy<RSA>
{
    private readonly int _keySize;

    public RsaPooledPolicy(int keySize) => _keySize = keySize;

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public override RSA Create() => RSA.Create(_keySize);

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public override bool Return(RSA obj)
    {
        if (obj.KeySize != _keySize) return false;
        return true;
    }
}

// 启动配置
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<AcmeClient>(provider => 
    new AcmeClient(new Uri("https://acme-v02.api.letsencrypt.org/directory")));
builder.Services.AddSingleton<AcmeCertificateService>();
builder.Services.AddHostedService<AcmeCertificateService>();

var app = builder.Build();
app.MapGet("/", () => "ACME Certificate Service");
app.Run();