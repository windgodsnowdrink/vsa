#:sdk Microsoft.NET.Sdk.Web
#:package System.Threading.Channels@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System.Threading.Channels;
using System.Threading.Tasks.Dataflow;

// 高性能生产者消费者服务
public class ChannelProcessor<T> : IAsyncDisposable
{
    private readonly Channel<T> _channel;
    private readonly Task _processingTask;
    private readonly CancellationTokenSource _cts = new();

    public ChannelProcessor(int capacity = 1000)
    {
        // 使用有界通道控制内存使用
        _channel = Channel.CreateBounded<T>(new BoundedChannelOptions(capacity)
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleWriter = false,
            SingleReader = false
        });

        _processingTask = Task.Run(ProcessItemsAsync);
    }

    // 生产者方法
    public async ValueTask ProduceAsync(T item)
    {
        await _channel.Writer.WriteAsync(item, _cts.Token);
    }

    // 消费者处理逻辑
    private async Task ProcessItemsAsync()
    {
        try
        {
            await foreach (var item in _channel.Reader.ReadAllAsync(_cts.Token))
            {
                // 处理项目逻辑
                await ProcessItemAsync(item);
            }
        }
        catch (OperationCanceledException)
        {
            // 正常退出
        }
    }

    public class BatchProcessor<T> : ChannelProcessor<T>
    {
        private readonly int _batchSize;
        private readonly TimeSpan _batchTimeout;
    
        public BatchProcessor(int batchSize, TimeSpan batchTimeout, int capacity = 1000) 
            : base(capacity)
        {
            _batchSize = batchSize;
            _batchTimeout = batchTimeout;
        }
    
        protected override async Task ProcessItemAsync(T item)
        {
            var batch = new List<T>(_batchSize) { item };
            var batchTimer = new Timer(_ => { }, null, _batchTimeout, Timeout.InfiniteTimeSpan);
    
            try
            {
                while (batch.Count < _batchSize && await _channel.Reader.WaitToReadAsync())
                {
                    if (_channel.Reader.TryRead(out var nextItem))
                    {
                        batch.Add(nextItem);
                    }
                }
    
                await ProcessBatchAsync(batch);
            }
            finally
            {
                await batchTimer.DisposeAsync();
            }
        }
    
        protected virtual Task ProcessBatchAsync(IReadOnlyList<T> batch)
        {
            // 子类实现具体批处理逻辑
            return Task.CompletedTask;
        }
    }

    public async ValueTask DisposeAsync()
    {
        _cts.Cancel();
        _channel.Writer.Complete();
        await _processingTask;
    }
}

// 具体实现示例 - Todo处理器
public class TodoProcessor : ChannelProcessor<TodoEvent>
{
    private readonly ObjectPool<Memory<byte>> _memoryPool;

    public TodoProcessor(ObjectPool<Memory<byte>> memoryPool) 
        : base(10000) // 10,000容量
    {
        _memoryPool = memoryPool;
    }

    protected override async Task ProcessItemAsync(TodoEvent todo)
    {
        using var memory = _memoryPool.Get();
        // 高性能处理逻辑...
    }
}

// 启动配置
var builder = WebApplication.CreateBuilder();

// 配置服务
builder.Services.AddSingleton<ObjectPool<Memory<byte>>>(new DefaultObjectPool<Memory<byte>>(
    new DefaultPooledObjectPolicy<Memory<byte>>(), 1000));

builder.Services.AddSingleton<TodoProcessor>();

var app = builder.Build();

// 测试端点
app.MapPost("/todos", async (TodoProcessor processor, TodoEvent todo) =>
{
    await processor.ProduceAsync(todo);
    return Results.Ok();
});

app.Run();

// Todo事件模型
public class TodoEvent
{
    public int Id { get; set; }
    public string Title { get; set; }
    public bool IsCompleted { get; set; }
}


public class BackpressureChannel<T> : Channel<T>
{
    private readonly SemaphoreSlim _backpressureSemaphore;
    private readonly int _highWaterMark;
    private readonly int _lowWaterMark;

    public BackpressureChannel(int capacity, int highWaterMark, int lowWaterMark)
    {
        _highWaterMark = highWaterMark;
        _lowWaterMark = lowWaterMark;
        _backpressureSemaphore = new SemaphoreSlim(capacity);

        var options = new BoundedChannelOptions(capacity)
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleWriter = false,
            SingleReader = false
        };

        var channel = Channel.CreateBounded<T>(options);
        Reader = channel.Reader;
        Writer = channel.Writer;
    }

    public async ValueTask WriteWithBackpressureAsync(T item, CancellationToken ct = default)
    {
        await _backpressureSemaphore.WaitAsync(ct);
        try
        {
            await Writer.WriteAsync(item, ct);
            
            if (Reader.Count >= _highWaterMark)
            {
                await Task.Delay(CalculateBackpressureDelay(), ct);
            }
        }
        finally
        {
            if (Reader.Count <= _lowWaterMark)
            {
                _backpressureSemaphore.Release();
            }
        }
    }

    private TimeSpan CalculateBackpressureDelay()
    {
        var overload = Reader.Count - _highWaterMark;
        return TimeSpan.FromMilliseconds(Math.Pow(2, overload));
    }
}

public class ChannelMetrics
{
    private readonly Counter<int> _itemsProcessed;
    private readonly Histogram<double> _processingTime;
    private readonly UpDownCounter<int> _queueLength;

    public ChannelMetrics(IMeterFactory meterFactory)
    {
        var meter = meterFactory.Create("System.Threading.Channels");
        _itemsProcessed = meter.CreateCounter<int>("items.processed");
        _processingTime = meter.CreateHistogram<double>("processing.time.ms");
        _queueLength = meter.CreateUpDownCounter<int>("queue.length");
    }

    public void RecordProcessed(int count, double elapsedMs)
    {
        _itemsProcessed.Add(count);
        _processingTime.Record(elapsedMs);
    }

    public void UpdateQueueLength(int length)
    {
        _queueLength.Add(length);
    }
}

// 在Startup中注册
builder.Services.AddOpenTelemetry()
    .WithMetrics(metrics => metrics
        .AddMeter("System.Threading.Channels")
        .AddPrometheusExporter());


public class ResilientChannelProcessor<T> : ChannelProcessor<T>
{
    private readonly AsyncRetryPolicy _retryPolicy;
    private readonly AsyncCircuitBreakerPolicy _circuitBreaker;

    public ResilientChannelProcessor()
    {
        _retryPolicy = Policy
            .Handle<Exception>()
            .WaitAndRetryAsync(3, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)));

        _circuitBreaker = Policy
            .Handle<Exception>()
            .CircuitBreakerAsync(5, TimeSpan.FromSeconds(30));
    }

    protected override async Task ProcessItemAsync(T item)
    {
        await Policy.WrapAsync(_retryPolicy, _circuitBreaker)
            .ExecuteAsync(async () => 
            {
                try
                {
                    await base.ProcessItemAsync(item);
                }
                catch (Exception ex)
                {
                    // 记录错误指标
                    ChannelMetrics?.RecordError(ex);
                    throw;
                }
            });
    }
}