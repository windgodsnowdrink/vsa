#:sdk Microsoft.NET.Sdk.Web
#:package MediatR@12.1.1
#:package Microsoft.Orleans.Core@3.7.2
#:package Microsoft.Orleans.OrleansRuntime@3.7.2
#:package System.Threading.Channels@7.0.0
#:property TargetFramework net10.0
#:property Nullable enable

using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Orleans;
using Orleans.Concurrency;
using Orleans.Runtime;
using System.Buffers;
using System.Collections.Concurrent;
using System.Threading.Channels;
using System.Threading.Tasks;

// 1. 定义Orleans Grain接口
public interface IMediatorGrain : IGrainWithGuidKey
{
    Task<TResponse> Send<TResponse>(IRequest<TResponse> request);
    Task Publish(INotification notification);
}

// 2. 实现Mediator Grain
[Reentrant]
public class MediatorGrain : Grain, IMediatorGrain
{
    private readonly IMediator _mediator;
    private readonly ConcurrentDictionary<Guid, TaskCompletionSource<object>> _pendingRequests = new();

    public MediatorGrain([PersistentState("mediatorState", "mediatorStore")] IPersistentState<MediatorGrainState> state)
    {
        // 从DI获取MediatR实例
        _mediator = this.ServiceProvider.GetRequiredService<IMediator>();
    }

    public async Task<TResponse> Send<TResponse>(IRequest<TResponse> request)
    {
        return await _mediator.Send(request);
    }

    public async Task Publish(INotification notification)
    {
        await _mediator.Publish(notification);
    }

    // 跨Actor消息路由方法
    public async Task<TResponse> RouteToActor<TResponse>(IRequest<TResponse> request, GrainId targetActorId)
    {
        var targetGrain = GrainFactory.GetGrain<IMediatorGrain>(targetActorId);
        return await targetGrain.Send(request);
    }
}

// 3. 定义Orleans Grain状态
public class MediatorGrainState
{
    public List<INotification> PendingNotifications { get; set; } = new();
}

// 4. 分布式MediatR处理器
public class OrleansNotificationHandler<TNotification> : INotificationHandler<TNotification>
    where TNotification : INotification
{
    private readonly IGrainFactory _grainFactory;

    public OrleansNotificationHandler(IGrainFactory grainFactory)
    {
        _grainFactory = grainFactory;
    }

    public async Task Handle(TNotification notification, CancellationToken cancellationToken)
    {
        // 获取所有相关的Mediator Grains并发布通知
        var mediatorGrains = await GetRelevantMediatorGrains();
        var tasks = mediatorGrains.Select(g => g.Publish(notification));
        await Task.WhenAll(tasks);
    }

    private async Task<IEnumerable<IMediatorGrain>> GetRelevantMediatorGrains()
    {
        // 实现获取相关Grains的逻辑
        return Enumerable.Empty<IMediatorGrain>();
    }
}

//分布式追踪增强 ：
//- 集成OpenTelemetry实现端到端追踪
// - 在CrossGrainCommand/Event中添加TraceId/SpanId
// 序列化优化 ：
// - 使用MemoryPack替代JSON序列化
// - 实现零拷贝消息传输
[MemoryPackable]
public partial record CrossGrainCommand(string TraceId, string SpanId, string TargetGrainId, object Payload) : IRequest;

// 消息持久化与重试 ：
// - 实现IMessageStore接口持久化重要消息
// - 添加Dead Letter Queue处理失败消息
public interface IMessageStore
{
    Task SaveAsync(CrossGrainCommand command);
    Task RetryFailedMessagesAsync();
}

// 性能监控 ：
// - 使用Metrics.NET添加关键指标监控
// - 跟踪消息处理延迟、吞吐量等
public static class MediatorMetrics
{
    public static readonly Histogram CommandDuration = Metrics
        .CreateHistogram("mediator_command_duration", "Command processing duration");
}

// 安全增强 ：
// - 在CrossGrainCommand中添加JWT令牌验证
// - 实现IGrainCallFilter进行权限检查
public class AuthGrainFilter : IIncomingGrainCallFilter
{
    public async Task Invoke(IIncomingGrainCallContext context)
    {
        // 验证逻辑
        await context.Invoke();
    }
}
// 容错设计 ：
// - 实现Circuit Breaker模式
// - 添加Bulkhead隔离策略
services.AddResiliencePipeline("mediator-pipeline", builder =>
{
    builder.AddCircuitBreaker(new()
    {
        FailureRatio = 0.5,
        SamplingDuration = TimeSpan.FromSeconds(10)
    });
});

// 5. DI扩展
public static class MediatROrleansIntegrationExtensions
{
    public static IServiceCollection AddMediatROrleansIntegration(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssembly(typeof(MediatROrleansIntegrationExtensions).Assembly);
        });

        // 注册Orleans特定的处理器
        services.AddTransient(typeof(INotificationHandler<>), typeof(OrleansNotificationHandler<>));
        
        // 添加高性能通道用于跨Grain通信
        services.AddSingleton<Channel<IRequest>>(sp => 
            Channel.CreateUnbounded<IRequest>(new UnboundedChannelOptions()
            {
                SingleReader = true,
                SingleWriter = false
            }));
            
        // 配置Orleans序列化优化
        services.Configure<OrleansJsonSerializerOptions>(options =>
        {
            options.JsonSerializerOptions.WriteIndented = false;
            options.JsonSerializerOptions.DefaultBufferSize = 16 * 1024;
        });

        // 添加分布式追踪
        services.AddOpenTelemetry()
            .WithTracing(builder => builder
                .AddSource("MediatR.Orleans")
                .AddOtlpExporter());

        services.AddSingleton<IIncomingGrainCallFilter, MediatorGrain>();
        services.AddSingleton<HighPerformanceChannel<CrossGrainCommand>>();
        services.AddHostedService<ChannelBackgroundService>();
        services.AddTransient<IRequestHandler<CrossGrainCommand>, ZeroCopyMessageHandler>();
        services.AddTransient<INotificationHandler<CrossGrainEvent>, CrossGrainEventHandler>();

        return services;
    }
}

// Program.cs 示例配置
/*
var builder = WebApplication.CreateBuilder(args);

// 配置Orleans
builder.UseOrleans(siloBuilder =>
{
    siloBuilder.UseLocalhostClustering();
    siloBuilder.AddMemoryGrainStorage("mediatorStore");
});

// 添加MediatR和Orleans集成
builder.Services.AddMediatROrleansIntegration();

var app = builder.Build();

app.MapGet("/send-to-actor", async (IMediator mediator, GrainId actorId, string message) =>
{
    var request = new SampleRequest(message);
    var mediatorGrain = app.Services.GetRequiredService<IGrainFactory>().GetGrain<IMediatorGrain>(actorId);
    var response = await mediatorGrain.Send(request);
    return Results.Ok(response);
});

app.Run();
*/

// 客户端示例
/*
// 获取Mediator Grain
var mediatorGrain = grainFactory.GetGrain<IMediatorGrain>(Guid.NewGuid());

// 发送请求
var response = await mediatorGrain.Send(new SampleRequest("Hello from client"));

// 路由到特定Actor
var targetActorId = GrainId.Create("SomeActorType", "actor1");
var routedResponse = await mediatorGrain.RouteToActor(new SampleRequest("Routed message"), targetActorId);
*/

/*
- Kubernetes部署YAML示例
- 配置Horizontal Pod Autoscaler
autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
*/