#:sdk Microsoft.NET.Sdk
#:package HtmlSanitizer@8.0.645
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using HtmlSanitizer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System.Buffers;
using System.Threading.Channels;
using System.Threading;

namespace HtmlSanitizerIntegration
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddHtmlSanitizerServices(this IServiceCollection services, Action<HtmlSanitizerOptions> configureOptions)
        {
            // 配置选项
            services.Configure(configureOptions);
            
            // 注册HtmlSanitizer服务
            services.AddSingleton<IHtmlSanitizer, HtmlSanitizer>(sp =>
            {
                var options = sp.GetRequiredService<IOptions<HtmlSanitizerOptions>>().Value;
                var sanitizer = new HtmlSanitizer();
                
                // 配置基础清理规则
                sanitizer.AllowedAttributes.UnionWith(options.AllowedAttributes);
                sanitizer.AllowedCssProperties.UnionWith(options.AllowedCssProperties);
                sanitizer.AllowedTags.UnionWith(options.AllowedTags);
                
                // 配置URL清理
                if (options.SanitizeUrls)
                {
                    sanitizer.AllowedSchemes.UnionWith(options.AllowedUrlSchemes);
                    sanitizer.AllowDataAttributes = false;
                }
                
                // 配置CSS类清理
                if (options.SanitizeCssClasses)
                {
                    sanitizer.AllowedCssClasses.UnionWith(options.AllowedCssClasses);
                }
                
                // 应用自定义清理策略
                foreach (var strategy in options.CustomStrategies)
                {
                    sanitizer.AddSanitizerStrategy(strategy);
                }
                
                return sanitizer;
            });
            
            // 高性能处理管道
            services.AddSingleton<Channel<HtmlProcessingJob>>(Channel.CreateBounded<HtmlProcessingJob>(1000));
            services.AddHostedService<HtmlProcessingService>();
            
            // 线程安全的对象池
            services.AddSingleton<ObjectPool<HtmlSanitizer>>(sp =>
            {
                var options = sp.GetRequiredService<IOptions<HtmlSanitizerOptions>>().Value;
                return new DefaultObjectPool<HtmlSanitizer>(
                    new HtmlSanitizerPooledObjectPolicy(options),
                    Environment.ProcessorCount * 2);
            });
            
            return services;
        }
    }
    
    public class HtmlSanitizerOptions
    {
        public HashSet<string> AllowedAttributes { get; set; } = new();
        public HashSet<string> AllowedCssProperties { get; set; } = new();
        public HashSet<string> AllowedTags { get; set; } = new();
        
        // URL清理配置
        public bool SanitizeUrls { get; set; } = true;
        public HashSet<string> AllowedUrlSchemes { get; set; } = new() { "http", "https" };
        
        // CSS清理配置
        public bool SanitizeCssClasses { get; set; } = true;
        public HashSet<string> AllowedCssClasses { get; set; } = new();
        
        // 自定义清理策略
        public List<ICustomSanitizerStrategy> CustomStrategies { get; set; } = new();
    }
    
    public record HtmlProcessingJob(string HtmlContent, CancellationToken CancellationToken);
    
    public class HtmlProcessingService : BackgroundService
    {
        private readonly Channel<HtmlProcessingJob> _channel;
        private readonly ObjectPool<HtmlSanitizer> _sanitizerPool;
        
        public HtmlProcessingService(
            Channel<HtmlProcessingJob> channel,
            ObjectPool<HtmlSanitizer> sanitizerPool)
        {
            _channel = channel;
            _sanitizerPool = sanitizerPool;
        }
        
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await foreach (var job in _channel.Reader.ReadAllAsync(stoppingToken))
            {
                var sanitizer = _sanitizerPool.Get();
                try
                {
                    var cleanHtml = sanitizer.Sanitize(job.HtmlContent);
                    // 处理清理后的HTML
                }
                finally
                {
                    _sanitizerPool.Return(sanitizer);
                }
            }
        }
    }
    
    public class HtmlSanitizerPooledObjectPolicy : IPooledObjectPolicy<HtmlSanitizer>
    {
        private readonly HtmlSanitizerOptions _options;
        
        public HtmlSanitizerPooledObjectPolicy(HtmlSanitizerOptions options)
        {
            _options = options;
        }
        
        public HtmlSanitizer Create()
        {
            var sanitizer = new HtmlSanitizer();
            
            // 配置基础清理规则
            sanitizer.AllowedAttributes.UnionWith(_options.AllowedAttributes);
            sanitizer.AllowedCssProperties.UnionWith(_options.AllowedCssProperties);
            sanitizer.AllowedTags.UnionWith(_options.AllowedTags);
            
            // 配置URL清理
            if (_options.SanitizeUrls)
            {
                sanitizer.AllowedSchemes.UnionWith(_options.AllowedUrlSchemes);
                sanitizer.AllowDataAttributes = false;
            }
            
            // 配置CSS类清理
            if (_options.SanitizeCssClasses)
            {
                sanitizer.AllowedCssClasses.UnionWith(_options.AllowedCssClasses);
            }
            
            // 应用自定义清理策略
            foreach (var strategy in _options.CustomStrategies)
            {
                sanitizer.AddSanitizerStrategy(strategy);
            }
            
            return sanitizer;
        }
        
        public bool Return(HtmlSanitizer obj)
        {
            // 重置清理器状态
            obj.AllowedAttributes.Clear();
            obj.AllowedCssProperties.Clear();
            obj.AllowedTags.Clear();
            obj.AllowedSchemes.Clear();
            obj.AllowedCssClasses.Clear();
            obj.RemoveSanitizerStrategies();
            return true;
        }
    }
    
    // 自定义清理策略接口
    public interface ICustomSanitizerStrategy
    {
        void Apply(HtmlSanitizer sanitizer);
    }
    
    // 示例：移除所有iframe的自定义策略
    public class RemoveIframesStrategy : ICustomSanitizerStrategy
    {
        public void Apply(HtmlSanitizer sanitizer)
        {
            sanitizer.PostProcessNode += (sender, args) => 
            {
                if (args.Node.Name.Equals("iframe", StringComparison.OrdinalIgnoreCase))
                {
                    args.DiscardNode = true;
                }
            };
        }
    }
}