#:sdk Microsoft.NET.Sdk.Web
#:package KcpTransport@1.0.0
#:package System.Threading.Channels@8.0.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using System.Net;
using System.Threading.Channels;
using KcpTransport;
using Microsoft.Extensions.ObjectPool;

[SkipLocalsInit]
public sealed class KcpMultiplexer : IAsyncDisposable
{
    private readonly KcpListener _listener;
    private readonly Channel<KcpConnection> _connectionChannel;
    private readonly ObjectPool<KcpStream> _streamPool;
    private readonly TailLatencyOptimizer _latencyOptimizer;
    private readonly CancellationTokenSource _cts;

    public KcpMultiplexer(IPEndPoint endpoint)
    {
        _latencyOptimizer = new TailLatencyOptimizer();
        _cts = new CancellationTokenSource();
        
        var options = new KcpListenerOptions
        {
            ListenEndPoint = endpoint,
            MultiplexerOptions = new KcpMultiplexerOptions
            {
                MaxConcurrentStreams = 1024,
                InitialStreamWindowSize = 1024 * 1024
            }
        };
        
        _listener = new KcpListener(options);
        _connectionChannel = Channel.CreateBounded<KcpConnection>(
            new BoundedChannelOptions(10_000)
            {
                SingleReader = true,
                AllowSynchronousContinuations = true,
                FullMode = BoundedChannelFullMode.DropOldest
            });
        
        _streamPool = new DefaultObjectPool<KcpStream>(
            new KcpStreamPooledPolicy(), 
            Environment.ProcessorCount * 2);
        
        _ = Task.Run(AcceptConnectionsAsync);
        _ = Task.Run(ProcessConnectionsAsync);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task AcceptConnectionsAsync()
    {
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                var connection = await _listener.AcceptConnectionAsync(_cts.Token);
                await _connectionChannel.Writer.WriteAsync(connection, _cts.Token);
            }
            catch (OperationCanceledException) when (_cts.IsCancellationRequested)
            {
                break;
            }
        }
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task ProcessConnectionsAsync()
    {
        await foreach (var connection in _connectionChannel.Reader.ReadAllAsync(_cts.Token))
        {
            _ = Task.Run(async () =>
            {
                using (connection)
                {
                    while (!connection.IsClosed && !_cts.IsCancellationRequested)
                    {
                        try
                        {
                            var stream = await connection.AcceptStreamAsync(_cts.Token);
                            _ = ProcessStreamAsync(stream);
                        }
                        catch (KcpException) { break; }
                    }
                }
            });
        }
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    private async Task ProcessStreamAsync(KcpStream stream)
    {
        using var latencyToken = _latencyOptimizer.BeginOperation();
        var buffer = ArrayPool<byte>.Shared.Rent(4096);
        try
        {
            var bytesRead = await stream.ReadAsync(buffer, _cts.Token);
            // 处理KCP数据流
            await HandleKcpData(buffer.AsMemory(0, bytesRead), stream);
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }

    public async ValueTask DisposeAsync()
    {
        _cts.Cancel();
        _connectionChannel.Writer.Complete();
        await _connectionChannel.Reader.Completion;
        await _listener.DisposeAsync();
    }
}

[SkipLocalsInit]
internal sealed class KcpStreamPooledPolicy : PooledObjectPolicy<KcpStream>
{
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public override KcpStream Create() => throw new NotSupportedException();

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public override bool Return(KcpStream obj)
    {
        if (!obj.CanWrite) return false;
        obj.Reset();
        return true;
    }
}

// 启动配置
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<KcpMultiplexer>(provider => 
    new KcpMultiplexer(new IPEndPoint(IPAddress.Any, 5000)));

var app = builder.Build();
app.MapGet("/", () => "KCP Multiplexer Running");
app.Run();