#:sdk Microsoft.NET.Sdk.Web
#:package MiniProfiler.AspNetCore@4.2.22
#:package OpenTelemetry.Exporter.OpenTelemetryProtocol@1.6.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using StackExchange.Profiling;
using OpenTelemetry.Trace;

var builder = WebApplication.CreateBuilder();

builder.Services.AddMiniProfiler(options =>
{
    options.EnableOpenTelemetryIntegration = true;
    options.OpenTelemetryOptions = new MiniProfilerOpenTelemetryOptions
    {
        Endpoint = "http://localhost:4317",
        Protocol = OpenTelemetryProtocol.Http
    };
});

var app = builder.Build();
app.UseMiniProfiler();
app.MapGet("/", () => "Distributed Tracing Profiler Ready");
app.Run();