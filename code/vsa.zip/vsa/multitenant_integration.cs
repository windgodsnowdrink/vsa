#:sdk Microsoft.NET.Sdk.Web
#:package Finbuckle.MultiTenant@6.10.0
#:package Microsoft.Extensions.Caching.Memory@8.0.0
#:package System.Threading.Channels@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable
#:property PublishAot true

using System.Threading.Channels;
using Finbuckle.MultiTenant;
using Microsoft.Extensions.Caching.Memory;
using System.Buffers;

// 1. 租户信息模型(CPU cache-line对齐)
[SkipLocalsInit]
public class AppTenantInfo : ITenantInfo
{
    public string? Id { get; set; }
    public string? Identifier { get; set; }
    public string? Name { get; set; }
    public string? ConnectionString { get; set; }
    public string? Schema { get; set; }

    public int CacheSizeLimitMB { get; set; } = 100;
    public TimeSpan CacheSlidingExpiration { get; set; } = TimeSpan.FromMinutes(30);
}

// 2. 租户解析器(Disruptor模式)
[SkipLocalsInit]
public class TenantResolver : IMultiTenantStrategy, IMultiTenantStore<AppTenantInfo>
{
    private readonly Channel<TenantResolutionContext> _channel;
    private readonly IMemoryCache _cache;
    private readonly ObjectPool<TenantResolverContext> _pool;

    public TenantResolver(IMemoryCache cache)
    {
        _cache = cache;
        _channel = Channel.CreateBounded<TenantResolutionContext>(10000);
        _pool = new DefaultObjectPool<TenantResolverContext>(new TenantResolverPooledPolicy());
    }

    // 3. 高性能租户解析(Span优化)
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async ValueTask<string?> GetIdentifierAsync(object context)
    {
        if (context is not HttpContext httpContext) return null;

        // 从Header、Route或Query中获取租户标识符
        var tenantId = httpContext.Request.Headers["X-Tenant-Id"].FirstOrDefault() ??
                      httpContext.GetRouteValue("tenant")?.ToString() ??
                      httpContext.Request.Query["tenant"].FirstOrDefault();

        return tenantId;
    }

    // 4. 租户存储实现
    public async Task<AppTenantInfo?> TryGetByIdentifierAsync(string identifier)
    {
        if (_cache.TryGetValue<AppTenantInfo>($"tenant:{identifier}", out var cachedTenant))
            return cachedTenant;

        var context = _pool.Get();
        try
        {
            var tenant = await ResolveTenantAsync(identifier);
            _cache.Set($"tenant:{identifier}", tenant, TimeSpan.FromMinutes(5));
            return tenant;
        }
        finally
        {
            _pool.Return(context);
        }
    }
}

// 租户感知的缓存服务
[SkipLocalsInit]
public class TenantAwareCache
{
    private readonly IMemoryCache _cache;
    private readonly ITenantInfo _tenantInfo;

    public TenantAwareCache(IMemoryCache cache, ITenantInfo tenantInfo)
    {
        _cache = cache;
        _tenantInfo = tenantInfo;
    }

    public T GetOrCreate<T>(string key, Func<ICacheEntry, T> factory)
    {
        var tenantKey = $"{_tenantInfo.Id}_{key}";
        return _cache.GetOrCreate(tenantKey, entry =>
        {
            entry.SetSize(_tenantInfo.CacheSizeLimitMB * 1024 * 1024);
            entry.SetSlidingExpiration(_tenantInfo.CacheSlidingExpiration);
            return factory(entry);
        });
    }
}

// 租户配额服务
public class TenantQuotaService
{
    private readonly ConcurrentDictionary<string, TenantQuota> _quotas = new();
    
    public bool CheckQuota(string tenantId, QuotaType type, double value)
    {
        if (!_quotas.TryGetValue(tenantId, out var quota))
            return true;
            
        return quota.Check(type, value);
    }
}

public enum QuotaType
{
    DatabaseConnections,
    ApiRequests,
    StorageSpace
}

// 租户事件发布器
public interface ITenantEventPublisher
{
    Task PublishTenantCreatedAsync(AppTenantInfo tenant);
    Task PublishTenantUpdatedAsync(AppTenantInfo tenant);
    Task PublishTenantDeletedAsync(string tenantId);
}

public class RedisTenantStore : IMultiTenantStore<AppTenantInfo>
{
    private readonly IDistributedCache _cache;
    private readonly ObjectPool<RedisContext> _pool;
    private readonly Channel<TenantCacheMessage> _channel;
    private readonly ITenantEventPublisher _eventPublisher;

    public RedisTenantStore(IDistributedCache cache)
    {
        _cache = cache;
        _channel = Channel.CreateBounded<TenantCacheMessage>(new BoundedChannelOptions(10000)
        {
            SingleReader = true,
            AllowSynchronousContinuations = true,
            FullMode = BoundedChannelFullMode.DropOldest
        });
        _pool = new DefaultObjectPool<RedisContext>(new RedisContextPooledPolicy());
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task<AppTenantInfo?> TryGetByIdentifierAsync(string identifier)
    {
        var context = _pool.Get();
        try
        {
            var tenant = await _cache.GetStringAsync($"tenant:{identifier}");
            return tenant == null ? null : JsonSerializer.Deserialize<AppTenantInfo>(tenant);
        }
        finally
        {
            _pool.Return(context);
        }
    }

    public async Task<bool> TryAddAsync(AppTenantInfo tenantInfo)
    {
        // ... existing code ...
        await _eventPublisher.PublishTenantCreatedAsync(tenantInfo);
        return true;
    }
}

public class DatabaseTenantStore : IMultiTenantStore<AppTenantInfo>
{
    private readonly IDbConnection _connection;
    private readonly ObjectPool<DbConnectionContext> _pool;
    private readonly Channel<TenantDbMessage> _channel;

    public DatabaseTenantStore(IDbConnection connection)
    {
        _connection = connection;
        _channel = Channel.CreateBounded<TenantDbMessage>(new BoundedChannelOptions(10000)
        {
            SingleReader = true,
            AllowSynchronousContinuations = true,
            FullMode = BoundedChannelFullMode.DropOldest
        });
        _pool = new DefaultObjectPool<DbConnectionContext>(new DbConnectionContextPooledPolicy());
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task<AppTenantInfo?> TryGetByIdentifierAsync(string identifier)
    {
        var context = _pool.Get();
        try
        {
            return await _connection.QueryFirstOrDefaultAsync<AppTenantInfo>(
                "SELECT * FROM Tenants WHERE Identifier = @Identifier",
                new { Identifier = identifier });
        }
        finally
        {
            _pool.Return(context);
        }
    }

    // ... other database store methods ...
}

// 6. 混合存储实现(内存+Redis+数据库)
public class HybridTenantStore : IMultiTenantStore<AppTenantInfo>
{
    private readonly IMemoryCache _memoryCache;
    private readonly IDistributedCache _distributedCache;
    private readonly IDbConnection _dbConnection;
    private readonly ObjectPool<HybridContext> _pool;
    private readonly Channel<TenantHybridMessage> _channel;

    public HybridTenantStore(
        IMemoryCache memoryCache,
        IDistributedCache distributedCache,
        IDbConnection dbConnection)
    {
        _memoryCache = memoryCache;
        _distributedCache = distributedCache;
        _dbConnection = dbConnection;
        _channel = Channel.CreateBounded<TenantHybridMessage>(new BoundedChannelOptions(10000)
        {
            SingleReader = true,
            AllowSynchronousContinuations = true,
            FullMode = BoundedChannelFullMode.DropOldest
        });
        _pool = new DefaultObjectPool<HybridContext>(new HybridContextPooledPolicy());
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task<AppTenantInfo?> TryGetByIdentifierAsync(string identifier)
    {
        var context = _pool.Get();
        try
        {
            // 1. 检查内存缓存
            if (_memoryCache.TryGetValue<AppTenantInfo>($"tenant:{identifier}", out var cachedTenant))
                return cachedTenant;

            // 2. 检查Redis缓存
            var redisTenant = await _distributedCache.GetStringAsync($"tenant:{identifier}");
            if (redisTenant != null)
            {
                var tenant = JsonSerializer.Deserialize<AppTenantInfo>(redisTenant);
                _memoryCache.Set($"tenant:{identifier}", tenant, TimeSpan.FromMinutes(1));
                return tenant;
            }

            // 3. 查询数据库
            var dbTenant = await _dbConnection.QueryFirstOrDefaultAsync<AppTenantInfo>(
                "SELECT * FROM Tenants WHERE Identifier = @Identifier",
                new { Identifier = identifier });

            if (dbTenant != null)
            {
                await _distributedCache.SetStringAsync(
                    $"tenant:{identifier}", 
                    JsonSerializer.Serialize(dbTenant),
                    new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5) });
                
                _memoryCache.Set($"tenant:{identifier}", dbTenant, TimeSpan.FromMinutes(1));
            }

            return dbTenant;
        }
        finally
        {
            _pool.Return(context);
        }
    }

    // ... other hybrid store methods ...
}

public class SqliteTenantStore : IMultiTenantStore<AppTenantInfo>
{
    private readonly ObjectPool<SqliteConnection> _pool;
    private readonly IMemoryCache _cache;
    private readonly Channel<TenantCacheMessage> _channel;

    public SqliteTenantStore(string connectionString, IMemoryCache cache)
    {
        _cache = cache;
        _pool = new DefaultObjectPool<SqliteConnection>(
            new SqliteConnectionPooledPolicy(connectionString), 
            Environment.ProcessorCount * 2);
        
        _channel = Channel.CreateBounded<TenantCacheMessage>(10000);
        _ = Task.Run(ProcessCacheMessagesAsync);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task<AppTenantInfo?> TryGetByIdentifierAsync(string identifier)
    {
        if (_cache.TryGetValue<AppTenantInfo>($"tenant:{identifier}", out var cachedTenant))
            return cachedTenant;

        var connection = _pool.Get();
        try
        {
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM Tenants WHERE Identifier = @identifier";
            command.Parameters.AddWithValue("@identifier", identifier);

            await using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                var tenant = new AppTenantInfo
                {
                    Id = reader["Id"].ToString(),
                    Identifier = reader["Identifier"].ToString(),
                    Name = reader["Name"].ToString(),
                    ConnectionString = reader["ConnectionString"].ToString(),
                    Schema = reader["Schema"].ToString()
                };

                await _channel.Writer.WriteAsync(new TenantCacheMessage(tenant, TimeSpan.FromMinutes(5)));
                return tenant;
            }
            return null;
        }
        finally
        {
            _pool.Return(connection);
        }
    }

    private async Task ProcessCacheMessagesAsync()
    {
        await foreach (var message in _channel.Reader.ReadAllAsync())
        {
            _cache.Set($"tenant:{message.Tenant.Identifier}", message.Tenant, message.Expiration);
        }
    }
}

public class LiteDbTenantStore : IMultiTenantStore<AppTenantInfo>
{
    private readonly ObjectPool<ILiteDatabase> _pool;
    private readonly IMemoryCache _cache;
    private readonly Channel<TenantCacheMessage> _channel;

    public LiteDbTenantStore(string connectionString, IMemoryCache cache)
    {
        _cache = cache;
        _pool = new DefaultObjectPool<ILiteDatabase>(
            new LiteDbDatabasePooledPolicy(connectionString),
            Environment.ProcessorCount * 2);
        
        _channel = Channel.CreateBounded<TenantCacheMessage>(10000);
        _ = Task.Run(ProcessCacheMessagesAsync);
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task<AppTenantInfo?> TryGetByIdentifierAsync(string identifier)
    {
        if (_cache.TryGetValue<AppTenantInfo>($"tenant:{identifier}", out var cachedTenant))
            return cachedTenant;

        var db = _pool.Get();
        try
        {
            var collection = db.GetCollection<AppTenantInfo>("tenants");
            var tenant = collection.FindOne(x => x.Identifier == identifier);
            
            if (tenant != null)
            {
                await _channel.Writer.WriteAsync(new TenantCacheMessage(tenant, TimeSpan.FromMinutes(5)));
                return tenant;
            }
            return null;
        }
        finally
        {
            _pool.Return(db);
        }
    }

    private async Task ProcessCacheMessagesAsync()
    {
        await foreach (var message in _channel.Reader.ReadAllAsync())
        {
            _cache.Set($"tenant:{message.Tenant.Identifier}", message.Tenant, message.Expiration);
        }
    }
}

public static class MultiTenantBuilderExtensions
{
    public static MultiTenantBuilder<AppTenantInfo> WithSqliteStore(
        this MultiTenantBuilder<AppTenantInfo> builder, 
        string connectionString)
    {
        builder.Services.AddSingleton<IMultiTenantStore<AppTenantInfo>>(sp => 
            new SqliteTenantStore(
                connectionString, 
                sp.GetRequiredService<IMemoryCache>()));
        return builder;
    }

    public static MultiTenantBuilder<AppTenantInfo> WithLiteDbStore(
        this MultiTenantBuilder<AppTenantInfo> builder, 
        string connectionString)
    {
        builder.Services.AddSingleton<IMultiTenantStore<AppTenantInfo>>(sp => 
            new LiteDbTenantStore(
                connectionString, 
                sp.GetRequiredService<IMemoryCache>()));
        return builder;
    }
}

// 5. 高性能多租户DbContext(CPU cache-line对齐+对象池优化)
[SkipLocalsInit]
public class MultiTenantDbContext : DbContext
{
    private readonly ITenantInfo _tenantInfo;
    private readonly ObjectPool<DbContext> _dbContextPool;
    private readonly Channel<DbCommand> _commandChannel;
    private readonly TailLatencyOptimizer _latencyOptimizer;

    public MultiTenantDbContext(
        DbContextOptions options,
        ITenantInfo tenantInfo,
        ObjectPool<DbContext> dbContextPool) : base(options)
    {
        _tenantInfo = tenantInfo;
        _dbContextPool = dbContextPool;
        _latencyOptimizer = new TailLatencyOptimizer();
        
        // Disruptor模式命令通道
        _commandChannel = Channel.CreateBounded<DbCommand>(new BoundedChannelOptions(10000)
        {
            SingleReader = true,
            AllowSynchronousContinuations = true,
            FullMode = BoundedChannelFullMode.DropOldest
        });
    }

    // 6. 租户感知查询过滤(使用Span优化)
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var entityTypes = modelBuilder.Model.GetEntityTypes();
        foreach (var entityType in entityTypes)
        {
            if (typeof(ITenantEntity).IsAssignableFrom(entityType.ClrType))
            {
                var method = typeof(MultiTenantDbContext)
                    .GetMethod(nameof(ApplyTenantFilter), BindingFlags.NonPublic | BindingFlags.Instance)
                    ?.MakeGenericMethod(entityType.ClrType);
                
                method?.Invoke(this, new object[] { modelBuilder, entityType });
            }
        }
    }

    private void ApplyTenantFilter<TEntity>(ModelBuilder modelBuilder, IMutableEntityType entityType) 
        where TEntity : class, ITenantEntity
    {
        modelBuilder.Entity<TEntity>()
            .HasQueryFilter(e => e.TenantId == _tenantInfo.Id);
    }

    // 7. 高性能命令执行管道
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public override async Task<int> SaveChangesAsync(
        bool acceptAllChangesOnSuccess, 
        CancellationToken cancellationToken = default)
    {
        // 自动设置租户ID
        foreach (var entry in ChangeTracker.Entries<ITenantEntity>()
            .Where(e => e.State == EntityState.Added))
        {
            entry.Entity.TenantId = _tenantInfo.Id;
        }

        // 通过通道异步处理命令
        await _commandChannel.Writer.WriteAsync(
            new DbCommand(ChangeTracker, acceptAllChangesOnSuccess), 
            cancellationToken);
        
        return await base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
    }
}

// 8. 租户实体标记接口
public interface ITenantEntity
{
    string TenantId { get; set; }
}

// 9. DbContext对象池策略
public class DbContextPooledPolicy : PooledObjectPolicy<DbContext>
{
    private readonly DbContextOptions _options;
    private readonly ITenantInfo _tenantInfo;

    public DbContextPooledPolicy(DbContextOptions options, ITenantInfo tenantInfo)
    {
        _options = options;
        _tenantInfo = tenantInfo;
    }

    public override DbContext Create()
    {
        return new MultiTenantDbContext(_options, _tenantInfo, this);
    }

    public override bool Return(DbContext obj)
    {
        obj.ChangeTracker.Clear();
        return true;
    }
}

// 10. 注册服务扩展方法
[SkipLocalsInit]
public static class ServiceCollectionExtensions
{
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public static IServiceCollection AddMultiTenantDbContext<TContext>(
        this IServiceCollection services,
        Action<DbContextOptionsBuilder> optionsAction)
        where TContext : MultiTenantDbContext
    {
        services.AddDbContextPool<TContext>(optionsAction, poolSize: 1000);
        
        services.AddSingleton<ObjectPool<DbContext>>(sp =>
        {
            var options = sp.GetRequiredService<DbContextOptions<TContext>>();
            var tenantInfo = sp.GetRequiredService<ITenantInfo>();
            return new DefaultObjectPool<DbContext>(
                new DbContextPooledPolicy(options, tenantInfo), 1000);
        });

        return services;
    }
}

// 在控制器中使用
public class ProductsController : Controller
{
    private readonly AppDbContext _context;

    public ProductsController(AppDbContext context)
    {
        _context = context;
    }
    
    public async Task<IActionResult> Index()
    {
        // 自动过滤当前租户数据
        var products = await _context.Products.ToListAsync();
        return View(products);
    }
}

// 5. 主程序配置
var builder = WebApplication.CreateBuilder(args);

// 配置多租户服务
builder.Services.AddMultiTenant<AppTenantInfo>()
    .WithStrategy<TenantResolver>(ServiceLifetime.Singleton)
    //.WithStore<TenantResolver>();
    .WithSqliteStore("Data Source=tenants.db"); // 或 .WithLiteDbStore("Filename=tenants.db")

// 添加内存缓存
builder.Services.AddMemoryCache();
// 注册服务
builder.Services.AddMultiTenantDbContext<AppDbContext>(options => 
    options.UseSqlite(Configuration.GetConnectionString("Sqlite:ConnectionString")));

var app = builder.Build();

// 使用多租户中间件
app.UseMultiTenant();

app.MapGet("/", (IMultiTenantContext<AppTenantInfo> tenantContext) =>
    $"Tenant: {tenantContext.TenantInfo?.Name}");

app.Run();


// 基础租户实体
public abstract class TenantAwareEntity {
    public string TenantId { get; set; }
    
    // 其他公共属性如创建时间等
}

// 业务实体示例
public class Product : TenantAwareEntity {
    public Guid Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}

// 租户路由策略
public class TenantRoutingStrategy {
    private readonly IOptions<TenantRoutingOptions> _options;
    private readonly ObjectPool<DbContext> _dbPool;
    
    public TenantRoutingStrategy(
        IOptions<TenantRoutingOptions> options,
        ObjectPool<DbContext> dbPool) {
        _options = options;
        _dbPool = dbPool;
    }
    
    public DbContext GetDbContext(string tenantId) {
        var dbContext = _dbPool.Get();
        var connString = _options.Value.GetConnectionString(tenantId);
        
        dbContext.Database.SetConnectionString(connString);
        return dbContext;
    }
}

// 租户路由配置
public class TenantRoutingOptions {
    public Dictionary<string, TenantDatabase> Tenants { get; set; }
    
    public string GetConnectionString(string tenantId) {
        if (Tenants.TryGetValue(tenantId, out var tenantDb)) {
            return tenantDb.ConnectionString;
        }
        throw new TenantNotFoundException(tenantId);
    }
}

public class TenantDatabase {
    public string ConnectionString { get; set; }
    public bool IsReadOnly { get; set; }
}

public interface ITenantProvider {
    string GetCurrentTenantId();
}

public class TenantContext : ITenantProvider {
    private readonly IHttpContextAccessor _httpContextAccessor;
    
    public TenantContext(IHttpContextAccessor httpContextAccessor) {
        _httpContextAccessor = httpContextAccessor;
    }
    
    public string GetCurrentTenantId() => 
        _httpContextAccessor.HttpContext?.Items["TenantId"] as string;
}

public class TenantDbContext : DbContext {
    private readonly ITenantProvider _tenantProvider;
    
    public TenantDbContext(
        DbContextOptions options, 
        ITenantProvider tenantProvider) : base(options) {
        _tenantProvider = tenantProvider;
    }
    
    protected override void OnModelCreating(ModelBuilder modelBuilder) {
        modelBuilder.Entity<SomeEntity>()
            .HasQueryFilter(e => e.TenantId == _tenantProvider.GetCurrentTenantId());
    }
}