#:sdk Microsoft.NET.Sdk.Web
#:package MemoryPack@2.0.0
#:package System.Threading.Channels@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0

/*
当前实现已经具备良好的高性能基础，建议下一步：

1. 增加物模型校验规则引擎
2. 实现物模型可视化编辑接口
3. 添加物模型变更通知机制
4. 支持物模型多协议自动转换
需要特别注意的优化点：

- 物模型序列化/反序列化的内存分配
- 高频访问时的缓存一致性
- 大规模物模型加载的启动性能
- 协议热切换时的数据一致性保证
*/
[SkipLocalsInit]
public sealed class ThingModelService : BackgroundService
{
    private readonly Channel<ModelUpdateEvent> _updateChannel;
    private readonly ConcurrentDictionary<string, DeviceModel> _modelCache;
    private readonly IMemoryCache _memoryCache;
    private readonly IDistributedCache _distributedCache;

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        await foreach (var update in _updateChannel.Reader.ReadAllAsync(ct))
        {
            // 三级缓存更新策略
            _modelCache.AddOrUpdate(update.ModelId, update.Model, (_,_) => update.Model);
            _memoryCache.Set(update.ModelId, update.Model);
            await _distributedCache.SetAsync($"model:{update.ModelId}", 
                MemoryPackSerializer.Serialize(update.Model),
                new DistributedCacheEntryOptions { SlidingExpiration = TimeSpan.FromHours(1) },
                ct);
        }
    }

    // 物模型版本对比
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public async Task<bool> CompareModelVersions(string modelId, string currentVersion)
    {
        if (_modelCache.TryGetValue(modelId, out var cached))
        {
            return cached.Version == currentVersion;
        }
        // ... existing code ...
    }

    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 使用MemoryPack零拷贝序列化
[MethodImpl(MethodImplOptions.AggressiveOptimization)]
public byte[] SerializeModel(DeviceModel model)
{
    Span<byte> buffer = stackalloc byte[1024];
    if (MemoryPackSerializer.TrySerialize(model, buffer, out var bytesWritten))
        return buffer[..bytesWritten].ToArray();
    
    // 大对象回退到池化内存
    using var owner = MemoryPool<byte>.Shared.Rent(4096);
    MemoryPackSerializer.Serialize(model, owner.Memory);
    return owner.Memory.ToArray();
}

// 三级缓存+版本号校验
private readonly record struct CacheEntry(DeviceModel Model, string Version);

[MethodImpl(MethodImplOptions.AggressiveInlining)]
public DeviceModel? GetModel(string modelId)
{
    // L1缓存：线程本地缓存
    if (_threadLocalCache.TryGetValue(modelId, out var entry) && 
        entry.Version == _distributedCache.GetVersion(modelId))
        return entry.Model;

    // L2/L3缓存检查...
    // 并行加载+内存映射文件
    private async Task LoadAllModelsAsync()
    {
        var files = Directory.EnumerateFiles("./models", "*.bin");
        await Parallel.ForEachAsync(files, async (file, ct) =>
        {
            using var mmap = MemoryMappedFile.CreateFromFile(file);
            using var accessor = mmap.CreateViewAccessor();
            var model = MemoryPackSerializer.Deserialize<DeviceModel>(accessor);
            _modelCache.TryAdd(model.Id, model);
        });
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 双缓冲+原子切换
private readonly ReaderWriterLockSlim _protocolLock = new();

public void SwitchProtocol(string newProtocol)
{
    _protocolLock.EnterWriteLock();
    try
    {
        // 1. 预加载新协议
        var newProtocolImpl = LoadProtocol(newProtocol);
        
        // 2. 原子替换
        Interlocked.Exchange(ref _currentProtocol, newProtocolImpl);
        
        // 3. 异步回收旧协议
        Task.Run(() => DisposeProtocol(_previousProtocol));
    }
    finally { _protocolLock.ExitWriteLock(); }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存
                _ = Task.Run(() => RefreshModelCacheAsync(protocolName));
            }
        }
    }
}

// 一级缓存+一级缓存刷新
private async Task RefreshModelCacheAsync(string protocolName)
{
    // 协议热加载优化
    private void OnProtocolChanged(object sender, FileSystemEventArgs e)
    {
        var protocolName = Path.GetFileNameWithoutExtension(e.Name);
        if (_protocols.TryGetValue(protocolName, out var protocol))
        {
            // 使用AOT友好方式重新加载
            var reloadSuccess = NativeLibrary.TryLoad(protocolName, out var handle);
            if (reloadSuccess && protocol is IHotReloadableProtocol reloadable)
            {
                reloadable.Reload();
                _logger.LogInformation("Protocol {Protocol} reloaded", protocolName);
                
                // 更新物模型缓存