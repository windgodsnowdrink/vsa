#:sdk Microsoft.NET.Sdk.Web
#:package MediatR@12.1.1
#:package Grpc.AspNetCore@2.62.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable

using MediatR;
using Grpc.Core;
using Grpc.AspNetCore.Server;
using Microsoft.Extensions.DependencyInjection;

// 1. 定义gRPC服务契约
[GrpcService(Name = "MediatRGateway")]
public interface IMediatRGateway
{
    Task<GrpcResponse> ExecuteCommand(GrpcRequest request);
}

// 2. 定义gRPC请求/响应模型
public class GrpcRequest
{
    public string CommandType { get; set; }
    public string CommandData { get; set; }
}

public class GrpcResponse
{
    public bool Success { get; set; }
    public string ResponseData { get; set; }
}

// 3. 实现gRPC服务
public class MediatRGatewayService : IMediatRGateway
{
    private readonly IMediator _mediator;
    private readonly ISerializer _serializer;

    public MediatRGatewayService(IMediator mediator, ISerializer serializer)
    {
        _mediator = mediator;
        _serializer = serializer;
    }

    public async Task<GrpcResponse> ExecuteCommand(GrpcRequest request)
    {
        try
        {
            // 反序列化命令
            var commandType = Type.GetType(request.CommandType);
            var command = _serializer.Deserialize(request.CommandData, commandType);
            
            // 动态调用MediatR
            dynamic result = await _mediator.Send((dynamic)command);
            
            return new GrpcResponse
            {
                Success = true,
                ResponseData = _serializer.Serialize(result)
            };
        }
        catch (Exception ex)
        {
            return new GrpcResponse
            {
                Success = false,
                ResponseData = ex.Message
            };
        }
    }
}

// 4. DI扩展方法
// 1. 添加分布式事务支持包
#:package DTM.Client@2.6.0
#:package DTM.Grpc@2.6.0

// 2. 定义分布式事务拦截器
public class DistributedTransactionInterceptor : Interceptor
{
    private readonly IDtmClient _dtmClient;
    
    public DistributedTransactionInterceptor(IDtmClient dtmClient)
    {
        _dtmClient = dtmClient;
    }

    public override async Task<TResponse> UnaryServerHandler<TRequest, TResponse>(
        TRequest request,
        ServerCallContext context,
        UnaryServerMethod<TRequest, TResponse> continuation)
    {
        // 从metadata获取事务ID
        var transactionId = context.RequestHeaders
            .FirstOrDefault(h => h.Key == "dtm-transaction-id")?.Value;

        if (!string.IsNullOrEmpty(transactionId))
        {
            // 注册分支事务
            await _dtmClient.RegisterBranchAsync(
                transactionId,
                context.Method,
                JsonSerializer.Serialize(request));

            try
            {
                var result = await continuation(request, context);
                await _dtmClient.ReportBranchResultAsync(transactionId, true);
                return result;
            }
            catch
            {
                await _dtmClient.ReportBranchResultAsync(transactionId, false);
                throw;
            }
        }

        return await continuation(request, context);
    }
}

// 3. 扩展DI方法
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddMediatRGrpcGateway(this IServiceCollection services)
    {
        services.AddGrpc(options =>
        {
            options.Interceptors.Add<ExceptionInterceptor>();
            options.Interceptors.Add<DistributedTransactionInterceptor>();
        });

        services.AddDtmClient(options =>
        {
            options.DtmUrl = "http://localhost:36789";
            options.BranchName = "mediatr-grpc-service";
        });

        services.AddSingleton<IMediatRGateway, MediatRGatewayService>();
        services.AddSingleton<ISerializer, JsonSerializer>();
        
        return services;
    }
}

// 5. 异常拦截器
public class ExceptionInterceptor : Interceptor
{
    public override async Task<TResponse> UnaryServerHandler<TRequest, TResponse>(
        TRequest request,
        ServerCallContext context,
        UnaryServerMethod<TRequest, TResponse> continuation)
    {
        try
        {
            return await continuation(request, context);
        }
        catch (Exception ex)
        {
            throw new RpcException(new Status(StatusCode.Internal, ex.Message));
        }
    }
}

// 6. 启动配置
var builder = WebApplication.CreateBuilder();
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(Program).Assembly));
builder.Services.AddMediatRGrpcGateway();

var app = builder.Build();
app.MapGrpcService<MediatRGatewayService>();
app.Run();

// 4. 使用示例 - 跨服务事务
public async Task<GrpcResponse> TransferFunds(GrpcRequest request)
{
    var transactionId = Guid.NewGuid().ToString();
    
    // 创建DTM事务
    await _dtmClient.ExecuteTransactionAsync(transactionId, async (dtmClient) =>
    {
        // 调用账户服务
        await _mediator.Send(new DebitAccountCommand(), cancellationToken);
        
        // 通过gRPC调用支付服务
        var paymentRequest = new GrpcRequest
        {
            CommandType = typeof(ProcessPaymentCommand).AssemblyQualifiedName,
            CommandData = JsonSerializer.Serialize(new ProcessPaymentCommand())
        };
        
        var headers = new Metadata
        {
            { "dtm-transaction-id", transactionId }
        };
        
        await _paymentClient.ExecuteCommandAsync(paymentRequest, headers);
    });
    
    return new GrpcResponse { Success = true };
}