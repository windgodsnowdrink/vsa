#:sdk Microsoft.NET.Sdk.Web
#:package Microsoft.IO.RecyclableMemoryStream@2.3.2
#:package System.Buffers@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using Microsoft.IO;
using System.Buffers;
using System.Threading.Channels;

var builder = WebApplication.CreateBuilder();

// 1. 配置内存管理器
builder.Services.AddSingleton<RecyclableMemoryStreamManager>(sp => 
    new RecyclableMemoryStreamManager(
        blockSize: 1024 * 1024,  // 1MB块大小
        largeBufferMultiple: 8 * 1024 * 1024,  // 8MB大缓冲区
        maximumBufferSize: 128 * 1024 * 1024,  // 128MB最大缓冲区
        useExponentialLargeBuffer: true)
    {
        AggressiveBufferReturn = true,
        GenerateCallStacks = false
    });

// 2. 高性能内存通道
var memoryChannel = Channel.CreateBounded<Memory<byte>>(
    new BoundedChannelOptions(10000)
    {
        SingleReader = true,
        AllowSynchronousContinuations = true
    });

// 3. 零拷贝内存处理器
builder.Services.AddSingleton<IMemoryProcessor>(sp => 
    new ChannelMemoryProcessor(
        memoryChannel,
        new ThreadLocal<Span<byte>>(() => stackalloc byte[512])));

var app = builder.Build();
app.MapGet("/", () => "RecyclableMemoryStream Ready");
app.Run();

[SkipLocalsInit]
public class ChannelMemoryProcessor : IMemoryProcessor
{
    private readonly ChannelWriter<Memory<byte>> _writer;
    private readonly ThreadLocal<Span<byte>> _buffer;
    
    public ChannelMemoryProcessor(Channel<Memory<byte>> channel, ThreadLocal<Span<byte>> buffer)
    {
        _writer = channel.Writer;
        _buffer = buffer;
    }

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public unsafe void Process(Memory<byte> memory)
    {
        Span<byte> buffer = stackalloc byte[512];
        fixed (byte* ptr = buffer)
        {
            if ((long)ptr % 64 == 0) // Cache-line对齐
            {
                // SIMD优化处理内存数据
                _writer.TryWrite(memory);
            }
        }
    }
}