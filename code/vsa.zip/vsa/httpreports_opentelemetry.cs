#:sdk Microsoft.NET.Sdk.Web
#:package HttpReports@3.0.0
#:package OpenTelemetry.Exporter.OpenTelemetryProtocol@1.6.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using HttpReports;
using OpenTelemetry.Trace;

var builder = WebApplication.CreateBuilder();

// 配置HttpReports与OpenTelemetry集成
builder.Services.AddHttpReports(options =>
{
    options.OpenTelemetry = new OpenTelemetryOptions
    {
        Endpoint = "http://localhost:4317",
        Protocol = OpenTelemetryProtocol.Http,
        ExportProcessorType = ExportProcessorType.Batch,
        BatchExportProcessorOptions = new BatchExportProcessorOptions<Activity>
        {
            MaxQueueSize = 2048,
            ScheduledDelayMilliseconds = 5000,
            ExporterTimeoutMilliseconds = 30000,
            MaxExportBatchSize = 512
        }
    };
});

var app = builder.Build();
app.UseHttpReports();
app.MapGet("/", () => "HttpReports with OpenTelemetry Ready");
app.Run();