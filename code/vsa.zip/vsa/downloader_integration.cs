#:sdk Microsoft.NET.Sdk.Web
#:package Downloader@3.0.0
#:package Microsoft.Extensions.ObjectPool@8.0.0
#:property LangVersion preview
#:property TargetFramework net10.0
#:property Nullable enable
#:property ImplicitUsings enable

using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Downloader;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.ObjectPool;

namespace DownloaderIntegration
{
    public interface IDownloadService
    {
        Task<Stream> DownloadAsync(string url, string tempPath, CancellationToken cancellationToken = default);
        Task ResumeDownloadAsync(string url, string tempPath, CancellationToken cancellationToken = default);
    }

    public class DownloadService : IDownloadService
    {
        private readonly ObjectPool<DownloadConfiguration> _configPool;
        private readonly ThreadLocal<Memory<byte>> _downloadBuffer;
        private readonly Channel<DownloadPackage> _downloadQueue;

        public DownloadService(
            ObjectPool<DownloadConfiguration> configPool,
            ThreadLocal<Memory<byte>> downloadBuffer,
            Channel<DownloadPackage> downloadQueue)
        {
            _configPool = configPool;
            _downloadBuffer = downloadBuffer;
            _downloadQueue = downloadQueue;
        }

        public async Task<Stream> DownloadAsync(string url, string tempPath, CancellationToken cancellationToken = default)
        {
            var config = _configPool.Get();
            try
            {
                var downloader = new DownloadService(config);
                
                // 进度更新处理
                downloader.DownloadProgressChanged += (s, e) => 
                {
                    var progress = new DownloadProgress
                    {
                        BytesReceived = e.BytesReceived,
                        TotalBytesToReceive = e.TotalBytesToReceive,
                        ProgressPercentage = e.ProgressPercentage,
                        BytesPerSecondSpeed = e.BytesPerSecondSpeed,
                        Chunks = e.Chunks,
                        ActiveChunks = e.ActiveChunks
                    };
                    
                    // 通过Channel发送进度更新
                    _progressChannel.Writer.TryWrite(progress);
                };

                var package = new DownloadPackage
                {
                    Urls = new[] { url },
                    TotalFileSize = 0,
                    FileName = Path.GetFileName(url),
                    TempDirectory = tempPath
                };

                // 断点续传检查
                if (File.Exists(Path.Combine(tempPath, package.FileName + ".download")))
                {
                    package = DownloadPackage.Load(tempPath);
                }

                await _downloadQueue.Writer.WriteAsync(package, cancellationToken);
                
                // 流式下载处理
                var memoryStream = new MemoryStream();
                downloader.DownloadFileCompleted += (s, e) => 
                {
                    if (e.Cancelled || e.Error != null)
                        return;
                        
                    using var fileStream = File.OpenRead(Path.Combine(tempPath, package.FileName));
                    fileStream.CopyTo(memoryStream);
                    memoryStream.Position = 0;
                };
                
                await downloader.DownloadFileTaskAsync(package);
                
                return memoryStream;
            }
            finally
            {
                _configPool.Return(config);
            }
        }

        public async Task ResumeDownloadAsync(string url, string tempPath, CancellationToken cancellationToken = default)
        {
            var config = _configPool.Get();
            try
            {
                var downloader = new DownloadService(config);
                var package = DownloadPackage.Load(tempPath);
                
                await downloader.DownloadFileTaskAsync(package);
            }
            finally
            {
                _configPool.Return(config);
            }
        }
        
        // 新增进度模型
        public class DownloadProgress
        {
            public long BytesReceived { get; set; }
            public long TotalBytesToReceive { get; set; }
            public double ProgressPercentage { get; set; }
            public double BytesPerSecondSpeed { get; set; }
            public int Chunks { get; set; }
            public int ActiveChunks { get; set; }
        }
    }

    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddDownloadServices(this IServiceCollection services)
        {
            services.AddSingleton<ObjectPool<DownloadConfiguration>>(sp =>
            {
                var policy = new DefaultPooledObjectPolicy<DownloadConfiguration>();
                return new DefaultObjectPool<DownloadConfiguration>(policy, Environment.ProcessorCount * 2);
            });
            
            services.AddSingleton<ThreadLocal<Memory<byte>>>(_ => 
                new ThreadLocal<Memory<byte>>(() => new Memory<byte>(new byte[81920])));
                
            services.AddSingleton<Channel<DownloadPackage>>(_ => 
                Channel.CreateUnbounded<DownloadPackage>(new UnboundedChannelOptions
                {
                    SingleReader = true,
                    SingleWriter = false,
                    AllowSynchronousContinuations = true
                }));
                
            services.AddSingleton<IDownloadService, DownloadService>();
            
            return services;
        }
    }
}